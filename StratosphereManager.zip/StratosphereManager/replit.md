# Portfolio Management Platform

## Overview

A comprehensive enterprise portfolio management system for tracking organizational streams, sub-streams, projects, tasks, and strategic goals. The platform provides hierarchical project organization with RAID log management, stakeholder tracking, document management, goal alignment visualization, budget management with expense tracking and budget lines for planned allocations, and progress rollup system that aggregates task completion through the hierarchy. Built with React, Express, and PostgreSQL with full database persistence using Drizzle ORM. Design follows clean patterns inspired by Linear and Material Design principles.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack**
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system

**Component Structure**
The application follows a component-based architecture with:
- Reusable UI components in `/client/src/components/ui/` (Shadcn components)
- Feature-specific components in `/client/src/components/` (StreamCard, TaskTable, RAIDLog, etc.)
- Page-level components in `/client/src/pages/` (Dashboard, Goals, Summary, etc.)
- Custom hooks in `/client/src/hooks/` for shared logic

**Design System**
- Typography: Inter font family via Google Fonts CDN
- Spacing: Tailwind units (2, 4, 6, 8) for consistent spacing
- Color System: HSL-based theming with light/dark mode support via CSS variables
- Layout Pattern: Three-panel dashboard (sidebar navigation, main content, conditional right panel)

### Backend Architecture

**Technology Stack**
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **ORM**: Drizzle ORM for type-safe database operations
- **Database Driver**: @neondatabase/serverless for PostgreSQL connectivity
- **Validation**: Zod schemas integrated with Drizzle

**API Structure**
RESTful API with CRUD endpoints for each entity:
- Streams: `/api/streams`
- Sub-streams: `/api/substreams`
- Projects: `/api/projects`
- Tasks: `/api/tasks`
- RAID logs: `/api/raid-logs`
- Documents: `/api/documents`
- Stakeholders: `/api/stakeholders`
- Strategic goals: `/api/strategic-goals`
- Milestones: `/api/milestones`

**Data Layer**
- **PostgreSQL Database**: All data persists to Neon-backed PostgreSQL database
- **Storage Implementation**: `DbStorage` class (in `/server/storage.ts`) implements `IStorage` interface with 75 methods across 14 entity types
- **Drizzle ORM**: Type-safe database operations using @neondatabase/serverless driver
- Type-safe database schemas defined in `/shared/schema.ts`
- Schema validation using Drizzle-Zod integration
- Database migrations handled via `npm run db:push` (not manual SQL)

### Data Model Hierarchy

**Organizational Structure**
1. **Strategic Goals**: High-level organizational objectives
2. **Streams**: Top-level portfolio groupings aligned to strategic goals
3. **Sub-Streams**: Categorical divisions within streams (e.g., "In-house Development", "Off the Shelf")
4. **Projects**: Individual initiatives within sub-streams
5. **Tasks**: Granular work items within projects

**Supporting Entities**
- **Users**: Owner/assignee tracking with authentication support
- **Milestones**: Project delivery checkpoints with dates and status
- **RAID Logs**: Risk, Assumption, Issue, Dependency tracking per project
- **Documents**: File management with categorization
- **Stakeholders**: Project stakeholder management with engagement levels
- **Activities**: Audit trail and activity logging
- **Benefits**: Separate tracking of project benefits distinct from risks
- **Expenses**: Actual spending per project with category, date, and description
- **Budget Lines**: Planned budget allocations per category within projects

### Database & Persistence

**Implementation Status**: ✅ **Fully Operational**
- **Database**: PostgreSQL via Replit (Neon-backed) connected via DATABASE_URL environment variable
- **ORM**: Drizzle ORM with @neondatabase/serverless driver and WebSocket support
- **Storage Class**: `DbStorage` (75 methods) replaces previous in-memory `MemStorage`
- **Schema Management**: Run `npm run db:push` to sync schema changes (use `--force` if data-loss warning appears)
- **Entity Coverage**: All 14 entity types persist to database (users, streams, subStreams, projects, tasks, raidLogs, documents, stakeholders, strategicGoals, milestones, benefits, expenses, budgetLines, activities)

### Authentication & Authorization

Currently implements basic user management structure with:
- User table with username/password fields (persisted in PostgreSQL)
- Session management placeholder (connect-pg-simple installed)
- Owner assignment throughout entity hierarchy
- Foundation for role-based access control (not yet implemented)

### Development Patterns

**Form Handling**
- React Hook Form with Zod resolver for type-safe validation
- Reusable dialog components for create operations (CreateStreamDialog, CreateProjectDialog, etc.)
- Consistent form patterns across all entity types

**Data Fetching**
- TanStack Query for declarative data fetching
- Custom `queryClient` with fetch wrapper for API requests
- Optimistic updates and cache invalidation on mutations
- Stale-while-revalidate strategy disabled (staleTime: Infinity)

**Error Handling**
- Toast notifications via Shadcn toast component
- Error boundaries for React component errors
- API error responses with status codes and messages

### Budget Management System

**Budget Tracking Hierarchy**
The platform implements a complete budget rollup system that aggregates expenses from projects up through sub-streams to streams:

1. **Project Level**: Each project has:
   - `allocatedBudget`: Planned budget amount
   - `spentToDate`: Automatically calculated from all project expenses
   - Expenses tracked with category, date, amount, and description

2. **Budget Lines**: Projects can define planned allocations by category:
   - Create multiple budget lines per project
   - Each line specifies category and allocated amount
   - UI compares allocated vs actual spend per category
   - Highlights over-budget categories

3. **Automatic Rollup**: The `recalculateBudgetRollups` helper:
   - Aggregates project spentToDate to sub-stream level
   - Aggregates sub-stream spentToDate to stream level
   - Handles edge cases (empty collections set to "0")
   - Triggered after expense POST/PATCH/DELETE operations

**Current Design Notes**
- Budget lines currently display allocated vs actual per category
- Multiple lines with same category show full category spend (enhancement opportunity for proportional allocation)
- Budget lines are tracked separately from project allocated budgets (future: integrate allocations into rollup calculations)
- Benefits tracking is separate from RAID risks

### Progress Rollup System

**Progress Tracking Hierarchy**
The platform implements automatic progress aggregation from tasks up through the hierarchy:

1. **Task Level**: Each task has a `progress` field (0-100 integer)

2. **Project Level**: Project progress calculated from its tasks:
   - **Weighted Average**: When tasks have `estimatedHours`, progress is weighted by hours
   - **Simple Average**: When no tasks have hours, uses simple average
   - Empty projects default to 0% progress

3. **Sub-Stream Level**: Sub-stream progress is simple average of all its projects

4. **Stream Level**: Stream progress is simple average of all its sub-streams

5. **Automatic Rollup**: Modular rollup functions trigger cascading updates:
   - **Task mutations** → `recalculateProgressRollups(projectId)` → calculates project from tasks, then calls sub-stream rollup
   - **Project mutations** → `recalculateSubStreamProgress(subStreamId)` → calculates sub-stream from projects, then calls stream rollup
   - **Storage methods**: `updateProjectProgress`, `updateSubStreamProgress`, `updateStreamProgress`
   - Rollup triggers on: task POST/PATCH/DELETE, project POST/PATCH/DELETE

**Dashboard Overall Progress Widget**
- Displays the **average of all project progress values** across the entire portfolio
- Formula: `sum of all project.progress / number of projects`
- Updates automatically when task or project progress changes via cache invalidation

**Frontend Cache Invalidation**
- All task mutations invalidate: specific project query, `/api/projects`, `/api/substreams`, `/api/streams`
- All project mutations invalidate: `/api/projects`, `/api/substreams`, `/api/streams`
- All expense mutations invalidate: specific project query, `/api/projects`, `/api/substreams`, `/api/streams`
- This ensures dashboard widgets and all hierarchy views refresh automatically after mutations

**Known Limitations**
- Weighted average skips tasks with null estimatedHours instead of including them with equal weight
- Manual progress updates on projects/sub-streams/streams can become stale until next task mutation

### Task Management Extensions

**Schema Support for Advanced Features** (November 2025)
The tasks table now includes fields to support dependencies, milestones, and subtasks:

1. **Milestone Linkage**: 
   - `milestoneId` field links tasks to project milestones
   - Optional foreign key to milestones table
   - **Date Format Fix** (November 2025): EditTaskDialog now properly formats Date objects to YYYY-MM-DD strings for HTML date inputs, preventing timestamp conversion errors when updating tasks

2. **Subtask Hierarchy**:
   - `parentTaskId` self-referencing foreign key
   - Supports nested task structures

3. **Task Dependencies Table**:
   - Separate `taskDependencies` table with `taskId` and `dependsOnId`
   - Tracks which tasks depend on completion of other tasks
   - Foundation for Gantt chart critical path analysis
   - Backend validation: prevents circular dependencies, enforces same-project constraint, prevents duplicates

4. **Milestone Dependencies Table** (November 2025):
   - Separate `milestoneDependencies` table with `milestoneId` and `dependsOnId`
   - Tracks milestone-to-milestone dependencies within the same project
   - Backend validation: prevents circular dependencies, self-dependencies, cross-project dependencies, and duplicates
   - Full CRUD API: GET/POST/DELETE for milestone dependencies
   - UI integration: MilestoneDialog supports dependency selection via checkboxes (edit mode only)
   - Rollback support: ProjectDetailView includes dependency rollback on update failures

**Implementation Status**:
- ✅ Task dependencies: Database schema, storage methods, API routes, UI integration, client-side rollback
- ✅ Milestone edit/delete: PATCH/DELETE routes, MilestoneDialog edit mode, ProjectDetailView integration
- ✅ Milestone dependencies: Database schema, storage methods, API routes, UI integration, client-side rollback
- ✅ Task update fix: Date formatting in EditTaskDialog to prevent timestamp conversion errors

**Known Limitations**:
- **Non-transactional dependency updates**: Client-side implementation cannot guarantee true ACID semantics for both task and milestone dependencies
  - Restored dependencies receive new IDs (breaks audit trails and historical tracking)
  - Partial rollback failures can leave inconsistent state
  - Rollback failures surfaced via "Critical Error" toast requiring manual verification
- **Critical Future Enhancement Required**: Backend transaction API for atomic updates with dependencies
  - Recommended approach: Single backend endpoint wrapping entity PATCH + dependency mutations in DB transaction
  - Ensures original dependency IDs are preserved during rollback
  - Guarantees all-or-nothing updates with true ACID properties
  - Until implemented: dependency mutations are best-effort with explicit error surfacing

## External Dependencies

### Database
- **PostgreSQL**: Primary data store accessed via Neon serverless driver
- **Drizzle ORM**: Schema definition, migrations, and query builder
- **Database URL**: Required via `DATABASE_URL` environment variable

### UI Component Libraries
- **Radix UI**: Headless component primitives (accordion, dialog, dropdown, select, etc.)
- **Shadcn/ui**: Pre-built components using Radix primitives with Tailwind styling
- **Lucide React**: Icon library for consistent iconography

### Utilities & Tooling
- **date-fns**: Date formatting and manipulation
- **clsx & tailwind-merge**: Utility for conditional className composition
- **class-variance-authority**: Variant-based component styling
- **Embla Carousel**: Carousel/slider functionality
- **cmdk**: Command palette component (installed but not actively used)

### Development Tools
- **Vite Plugins**: Runtime error overlay, development banner (Replit-specific)
- **TypeScript**: Type checking with strict mode enabled
- **ESBuild**: Server-side bundling for production

### Third-Party Services
- **Google Fonts CDN**: Inter font family delivery
- **Replit Integration**: Development environment optimizations (cartographer, dev banner plugins)