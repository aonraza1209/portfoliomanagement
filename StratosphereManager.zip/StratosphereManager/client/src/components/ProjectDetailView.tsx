import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TaskTable } from "./TaskTable";
import { EditTaskDialog } from "./EditTaskDialog";
import { CreateTaskDialog } from "./CreateTaskDialog";
import { RAIDLog } from "./RAIDLog";
import { GanttChart } from "./GanttChart";
import { DocumentManager } from "./DocumentManager";
import { StakeholderGrid } from "./StakeholderGrid";
import { BenefitsGrid } from "./BenefitsGrid";
import { ExpensesGrid } from "./ExpensesGrid";
import { BudgetLinesGrid } from "./BudgetLinesGrid";
import { Calendar, Users, FileText, AlertTriangle, Calendar as CalendarIcon, FolderKanban, DollarSign, Edit } from "lucide-react";
import type { Project, Task, RaidLog, Document, Stakeholder, Benefit, Expense, InsertExpense, BudgetLine, Milestone, InsertMilestone, MilestoneDependency, TaskDependency } from "@shared/schema";
import { CreateMilestoneDialog } from "./CreateMilestoneDialog";
import { MilestoneDialog } from "./MilestoneDialog";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { Pencil, Trash2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ProjectDetailViewProps {
  project: Project;
  tasks: any[];
  raid: {
    risks: any[];
    assumptions: any[];
    issues: any[];
    dependencies: any[];
  };
  documents: Document[];
  stakeholders: Stakeholder[];
  benefits: Benefit[];
  expenses: Expense[];
  budgetLines: BudgetLine[];
  milestones: Milestone[];
  onEdit?: () => void;
  onCreateMilestone?: (data: InsertMilestone) => void;
}

export function ProjectDetailView({
  project,
  tasks,
  raid,
  documents,
  stakeholders,
  benefits,
  expenses,
  budgetLines,
  milestones,
  onEdit,
  onCreateMilestone,
}: ProjectDetailViewProps) {
  const { toast } = useToast();
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [editMilestoneDialogOpen, setEditMilestoneDialogOpen] = useState(false);
  const [selectedMilestone, setSelectedMilestone] = useState<Milestone | null>(null);

  const statusVariant = project.status === 'Active' ? 'default' :
    project.status === 'At Risk' ? 'destructive' : 
    project.status === 'Completed' ? 'outline' : 'secondary';

  const updateTaskWithDependencies = async (
    taskId: string,
    updates: any,
    newDependencyIds: string[],
    existingDependencyIds: string[]
  ) => {
    const payload = {
      ...updates,
      startDate: updates.startDate ? new Date(updates.startDate).toISOString() : undefined,
      endDate: updates.endDate ? new Date(updates.endDate).toISOString() : undefined,
    };
    const updatedTask = await apiRequest("PATCH", `/api/tasks/${taskId}`, payload);
    
    let currentDeps: TaskDependency[];
    try {
      const res = await apiRequest("GET", `/api/tasks/${taskId}/dependencies`);
      currentDeps = await res.json() as TaskDependency[];
    } catch (fetchError) {
      toast({
        variant: "destructive",
        title: "Fetch Error",
        description: "Failed to load current dependencies. Cannot proceed with update.",
      });
      throw new Error("Failed to fetch current dependencies");
    }
    
    try {
      const currentDepIds = currentDeps.map(d => d.dependsOnId);
      
      const unexpectedDeps = currentDepIds.filter(id => !existingDependencyIds.includes(id) && !newDependencyIds.includes(id));
      if (unexpectedDeps.length > 0) {
        toast({
          variant: "destructive",
          title: "Stale Data",
          description: "Dependencies have changed externally. Please refresh and try again.",
        });
        throw new Error("Stale dependency data detected");
      }
      
      const depsToDelete = currentDeps.filter(dep => !newDependencyIds.includes(dep.dependsOnId));
      const depIdsToCreate = newDependencyIds.filter(id => !currentDepIds.includes(id));
      
      const createdDepIds: string[] = [];
      const deletedDeps: Array<{ taskId: string; dependsOnId: string }> = [];
      
      try {
        for (const dependsOnId of depIdsToCreate) {
          try {
            const res = await apiRequest("POST", "/api/task-dependencies", {
              taskId,
              dependsOnId,
            });
            const created = await res.json() as any;
            if (created?.id) createdDepIds.push(created.id);
          } catch (createError: any) {
            if (createError.message?.includes("409") || createError.message?.includes("already exists")) {
              continue;
            }
            throw createError;
          }
        }
        
        for (const dep of depsToDelete) {
          await apiRequest("DELETE", `/api/task-dependencies/${dep.id}`);
          deletedDeps.push({ taskId: dep.taskId, dependsOnId: dep.dependsOnId });
        }
      } catch (mutationError: any) {
        let rollbackFailed = false;
        
        for (const depId of createdDepIds) {
          try {
            await apiRequest("DELETE", `/api/task-dependencies/${depId}`);
          } catch (rollbackError) {
            console.error("Failed to rollback created dependency", depId, rollbackError);
            rollbackFailed = true;
          }
        }
        
        for (const deleted of deletedDeps) {
          try {
            const res = await apiRequest("POST", "/api/task-dependencies", deleted);
            await res.json();
          } catch (restoreError) {
            console.error("Failed to restore deleted dependency", deleted, restoreError);
            rollbackFailed = true;
          }
        }
        
        toast({
          variant: "destructive",
          title: rollbackFailed ? "Critical Error" : "Dependency Error",
          description: rollbackFailed 
            ? "Failed to update dependencies AND rollback failed. Task state may be inconsistent. Please refresh and manually verify dependencies."
            : mutationError.message || "Failed to update task dependencies. Changes rolled back.",
        });
        throw mutationError;
      }
    } catch (error: any) {
      if (!error.message?.includes("Stale") && !error.message?.includes("Dependency Error")) {
        toast({
          variant: "destructive",
          title: "Dependency Error",
          description: error.message || "Failed to update task dependencies",
        });
      }
      throw error;
    }
    
    return updatedTask;
  };

  const updateTaskMutation = useMutation({
    mutationFn: async (data: { taskId: string; updates: any; dependencyIds: string[]; existingDependencyIds: string[] }) => {
      return await updateTaskWithDependencies(data.taskId, data.updates, data.dependencyIds, data.existingDependencyIds);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'dependencies'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      queryClient.invalidateQueries({ queryKey: ['/api/substreams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/streams'] });
      setEditDialogOpen(false);
      setSelectedTask(null);
      toast({
        title: "Task updated",
        description: "The task has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update task. Please try again.",
      });
    },
  });

  const updateMilestoneWithDependencies = async (
    milestoneId: string,
    updates: any,
    newDependencyIds: string[],
    existingDependencyIds: string[]
  ) => {
    const payload = {
      ...updates,
      dueDate: updates.dueDate ? new Date(updates.dueDate).toISOString() : undefined,
    };
    const updatedMilestone = await apiRequest("PATCH", `/api/milestones/${milestoneId}`, payload);
    
    let currentDeps: MilestoneDependency[];
    try {
      const res = await apiRequest("GET", `/api/milestones/${milestoneId}/dependencies`);
      currentDeps = await res.json() as MilestoneDependency[];
    } catch (fetchError) {
      toast({
        variant: "destructive",
        title: "Fetch Error",
        description: "Failed to load current dependencies. Cannot proceed with update.",
      });
      throw new Error("Failed to fetch current dependencies");
    }
    
    try {
      const currentDepIds = currentDeps.map(d => d.dependsOnId);
      
      const unexpectedDeps = currentDepIds.filter(id => !existingDependencyIds.includes(id) && !newDependencyIds.includes(id));
      if (unexpectedDeps.length > 0) {
        toast({
          variant: "destructive",
          title: "Stale Data",
          description: "Dependencies have changed externally. Please refresh and try again.",
        });
        throw new Error("Stale dependency data detected");
      }
      
      const depsToDelete = currentDeps.filter(dep => !newDependencyIds.includes(dep.dependsOnId));
      const depIdsToCreate = newDependencyIds.filter(id => !currentDepIds.includes(id));
      
      const createdDepIds: string[] = [];
      const deletedDeps: Array<{ milestoneId: string; dependsOnId: string }> = [];
      
      try {
        for (const dependsOnId of depIdsToCreate) {
          try {
            const res = await apiRequest("POST", "/api/milestone-dependencies", {
              milestoneId,
              dependsOnId,
            });
            const created = await res.json() as any;
            if (created?.id) createdDepIds.push(created.id);
          } catch (createError: any) {
            if (createError.message?.includes("409") || createError.message?.includes("already exists")) {
              continue;
            }
            throw createError;
          }
        }
        
        for (const dep of depsToDelete) {
          await apiRequest("DELETE", `/api/milestone-dependencies/${dep.id}`);
          deletedDeps.push({ milestoneId: dep.milestoneId, dependsOnId: dep.dependsOnId });
        }
      } catch (error: any) {
        for (const depId of createdDepIds) {
          try {
            await apiRequest("DELETE", `/api/milestone-dependencies/${depId}`);
          } catch (rollbackError) {
            console.error("Rollback failed for dependency", depId, rollbackError);
          }
        }
        
        for (const dep of deletedDeps) {
          try {
            await apiRequest("POST", "/api/milestone-dependencies", {
              milestoneId: dep.milestoneId,
              dependsOnId: dep.dependsOnId,
            });
          } catch (rollbackError) {
            console.error("Critical: Failed to restore dependency", dep, rollbackError);
            toast({
              variant: "destructive",
              title: "Critical Error",
              description: "Failed to rollback some dependency changes. Please verify manually.",
            });
          }
        }
        
        toast({
          variant: "destructive",
          title: "Dependency Error",
          description: error.message || "Failed to update milestone dependencies",
        });
        throw error;
      }
    } catch (error: any) {
      if (!error.message?.includes("Stale") && !error.message?.includes("Dependency Error")) {
        toast({
          variant: "destructive",
          title: "Dependency Error",
          description: error.message || "Failed to update milestone dependencies",
        });
      }
      throw error;
    }
    
    return updatedMilestone;
  };

  const updateMilestoneMutation = useMutation({
    mutationFn: async (data: { milestoneId: string; updates: any; dependencyIds: string[]; existingDependencyIds: string[] }) => {
      return await updateMilestoneWithDependencies(data.milestoneId, data.updates, data.dependencyIds, data.existingDependencyIds);
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'milestones'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/milestones'] });
      queryClient.invalidateQueries({ queryKey: ['/api/milestones', variables.milestoneId, 'dependencies'] });
      setEditMilestoneDialogOpen(false);
      setSelectedMilestone(null);
      toast({
        title: "Milestone updated",
        description: "The milestone has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update milestone. Please try again.",
      });
    },
  });

  const deleteMilestoneMutation = useMutation({
    mutationFn: async (milestoneId: string) => {
      return await apiRequest("DELETE", `/api/milestones/${milestoneId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'milestones'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/milestones'] });
      toast({
        title: "Milestone deleted",
        description: "The milestone has been deleted successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete milestone. Please try again.",
      });
    },
  });

  const handleTaskClick = (taskId: string) => {
    const task = tasks.find((t) => t.id === taskId);
    if (task) {
      setSelectedTask(task);
      setEditDialogOpen(true);
    }
  };

  const handleMilestoneEdit = (milestone: Milestone) => {
    setSelectedMilestone(milestone);
    setEditMilestoneDialogOpen(true);
  };

  const handleMilestoneDelete = async (milestoneId: string) => {
    if (confirm("Are you sure you want to delete this milestone?")) {
      deleteMilestoneMutation.mutate(milestoneId);
    }
  };

  const createRaidMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/raid-logs", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'raid-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/raid-logs'] });
      toast({
        title: "RAID item created",
        description: "The item has been added to the RAID log successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create RAID log item. Please try again.",
      });
    },
  });

  const updateRaidMutation = useMutation({
    mutationFn: async (data: { id: string; updates: any }) => {
      return await apiRequest("PATCH", `/api/raid-logs/${data.id}`, data.updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'raid-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/raid-logs'] });
      toast({
        title: "RAID item updated",
        description: "The item has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update RAID log item. Please try again.",
      });
    },
  });

  const createDocumentMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/documents", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'documents'] });
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
      toast({
        title: "Document added",
        description: "The document has been added to the library successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to add document. Please try again.",
      });
    },
  });

  const createStakeholderMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/stakeholders", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'stakeholders'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stakeholders'] });
      toast({
        title: "Stakeholder added",
        description: "The stakeholder has been added successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to add stakeholder. Please try again.",
      });
    },
  });

  const createBenefitMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/benefits", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'benefits'] });
      queryClient.invalidateQueries({ queryKey: ['/api/benefits'] });
      toast({
        title: "Benefit added",
        description: "The benefit has been added successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to add benefit. Please try again.",
      });
    },
  });

  const createExpenseMutation = useMutation({
    mutationFn: async (data: InsertExpense) => {
      return await apiRequest("POST", "/api/expenses", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      queryClient.invalidateQueries({ queryKey: ['/api/substreams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/streams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      toast({
        title: "Expense added",
        description: "The expense has been recorded and budget updated.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to add expense. Please try again.",
      });
    },
  });

  const updateExpenseMutation = useMutation({
    mutationFn: async (data: { id: string; updates: Partial<InsertExpense> }) => {
      return await apiRequest("PATCH", `/api/expenses/${data.id}`, data.updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      queryClient.invalidateQueries({ queryKey: ['/api/substreams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/streams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      toast({
        title: "Expense updated",
        description: "The expense has been updated and budget recalculated.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update expense. Please try again.",
      });
    },
  });

  const deleteExpenseMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/expenses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      queryClient.invalidateQueries({ queryKey: ['/api/substreams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/streams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      toast({
        title: "Expense deleted",
        description: "The expense has been deleted and budget updated.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete expense. Please try again.",
      });
    },
  });

  const createTaskWithDependencies = async (taskData: any, dependencyIds: string[]) => {
    const createdTask = await apiRequest("POST", "/api/tasks", taskData) as any;
    
    if (dependencyIds.length > 0 && createdTask.id) {
      const createdDepIds: string[] = [];
      try {
        for (const dependsOnId of dependencyIds) {
          const dep = await apiRequest("POST", "/api/task-dependencies", {
            taskId: createdTask.id,
            dependsOnId,
          }) as any;
          if (dep?.id) createdDepIds.push(dep.id);
        }
      } catch (depError: any) {
        for (const depId of createdDepIds) {
          try {
            await apiRequest("DELETE", `/api/task-dependencies/${depId}`);
          } catch (rollbackError) {
            console.error("Failed to rollback dependency", depId, rollbackError);
          }
        }
        
        toast({
          variant: "destructive",
          title: "Dependency Error",
          description: depError.message || "Failed to create task dependencies. Task created but dependencies not added.",
        });
      }
    }
    
    return createdTask;
  };

  const createTaskMutation = useMutation({
    mutationFn: async ({ taskData, dependencyIds }: { taskData: any; dependencyIds: string[] }) => {
      return await createTaskWithDependencies(taskData, dependencyIds);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id, 'dependencies'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      queryClient.invalidateQueries({ queryKey: ['/api/substreams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/streams'] });
      toast({
        title: "Task created",
        description: "The task has been created successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create task. Please try again.",
      });
    },
  });

  return (
    <div className="space-y-6">
      {/* Project header */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-3">
                <FolderKanban className="h-6 w-6 text-primary" />
                <CardTitle className="text-2xl">{project.name}</CardTitle>
              </div>
              <CardDescription className="mt-2">
                {project.description}
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              {onEdit && project.id && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onEdit}
                  data-testid="button-edit-project"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Project
                </Button>
              )}
              <Badge variant={statusVariant} data-testid="badge-status">
                {project.status}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-3">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CalendarIcon className="h-4 w-4" />
                <span>Timeline</span>
              </div>
              <p className="text-sm font-medium">
                {project.startDate ? format(new Date(project.startDate), 'MMM d, yyyy') : 'Not set'} - {project.endDate ? format(new Date(project.endDate), 'MMM d, yyyy') : 'Not set'}
              </p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Users className="h-4 w-4" />
                <span>Stakeholders</span>
              </div>
              <p className="text-sm font-medium">{stakeholders.length} involved</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Overall Progress</p>
              <div className="space-y-2">
                <Progress value={project.progress} className="h-2" />
                <p className="text-sm font-mono font-medium">{project.progress}%</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabbed content */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-11">
          <TabsTrigger value="overview" data-testid="tab-overview">
            Overview
          </TabsTrigger>
          <TabsTrigger value="schedule" data-testid="tab-schedule">
            <Calendar className="h-4 w-4 mr-2" />
            Schedule
          </TabsTrigger>
          <TabsTrigger value="milestones" data-testid="tab-milestones">
            <CalendarIcon className="h-4 w-4 mr-2" />
            Milestones
          </TabsTrigger>
          <TabsTrigger value="tasks" data-testid="tab-tasks">
            Tasks
          </TabsTrigger>
          <TabsTrigger value="raid" data-testid="tab-raid">
            <AlertTriangle className="h-4 w-4 mr-2" />
            RAID Log
          </TabsTrigger>
          <TabsTrigger value="benefits" data-testid="tab-benefits">
            Benefits
          </TabsTrigger>
          <TabsTrigger value="expenses" data-testid="tab-expenses">
            <DollarSign className="h-4 w-4 mr-2" />
            Expenses
          </TabsTrigger>
          <TabsTrigger value="budget" data-testid="tab-budget">
            <FolderKanban className="h-4 w-4 mr-2" />
            Budget
          </TabsTrigger>
          <TabsTrigger value="documents" data-testid="tab-documents">
            <FileText className="h-4 w-4 mr-2" />
            Documents
          </TabsTrigger>
          <TabsTrigger value="stakeholders" data-testid="tab-stakeholders">
            <Users className="h-4 w-4 mr-2" />
            Stakeholders
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Business Case</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {project.businessCase ? (
                <div>
                  <h4 className="text-sm font-medium mb-2">Business Case</h4>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                    {project.businessCase}
                  </p>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">No business case defined yet</p>
              )}
              {project.expectedBenefits ? (
                <div>
                  <h4 className="text-sm font-medium mb-2">Expected Benefits</h4>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                    {project.expectedBenefits}
                  </p>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">No expected benefits defined yet</p>
              )}
              {project.budget && (
                <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                  <div>
                    <h4 className="text-sm font-medium mb-1">Budget</h4>
                    <p className="text-sm text-muted-foreground">${Number(project.budget).toLocaleString()}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium mb-1">Spent</h4>
                    <p className="text-sm text-muted-foreground">${Number(project.spent || 0).toLocaleString()}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedule" className="mt-6">
          <GanttChart tasks={tasks} title="Project Timeline" />
        </TabsContent>

        <TabsContent value="milestones" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2">
              <div>
                <CardTitle>Project Milestones</CardTitle>
                <CardDescription>Track key project deliverables and deadlines</CardDescription>
              </div>
              {onCreateMilestone && (
                <CreateMilestoneDialog
                  projectId={project.id}
                  onSubmit={onCreateMilestone}
                />
              )}
            </CardHeader>
            <CardContent>
              {milestones.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No milestones yet. Add a milestone to track project checkpoints.
                </div>
              ) : (
                <div className="space-y-4">
                  {milestones.map((milestone) => {
                    const isOverdue = milestone.status !== 'Completed' && 
                      new Date(milestone.dueDate) < new Date();
                    const isCompleted = milestone.status === 'Completed';
                    
                    return (
                      <div
                        key={milestone.id}
                        className="flex items-start gap-4 p-4 border rounded-md hover-elevate"
                        data-testid={`milestone-${milestone.id}`}
                      >
                        <div className="flex-1 space-y-2">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1">
                              <h4 className="font-medium">{milestone.name}</h4>
                              {milestone.description && (
                                <p className="text-sm text-muted-foreground mt-1">
                                  {milestone.description}
                                </p>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge
                                variant={
                                  isCompleted ? 'outline' :
                                  isOverdue ? 'destructive' :
                                  milestone.status === 'In Progress' ? 'default' :
                                  'secondary'
                                }
                                data-testid={`badge-milestone-status-${milestone.id}`}
                              >
                                {milestone.status}
                              </Badge>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => handleMilestoneEdit(milestone)}
                                data-testid={`button-edit-milestone-${milestone.id}`}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => handleMilestoneDelete(milestone.id)}
                                disabled={deleteMilestoneMutation.isPending}
                                data-testid={`button-delete-milestone-${milestone.id}`}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <CalendarIcon className="h-4 w-4" />
                              <span>Due: {format(new Date(milestone.dueDate), 'MMM d, yyyy')}</span>
                            </div>
                            {milestone.completedDate && (
                              <div className="flex items-center gap-1">
                                <span>Completed: {format(new Date(milestone.completedDate), 'MMM d, yyyy')}</span>
                              </div>
                            )}
                            {isOverdue && !isCompleted && (
                              <Badge variant="destructive" className="text-xs">
                                Overdue
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
          <MilestoneDialog
            projectId={project.id}
            milestone={selectedMilestone}
            milestones={milestones}
            open={editMilestoneDialogOpen}
            onOpenChange={setEditMilestoneDialogOpen}
            mode="edit"
            onSubmit={(updates, dependencyIds, existingDependencyIds) => {
              if (selectedMilestone) {
                updateMilestoneMutation.mutate({
                  milestoneId: selectedMilestone.id,
                  updates,
                  dependencyIds: dependencyIds || [],
                  existingDependencyIds: existingDependencyIds || [],
                });
              }
            }}
            isPending={updateMilestoneMutation.isPending}
          />
        </TabsContent>

        <TabsContent value="tasks" className="mt-6">
          <div className="space-y-4">
            <div className="flex justify-end">
              <CreateTaskDialog
                projectId={project.id}
                milestones={milestones}
                tasks={tasks}
                onSubmit={(taskData, dependencyIds) => 
                  createTaskMutation.mutate({ taskData, dependencyIds })
                }
              />
            </div>
            <TaskTable tasks={tasks} onTaskClick={handleTaskClick} />
            <EditTaskDialog
              task={selectedTask}
              milestones={milestones}
              tasks={tasks}
              open={editDialogOpen}
              onOpenChange={setEditDialogOpen}
              onSubmit={(updates, dependencyIds, existingDependencyIds) => {
                if (selectedTask) {
                  updateTaskMutation.mutate({
                    taskId: selectedTask.id,
                    updates,
                    dependencyIds,
                    existingDependencyIds,
                  });
                }
              }}
              isPending={updateTaskMutation.isPending}
            />
          </div>
        </TabsContent>

        <TabsContent value="raid" className="mt-6">
          <RAIDLog
            projectId={project.id}
            {...raid}
            onCreateRaid={(data) => createRaidMutation.mutate(data)}
            onUpdateRaid={(id, updates) => updateRaidMutation.mutate({ id, updates })}
            isCreating={createRaidMutation.isPending}
            isUpdating={updateRaidMutation.isPending}
          />
        </TabsContent>

        <TabsContent value="documents" className="mt-6">
          <DocumentManager
            projectId={project.id}
            documents={documents}
            onCreateDocument={(data) => createDocumentMutation.mutate(data)}
            isCreating={createDocumentMutation.isPending}
          />
        </TabsContent>

        <TabsContent value="benefits" className="mt-6">
          <BenefitsGrid
            projectId={project.id}
            benefits={benefits}
            onCreateBenefit={(data) => createBenefitMutation.mutate(data)}
            isCreating={createBenefitMutation.isPending}
          />
        </TabsContent>

        <TabsContent value="expenses" className="mt-6">
          <ExpensesGrid
            projectId={project.id}
            expenses={expenses}
            onCreateExpense={(data) => createExpenseMutation.mutate(data)}
            onUpdateExpense={(id, updates) => updateExpenseMutation.mutate({ id, updates })}
            onDeleteExpense={(id) => deleteExpenseMutation.mutate(id)}
            isCreating={createExpenseMutation.isPending}
            isUpdating={updateExpenseMutation.isPending}
            isDeleting={deleteExpenseMutation.isPending}
          />
        </TabsContent>

        <TabsContent value="budget" className="mt-6">
          <BudgetLinesGrid projectId={project.id} budgetLines={budgetLines} expenses={expenses} />
        </TabsContent>

        <TabsContent value="stakeholders" className="mt-6">
          <StakeholderGrid
            projectId={project.id}
            stakeholders={stakeholders}
            onCreateStakeholder={(data) => createStakeholderMutation.mutate(data)}
            isCreating={createStakeholderMutation.isPending}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
