import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { useState } from "react";

interface ProgressIndicatorProps {
  progress: number;
  onUpdate?: (newProgress: number) => void;
  editable?: boolean;
  size?: "sm" | "md" | "lg";
}

export function ProgressIndicator({
  progress,
  onUpdate,
  editable = false,
  size = "md",
}: ProgressIndicatorProps) {
  const [open, setOpen] = useState(false);
  const [tempProgress, setTempProgress] = useState(progress);

  const handleSave = () => {
    onUpdate?.(tempProgress);
    setOpen(false);
  };

  const sizeClasses = {
    sm: "text-base",
    md: "text-xl",
    lg: "text-2xl",
  };

  const progressContent = (
    <span
      className={`${sizeClasses[size]} font-mono font-bold`}
      data-testid="text-progress"
    >
      {progress}%
    </span>
  );

  if (!editable) {
    return progressContent;
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          className="h-auto p-1 hover-elevate"
          data-testid="button-update-progress"
        >
          {progressContent}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Update Progress</DialogTitle>
          <DialogDescription>
            Adjust the progress percentage for this item.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="progress-slider">Progress: {tempProgress}%</Label>
            <Slider
              id="progress-slider"
              value={[tempProgress]}
              onValueChange={(value) => setTempProgress(value[0])}
              max={100}
              step={1}
              data-testid="slider-progress"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="progress-input">Or enter manually</Label>
            <Input
              id="progress-input"
              type="number"
              min={0}
              max={100}
              value={tempProgress}
              onChange={(e) => setTempProgress(Number(e.target.value))}
              data-testid="input-progress"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} data-testid="button-cancel">
            Cancel
          </Button>
          <Button onClick={handleSave} data-testid="button-save">
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
