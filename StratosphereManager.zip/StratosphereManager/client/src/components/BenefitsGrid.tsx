import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Calendar, Target, DollarSign, ChartLine, Zap, Star, Heart, Crosshair, BarChart3 } from "lucide-react";
import { BenefitDialog } from "./BenefitDialog";
import type { Benefit } from "@shared/schema";
import { format } from "date-fns";

interface BenefitsGridProps {
  projectId: string;
  benefits: Benefit[];
  onCreateBenefit?: (data: any) => void;
  isCreating?: boolean;
}

const statusConfig = {
  "Planned": { variant: "outline" as const, label: "Planned" },
  "In Progress": { variant: "secondary" as const, label: "In Progress" },
  "Achieved": { variant: "default" as const, label: "Achieved" },
  "Not Achieved": { variant: "destructive" as const, label: "Not Achieved" },
};

const CategoryIcon = ({ category }: { category: string }) => {
  const iconClass = "h-5 w-5 text-muted-foreground";
  switch (category) {
    case "Cost Savings":
      return <DollarSign className={iconClass} />;
    case "Revenue Growth":
      return <ChartLine className={iconClass} />;
    case "Efficiency":
      return <Zap className={iconClass} />;
    case "Quality":
      return <Star className={iconClass} />;
    case "Customer Satisfaction":
      return <Heart className={iconClass} />;
    case "Strategic":
      return <Crosshair className={iconClass} />;
    default:
      return <BarChart3 className={iconClass} />;
  }
};

export function BenefitsGrid({ projectId, benefits, onCreateBenefit, isCreating }: BenefitsGridProps) {
  return (
    <div className="space-y-6">
      {onCreateBenefit && (
        <div className="flex justify-end">
          <BenefitDialog
            projectId={projectId}
            onSubmit={onCreateBenefit}
            isPending={isCreating}
            mode="create"
          />
        </div>
      )}
      {benefits.length === 0 ? (
        <Card>
          <CardContent className="py-12">
            <p className="text-sm text-muted-foreground text-center">No benefits tracked yet</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {benefits.map((benefit) => (
            <Card key={benefit.id} data-testid={`card-benefit-${benefit.id}`} className="hover-elevate">
              <CardHeader>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <CategoryIcon category={benefit.category} />
                      <Badge variant="outline" className="text-xs">
                        {benefit.type}
                      </Badge>
                    </div>
                    <CardTitle className="text-base">{benefit.name}</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  <Badge 
                    variant={statusConfig[benefit.status as keyof typeof statusConfig]?.variant || "outline"}
                    className="text-xs"
                  >
                    {benefit.status}
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    {benefit.category}
                  </Badge>
                </div>

                {benefit.description && (
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {benefit.description}
                  </p>
                )}

                {benefit.type === "Quantitative" && (benefit.targetValue || benefit.unit) && (
                  <div className="flex items-center gap-2 text-sm">
                    <Target className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">
                      Target: {benefit.targetValue || "N/A"} {benefit.unit || ""}
                    </span>
                  </div>
                )}

                {benefit.achievementDate && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">
                      {format(new Date(benefit.achievementDate), "MMM d, yyyy")}
                    </span>
                  </div>
                )}

                {benefit.notes && benefit.type === "Qualitative" && (
                  <div className="space-y-1">
                    <h4 className="text-sm font-medium">Notes</h4>
                    <p className="text-sm text-muted-foreground line-clamp-3">{benefit.notes}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
