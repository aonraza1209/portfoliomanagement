import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DollarSign } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertExpenseSchema, type InsertExpense, type Expense } from "@shared/schema";
import { z } from "zod";

const updateExpenseSchema = insertExpenseSchema.partial().omit({ projectId: true });
type UpdateExpense = z.infer<typeof updateExpenseSchema>;

interface ExpenseDialogProps {
  projectId: string;
  expense?: Expense | null;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  onSubmit: (data: InsertExpense | UpdateExpense) => void;
  isPending?: boolean;
  mode?: "create" | "edit";
}

const EXPENSE_CATEGORIES = [
  "Labor",
  "Materials",
  "Software",
  "Hardware",
  "Travel",
  "Training",
  "Consulting",
  "Licensing",
  "Infrastructure",
  "Other",
];

export function ExpenseDialog({
  projectId,
  expense,
  open: externalOpen,
  onOpenChange: externalOnOpenChange,
  onSubmit,
  isPending,
  mode = "create",
}: ExpenseDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);

  const open = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = externalOnOpenChange || setInternalOpen;

  const formSchema = mode === "create" ? insertExpenseSchema : updateExpenseSchema;
  
  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      projectId: mode === "create" ? projectId : undefined,
      category: "Labor",
      amount: "",
      date: "",
      description: "",
    },
  });

  useEffect(() => {
    if (expense && mode === "edit") {
      const dateValue = expense.date ? (expense.date instanceof Date ? expense.date : new Date(expense.date)).toISOString().split('T')[0] : "";
      form.reset({
        category: expense.category,
        amount: expense.amount?.toString() || "",
        date: dateValue,
        description: expense.description || "",
      });
    } else if (mode === "create") {
      form.reset({
        projectId,
        category: "Labor",
        amount: "",
        date: "",
        description: "",
      });
    }
  }, [expense, mode, projectId, form]);

  const handleSubmit = (data: any) => {
    onSubmit(data);
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!isPending) {
      setOpen(newOpen);
      if (!newOpen) {
        form.reset();
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      {mode === "create" && (
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" data-testid="button-create-expense">
            <DollarSign className="h-4 w-4 mr-2" />
            Add Expense
          </Button>
        </DialogTrigger>
      )}
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Add Expense" : "Edit Expense"}</DialogTitle>
          <DialogDescription>
            {mode === "create" 
              ? "Record a new expense for this project. Budget totals will update automatically."
              : "Update expense details. Budget totals will recalculate automatically."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-expense-category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {EXPENSE_CATEGORIES.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      {...field}
                      data-testid="input-expense-amount"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Date</FormLabel>
                  <FormControl>
                    <Input
                      type="date"
                      {...field}
                      value={field.value as string || ""}
                      data-testid="input-expense-date"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description (Optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Expense details..."
                      className="resize-none"
                      {...field}
                      data-testid="textarea-expense-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={isPending}
                data-testid="button-cancel-expense"
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isPending} data-testid="button-submit-expense">
                {isPending ? "Saving..." : mode === "create" ? "Add Expense" : "Update Expense"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
