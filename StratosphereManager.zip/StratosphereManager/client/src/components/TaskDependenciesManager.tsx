import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Plus, ArrowRight, AlertTriangle } from "lucide-react";
import type { Task, TaskDependency } from "@shared/schema";

interface TaskDependenciesManagerProps {
  projectId: string;
}

export function TaskDependenciesManager({ projectId }: TaskDependenciesManagerProps) {
  const { toast } = useToast();
  const [selectedTaskId, setSelectedTaskId] = useState<string>("");
  const [selectedDependsOnId, setSelectedDependsOnId] = useState<string>("");

  const { data: tasks = [], isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ["/api/projects", projectId, "tasks"],
    queryFn: async () => {
      const response = await fetch(`/api/projects/${projectId}/tasks`);
      if (!response.ok) throw new Error('Failed to fetch tasks');
      return response.json();
    },
    enabled: !!projectId,
  });

  const { data: allDependencies = [], isLoading: depsLoading } = useQuery<TaskDependency[]>({
    queryKey: ["/api/projects", projectId, "dependencies"],
    queryFn: async () => {
      const response = await fetch(`/api/projects/${projectId}/dependencies`);
      if (!response.ok) throw new Error('Failed to fetch dependencies');
      return response.json();
    },
    enabled: !!projectId,
  });

  const createDependencyMutation = useMutation({
    mutationFn: async (data: { taskId: string; dependsOnId: string }) => {
      return await apiRequest("/api/task-dependencies", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "dependencies"] });
      toast({
        title: "Success",
        description: "Task dependency created successfully",
      });
      setSelectedTaskId("");
      setSelectedDependsOnId("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create dependency",
        variant: "destructive",
      });
    },
  });

  const deleteDependencyMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest(`/api/task-dependencies/${id}`, "DELETE");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "dependencies"] });
      toast({
        title: "Success",
        description: "Dependency removed successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to remove dependency",
        variant: "destructive",
      });
    },
  });

  const handleAddDependency = () => {
    if (!selectedTaskId || !selectedDependsOnId) {
      toast({
        title: "Error",
        description: "Please select both tasks",
        variant: "destructive",
      });
      return;
    }
    createDependencyMutation.mutate({ taskId: selectedTaskId, dependsOnId: selectedDependsOnId });
  };

  const getTaskName = (taskId: string) => {
    return tasks.find(t => t.id === taskId)?.name || "Unknown Task";
  };

  if (tasksLoading) {
    return <div className="text-sm text-muted-foreground">Loading tasks...</div>;
  }

  if (tasks.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <AlertTriangle className="h-4 w-4" />
            <span>No tasks available. Create tasks first to manage dependencies.</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Add Task Dependency</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <label className="text-sm font-medium mb-2 block">Task</label>
              <Select value={selectedTaskId} onValueChange={setSelectedTaskId}>
                <SelectTrigger data-testid="select-task">
                  <SelectValue placeholder="Select task" />
                </SelectTrigger>
                <SelectContent data-testid="select-content-task">
                  {tasks.map((task) => (
                    <SelectItem key={task.id} value={task.id} data-testid={`select-item-task-${task.id}`}>
                      {task.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="pt-6">
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
            </div>

            <div className="flex-1">
              <label className="text-sm font-medium mb-2 block">Depends On</label>
              <Select value={selectedDependsOnId} onValueChange={setSelectedDependsOnId}>
                <SelectTrigger data-testid="select-depends-on">
                  <SelectValue placeholder="Select dependency" />
                </SelectTrigger>
                <SelectContent data-testid="select-content-depends-on">
                  {tasks
                    .filter(t => t.id !== selectedTaskId)
                    .map((task) => (
                      <SelectItem key={task.id} value={task.id} data-testid={`select-item-depends-on-${task.id}`}>
                        {task.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>

            <div className="pt-6">
              <Button
                onClick={handleAddDependency}
                disabled={!selectedTaskId || !selectedDependsOnId || createDependencyMutation.isPending}
                size="default"
                data-testid="button-add-dependency"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Existing Dependencies</CardTitle>
        </CardHeader>
        <CardContent>
          {depsLoading ? (
            <div className="text-sm text-muted-foreground">Loading dependencies...</div>
          ) : allDependencies.length === 0 ? (
            <div className="text-sm text-muted-foreground">No dependencies defined yet</div>
          ) : (
            <div className="space-y-2">
              {allDependencies.map((dep) => (
                <div
                  key={dep.id}
                  className="flex items-center justify-between p-3 rounded-md border hover-elevate"
                  data-testid={`dependency-${dep.id}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium">{getTaskName(dep.taskId)}</span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">depends on</span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{getTaskName(dep.dependsOnId)}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteDependencyMutation.mutate(dep.id)}
                    disabled={deleteDependencyMutation.isPending}
                    data-testid={`button-delete-dependency-${dep.id}`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
