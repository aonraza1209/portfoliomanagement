import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon, FlagIcon } from "lucide-react";
import { format } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMilestoneSchema, type InsertMilestone, type Milestone, type MilestoneDependency } from "@shared/schema";
import { z } from "zod";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const updateMilestoneSchema = insertMilestoneSchema.partial().omit({ projectId: true }).extend({
  selectedDependencies: z.array(z.string()).optional().default([]),
});
type UpdateMilestone = z.infer<typeof updateMilestoneSchema>;

interface MilestoneDialogProps {
  projectId: string;
  milestone?: Milestone | null;
  milestones?: Milestone[];
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  onSubmit: (data: InsertMilestone | UpdateMilestone, dependencyIds?: string[], existingDependencyIds?: string[]) => void;
  isPending?: boolean;
  mode?: "create" | "edit";
}

export function MilestoneDialog({
  projectId,
  milestone,
  milestones = [],
  open: externalOpen,
  onOpenChange: externalOnOpenChange,
  onSubmit,
  isPending,
  mode = "create",
}: MilestoneDialogProps) {
  const { toast } = useToast();
  const [internalOpen, setInternalOpen] = useState(false);

  const open = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = externalOnOpenChange || setInternalOpen;

  const { data: existingDependencies = [], isLoading: isDependenciesLoading, isError: isDependenciesError } = useQuery<MilestoneDependency[]>({
    queryKey: milestone?.id ? ["/api/milestones", milestone.id, "dependencies"] : ["disabled"],
    queryFn: async () => {
      if (!milestone?.id) return [];
      const res = await apiRequest("GET", `/api/milestones/${milestone.id}/dependencies`);
      return await res.json() as MilestoneDependency[];
    },
    enabled: !!milestone?.id && open && mode === "edit",
    retry: 2,
  });

  const form = useForm<InsertMilestone | UpdateMilestone>({
    resolver: zodResolver(mode === "create" ? insertMilestoneSchema : updateMilestoneSchema),
    defaultValues: {
      projectId: mode === "create" ? projectId : undefined,
      name: "",
      description: "",
      dueDate: undefined,
      status: "Pending",
      selectedDependencies: [],
    },
  });

  useEffect(() => {
    if (milestone && mode === "edit" && !isDependenciesLoading) {
      const depIds = existingDependencies.map(dep => dep.dependsOnId);
      form.reset({
        name: milestone.name,
        description: milestone.description || "",
        dueDate: milestone.dueDate,
        status: milestone.status,
        selectedDependencies: depIds,
      });
    } else if (mode === "create") {
      form.reset({
        projectId,
        name: "",
        description: "",
        dueDate: undefined,
        status: "Pending",
        selectedDependencies: [],
      });
    }
  }, [milestone, mode, projectId, existingDependencies, isDependenciesLoading, form]);

  const handleSubmit = (data: InsertMilestone | UpdateMilestone) => {
    if (isDependenciesError && mode === "edit") {
      toast({
        variant: "destructive",
        title: "Cannot Update Milestone",
        description: "Failed to load current dependencies. Please close and try again.",
      });
      return;
    }
    
    if (mode === "edit") {
      const updateData = data as UpdateMilestone;
      const { selectedDependencies, ...rest } = updateData;
      const existingDepIds = existingDependencies.map(dep => dep.dependsOnId);
      onSubmit(rest as any, selectedDependencies || [], existingDepIds);
    } else {
      onSubmit(data);
    }
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!isPending) {
      setOpen(newOpen);
      if (!newOpen) {
        form.reset();
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      {mode === "create" && (
        <DialogTrigger asChild>
          <Button data-testid="button-add-milestone">
            <FlagIcon className="h-4 w-4 mr-2" />
            Add Milestone
          </Button>
        </DialogTrigger>
      )}
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{mode === "edit" ? "Edit Milestone" : "Add Milestone"}</DialogTitle>
          <DialogDescription>
            {mode === "edit"
              ? "Update milestone information"
              : "Add a new milestone to the project"}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Milestone Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter milestone name"
                      {...field}
                      data-testid="input-milestone-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description (optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe the milestone"
                      {...field}
                      value={field.value || ""}
                      data-testid="input-milestone-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Due Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className="justify-start text-left font-normal"
                            data-testid="button-milestone-date"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {field.value ? format(new Date(field.value), "PPP") : <span>Pick a date</span>}
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value ? new Date(field.value) : undefined}
                          onSelect={(date) => field.onChange(date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value}
                      data-testid="select-milestone-status"
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Pending">Pending</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Completed">Completed</SelectItem>
                        <SelectItem value="Delayed">Delayed</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {mode === "edit" && (
              <FormField
                control={form.control}
                name="selectedDependencies"
                render={() => (
                  <FormItem>
                    <FormLabel>Dependencies (Optional)</FormLabel>
                    <FormDescription className="text-sm text-muted-foreground">
                      Select milestones that must be completed before this milestone can start
                    </FormDescription>
                    <div className="space-y-2 max-h-40 overflow-y-auto border rounded-md p-3">
                      {milestones.filter(m => m.id !== milestone?.id).length === 0 ? (
                        <p className="text-sm text-muted-foreground">No other milestones available</p>
                      ) : (
                        milestones.filter(m => m.id !== milestone?.id).map((availableMilestone) => (
                          <FormField
                            key={availableMilestone.id}
                            control={form.control}
                            name="selectedDependencies"
                            render={({ field }) => {
                              return (
                                <FormItem
                                  key={availableMilestone.id}
                                  className="flex flex-row items-start space-x-3 space-y-0"
                                >
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(availableMilestone.id)}
                                      onCheckedChange={(checked) => {
                                        return checked
                                          ? field.onChange([...field.value, availableMilestone.id])
                                          : field.onChange(
                                              field.value?.filter(
                                                (value) => value !== availableMilestone.id
                                              )
                                            );
                                      }}
                                      data-testid={`checkbox-dependency-${availableMilestone.id}`}
                                    />
                                  </FormControl>
                                  <FormLabel className="text-sm font-normal cursor-pointer">
                                    {availableMilestone.name}
                                  </FormLabel>
                                </FormItem>
                              );
                            }}
                          />
                        ))
                      )}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={isPending}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={isPending || (mode === "edit" && (isDependenciesLoading || isDependenciesError))} 
                data-testid="button-save-milestone"
              >
                {isPending ? "Saving..." : isDependenciesLoading ? "Loading..." : isDependenciesError ? "Error Loading Dependencies" : mode === "edit" ? "Save Changes" : "Add Milestone"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
