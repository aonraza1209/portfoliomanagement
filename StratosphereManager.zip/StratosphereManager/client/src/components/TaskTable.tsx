import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, ArrowUpCircle, MinusCircle } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

type Priority = "high" | "medium" | "low";
type Status = "not-started" | "in-progress" | "completed" | "delayed";

interface Task {
  id: string;
  name: string;
  priority: Priority;
  assignee: string;
  startDate: string;
  endDate: string;
  duration: number;
  dependencies: string[];
  progress: number;
  status: Status;
  isCriticalPath?: boolean;
}

interface TaskTableProps {
  tasks: Task[];
  onTaskClick?: (taskId: string) => void;
}

const priorityConfig = {
  high: {
    icon: AlertCircle,
    label: "High",
    variant: "destructive" as const,
  },
  medium: {
    icon: ArrowUpCircle,
    label: "Medium",
    variant: "secondary" as const,
  },
  low: {
    icon: MinusCircle,
    label: "Low",
    variant: "outline" as const,
  },
};

const statusConfig = {
  "not-started": { label: "Not Started", variant: "outline" as const },
  "in-progress": { label: "In Progress", variant: "default" as const },
  completed: { label: "Completed", variant: "secondary" as const },
  delayed: { label: "Delayed", variant: "destructive" as const },
};

export function TaskTable({ tasks, onTaskClick }: TaskTableProps) {
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Task Name</TableHead>
            <TableHead>Priority</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Assignee</TableHead>
            <TableHead>Start Date</TableHead>
            <TableHead>End Date</TableHead>
            <TableHead>Duration</TableHead>
            <TableHead>Progress</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {tasks.map((task) => {
            const priority = (task.priority?.toLowerCase() || 'medium') as Priority;
            const priorityInfo = priorityConfig[priority] || priorityConfig.medium;
            const PriorityIcon = priorityInfo.icon;
            return (
              <TableRow
                key={task.id}
                className={`hover-elevate cursor-pointer ${task.isCriticalPath ? 'bg-accent/30' : ''}`}
                onClick={() => onTaskClick?.(task.id)}
                data-testid={`row-task-${task.id}`}
              >
                <TableCell className="font-medium">
                  <div className="flex items-center gap-2">
                    {task.name}
                    {task.isCriticalPath && (
                      <Badge variant="secondary" className="text-xs">
                        Critical Path
                      </Badge>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge
                    variant={priorityInfo.variant}
                    className="flex items-center gap-1 w-fit"
                    data-testid={`badge-priority-${task.id}`}
                  >
                    <PriorityIcon className="h-3 w-3" />
                    {priorityInfo.label}
                  </Badge>
                </TableCell>
                <TableCell>
                  {task.status && statusConfig[task.status as Status] ? (
                    <Badge variant={statusConfig[task.status as Status].variant} data-testid={`badge-status-${task.id}`}>
                      {statusConfig[task.status as Status].label}
                    </Badge>
                  ) : (
                    <Badge variant="outline" data-testid={`badge-status-${task.id}`}>
                      {task.status || 'Unknown'}
                    </Badge>
                  )}
                </TableCell>
                <TableCell>
                  {task.assignee ? (
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarFallback className="text-xs">
                          {task.assignee.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{task.assignee}</span>
                    </div>
                  ) : (
                    <span className="text-sm text-muted-foreground">Unassigned</span>
                  )}
                </TableCell>
                <TableCell className="font-mono text-xs">{task.startDate}</TableCell>
                <TableCell className="font-mono text-xs">{task.endDate}</TableCell>
                <TableCell className="font-mono text-xs">{task.duration}d</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Progress value={task.progress} className="h-2 flex-1" />
                    <span className="font-mono text-xs w-10 text-right" data-testid={`text-progress-${task.id}`}>
                      {task.progress}%
                    </span>
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
