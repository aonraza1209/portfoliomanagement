import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format, eachDayOfInterval, startOfWeek, endOfWeek, isSameDay, parseISO } from "date-fns";

interface GanttTask {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  progress: number;
  isCriticalPath?: boolean;
  dependencies?: string[];
}

interface GanttChartProps {
  tasks: GanttTask[];
  title?: string;
}

export function GanttChart({ tasks, title = "Project Schedule" }: GanttChartProps) {
  if (tasks.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No tasks to display</p>
        </CardContent>
      </Card>
    );
  }

  const allDates = tasks.flatMap(task => [parseISO(task.startDate), parseISO(task.endDate)]);
  const minDate = new Date(Math.min(...allDates.map(d => d.getTime())));
  const maxDate = new Date(Math.max(...allDates.map(d => d.getTime())));
  
  const startDate = startOfWeek(minDate);
  const endDate = endOfWeek(maxDate);
  const days = eachDayOfInterval({ start: startDate, end: endDate });
  
  const today = new Date();

  const calculatePosition = (taskStartDate: string, taskEndDate: string) => {
    const start = parseISO(taskStartDate);
    const end = parseISO(taskEndDate);
    
    const startIndex = days.findIndex(day => isSameDay(day, start));
    const endIndex = days.findIndex(day => isSameDay(day, end));
    
    const left = (startIndex / days.length) * 100;
    const width = ((endIndex - startIndex + 1) / days.length) * 100;
    
    return { left: `${left}%`, width: `${width}%` };
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <div className="min-w-[800px]">
            {/* Timeline header */}
            <div className="flex border-b pb-2 mb-4">
              <div className="w-48 flex-shrink-0"></div>
              <div className="flex-1 flex">
                {days.map((day, idx) => {
                  const isToday = isSameDay(day, today);
                  return (
                    <div
                      key={idx}
                      className={`flex-1 text-center text-xs ${
                        isToday ? 'font-bold text-primary' : 'text-muted-foreground'
                      }`}
                    >
                      {format(day, 'd')}
                      {idx % 7 === 0 && (
                        <div className="font-medium">{format(day, 'MMM')}</div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Task rows */}
            <div className="space-y-3">
              {tasks.map((task) => {
                const position = calculatePosition(task.startDate, task.endDate);
                const todayIndex = days.findIndex(day => isSameDay(day, today));
                const todayPosition = (todayIndex / days.length) * 100;

                return (
                  <div key={task.id} className="flex items-center" data-testid={`gantt-task-${task.id}`}>
                    <div className="w-48 flex-shrink-0 pr-4">
                      <div className="flex items-center gap-2">
                        <span className="text-sm truncate">{task.name}</span>
                        {task.isCriticalPath && (
                          <Badge variant="secondary" className="text-xs">CP</Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex-1 relative h-8">
                      {/* Grid background */}
                      <div className="absolute inset-0 flex">
                        {days.map((_, idx) => (
                          <div
                            key={idx}
                            className="flex-1 border-l border-border/50"
                          />
                        ))}
                      </div>

                      {/* Today indicator */}
                      {todayIndex >= 0 && (
                        <div
                          className="absolute top-0 bottom-0 w-0.5 bg-primary z-10"
                          style={{ left: `${todayPosition}%` }}
                        />
                      )}

                      {/* Task bar */}
                      <div
                        className="absolute top-1 bottom-1 rounded"
                        style={position}
                      >
                        <div
                          className={`h-full rounded ${
                            task.isCriticalPath
                              ? 'bg-primary'
                              : 'bg-secondary'
                          } relative overflow-hidden`}
                        >
                          {/* Progress fill */}
                          <div
                            className={`h-full ${
                              task.isCriticalPath
                                ? 'bg-primary/60'
                                : 'bg-muted'
                            }`}
                            style={{ width: `${task.progress}%` }}
                          />
                          {/* Progress text */}
                          <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-xs font-medium text-primary-foreground">
                              {task.progress}%
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
