import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TrendingUp } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBenefitSchema, type InsertBenefit, type Benefit } from "@shared/schema";
import { z } from "zod";
import { format } from "date-fns";

const updateBenefitSchema = insertBenefitSchema.partial().omit({ projectId: true });
type UpdateBenefit = z.infer<typeof updateBenefitSchema>;

interface BenefitDialogProps {
  projectId: string;
  benefit?: Benefit | null;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  onSubmit: (data: InsertBenefit | UpdateBenefit) => void;
  isPending?: boolean;
  mode?: "create" | "edit";
}

export function BenefitDialog({
  projectId,
  benefit,
  open: externalOpen,
  onOpenChange: externalOnOpenChange,
  onSubmit,
  isPending,
  mode = "create",
}: BenefitDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);

  const open = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = externalOnOpenChange || setInternalOpen;

  const form = useForm<InsertBenefit | UpdateBenefit>({
    resolver: zodResolver(mode === "create" ? insertBenefitSchema : updateBenefitSchema),
    defaultValues: {
      projectId: mode === "create" ? projectId : undefined,
      name: "",
      description: "",
      category: "Cost Savings",
      type: "Qualitative",
      targetValue: "",
      unit: "",
      status: "Planned",
      achievementDate: undefined,
      notes: "",
    },
  });

  const selectedType = form.watch("type");

  useEffect(() => {
    if (benefit && mode === "edit") {
      form.reset({
        name: benefit.name,
        description: benefit.description || "",
        category: benefit.category,
        type: benefit.type,
        targetValue: benefit.targetValue || "",
        unit: benefit.unit || "",
        status: benefit.status,
        achievementDate: benefit.achievementDate ? new Date(benefit.achievementDate) : undefined,
        notes: benefit.notes || "",
      });
    } else if (mode === "create") {
      form.reset({
        projectId,
        name: "",
        description: "",
        category: "Cost Savings",
        type: "Qualitative",
        targetValue: "",
        unit: "",
        status: "Planned",
        achievementDate: undefined,
        notes: "",
      });
    }
  }, [benefit, mode, projectId, form]);

  const handleSubmit = (data: InsertBenefit | UpdateBenefit) => {
    onSubmit(data);
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!isPending) {
      setOpen(newOpen);
      if (!newOpen) {
        form.reset();
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      {mode === "create" && (
        <DialogTrigger asChild>
          <Button data-testid="button-add-benefit">
            <TrendingUp className="h-4 w-4 mr-2" />
            Add Benefit
          </Button>
        </DialogTrigger>
      )}
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mode === "edit" ? "Edit Benefit" : "Add Benefit"}</DialogTitle>
          <DialogDescription>
            {mode === "edit"
              ? "Update benefit details and tracking metrics."
              : "Track quantitative and qualitative benefits for this project."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Benefit Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g., Reduced operational costs"
                      data-testid="input-benefit-name"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger data-testid="select-benefit-type">
                        <SelectValue placeholder="Select benefit type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Quantitative">Quantitative</SelectItem>
                      <SelectItem value="Qualitative">Qualitative</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger data-testid="select-benefit-category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Cost Savings">Cost Savings</SelectItem>
                      <SelectItem value="Revenue Growth">Revenue Growth</SelectItem>
                      <SelectItem value="Efficiency">Efficiency</SelectItem>
                      <SelectItem value="Quality">Quality</SelectItem>
                      <SelectItem value="Customer Satisfaction">Customer Satisfaction</SelectItem>
                      <SelectItem value="Strategic">Strategic</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe the benefit in detail"
                      data-testid="textarea-benefit-description"
                      className="min-h-[80px]"
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {selectedType === "Quantitative" && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="targetValue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Target Value</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="e.g., 100000"
                            data-testid="input-benefit-target-value"
                            {...field}
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="unit"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Unit</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="e.g., USD, hours, %"
                            data-testid="input-benefit-unit"
                            {...field}
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </>
            )}

            {selectedType === "Qualitative" && (
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Additional qualitative observations and context"
                        data-testid="textarea-benefit-notes"
                        className="min-h-[80px]"
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger data-testid="select-benefit-status">
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Planned">Planned</SelectItem>
                      <SelectItem value="In Progress">In Progress</SelectItem>
                      <SelectItem value="Achieved">Achieved</SelectItem>
                      <SelectItem value="Not Achieved">Not Achieved</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="achievementDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Achievement Date</FormLabel>
                  <FormControl>
                    <Input
                      type="date"
                      data-testid="input-benefit-achievement-date"
                      value={field.value ? format(new Date(field.value), 'yyyy-MM-dd') : ''}
                      onChange={(e) => {
                        const dateValue = e.target.value ? new Date(e.target.value) : undefined;
                        field.onChange(dateValue);
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={isPending}
                data-testid="button-cancel-benefit"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isPending}
                data-testid="button-save-benefit"
              >
                {isPending ? "Saving..." : mode === "edit" ? "Update Benefit" : "Add Benefit"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
