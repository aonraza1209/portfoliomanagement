import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit } from "lucide-react";

interface StreamCardProps {
  name: string;
  description?: string;
  subStreamCount?: number;
  activeProjects?: number;
  progress?: number;
  allocatedBudget?: string | null;
  spentToDate?: string | null;
  onClick?: () => void;
  onEdit?: () => void;
}

export function StreamCard({
  name,
  description,
  subStreamCount = 0,
  activeProjects = 0,
  progress = 0,
  allocatedBudget,
  spentToDate,
  onClick,
  onEdit,
}: StreamCardProps) {
  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onEdit?.();
  };

  const allocated = allocatedBudget ? parseFloat(allocatedBudget) : 0;
  const spent = spentToDate ? parseFloat(spentToDate) : 0;
  const safeAllocated = isNaN(allocated) ? 0 : allocated;
  const safeSpent = isNaN(spent) ? 0 : spent;
  const budgetPercentage = safeAllocated > 0 ? Math.round((safeSpent / safeAllocated) * 100) : 0;

  return (
    <Card
      className="hover-elevate cursor-pointer"
      onClick={onClick}
      data-testid={`card-stream-${name.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <CardHeader>
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <CardTitle className="text-lg">{name}</CardTitle>
            {description && (
              <CardDescription className="mt-1">{description}</CardDescription>
            )}
          </div>
          <div className="flex items-center gap-2">
            {onEdit && (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleEditClick}
                data-testid="button-edit-stream"
                className="h-8 w-8"
              >
                <Edit className="h-4 w-4" />
              </Button>
            )}
            <Badge variant="secondary" data-testid="badge-progress">
              {progress}%
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-muted-foreground">Sub-Streams:</span>{" "}
            <span className="font-medium" data-testid="text-substream-count">{subStreamCount}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Projects:</span>{" "}
            <span className="font-medium" data-testid="text-project-count">{activeProjects}</span>
          </div>
        </div>

        {allocatedBudget && (
          <div className="space-y-3 pt-2 border-t">
            <div className="space-y-2">
              <div className="flex items-baseline justify-between">
                <span className="text-sm font-medium">Budget Consumption</span>
                <span className={`text-sm font-semibold ${budgetPercentage > 100 ? 'text-destructive' : budgetPercentage > 80 ? 'text-yellow-600 dark:text-yellow-500' : 'text-green-600 dark:text-green-500'}`} data-testid="text-budget-percentage">
                  {budgetPercentage}%
                </span>
              </div>
              <Progress 
                value={Math.min(budgetPercentage, 100)} 
                className={`h-2 ${budgetPercentage > 100 ? '[&>div]:bg-destructive' : budgetPercentage > 80 ? '[&>div]:bg-yellow-500' : '[&>div]:bg-green-500'}`}
                data-testid="progress-budget"
              />
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-baseline gap-1">
                  <span className="text-muted-foreground">Spent:</span>
                  <span className="font-medium" data-testid="text-spent">${safeSpent.toLocaleString()}</span>
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-muted-foreground">of</span>
                  <span className="font-medium" data-testid="text-allocated">${safeAllocated.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-2">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Progress</span>
            <span className="font-mono">{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      </CardContent>
    </Card>
  );
}
