import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, CheckCircle2, HelpCircle, Link2, Edit } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronRight } from "lucide-react";
import { useState } from "react";
import { RaidLogDialog } from "./RaidLogDialog";

type Severity = "high" | "medium" | "low";

interface RAIDItem {
  id: string;
  title: string;
  description: string;
  owner: string;
  severity: Severity;
  status: string;
  mitigation?: string;
}

interface RAIDLogProps {
  projectId: string;
  risks: RAIDItem[];
  assumptions: RAIDItem[];
  issues: RAIDItem[];
  dependencies: RAIDItem[];
  onCreateRaid?: (data: any) => void;
  onUpdateRaid?: (id: string, data: any) => void;
  isCreating?: boolean;
  isUpdating?: boolean;
}

const severityConfig = {
  high: { variant: "destructive" as const, label: "High" },
  medium: { variant: "secondary" as const, label: "Medium" },
  low: { variant: "outline" as const, label: "Low" },
};

function RAIDItemCard({
  item,
  type,
  onEdit,
}: {
  item: RAIDItem;
  type: string;
  onEdit?: () => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  
  const severity = (item.severity?.toLowerCase() || "medium") as Severity;
  const severityDisplay = severityConfig[severity] || severityConfig.medium;

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover-elevate">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <ChevronRight className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-90' : ''}`} />
                  <CardTitle className="text-base">{item.title}</CardTitle>
                </div>
                <CardDescription className="mt-1">Owner: {item.owner || "Unassigned"}</CardDescription>
              </div>
              <div className="flex gap-2">
                <Badge variant={severityDisplay.variant} data-testid={`badge-severity-${item.id}`}>
                  {severityDisplay.label}
                </Badge>
                <Badge variant="outline" data-testid={`badge-status-${item.id}`}>
                  {item.status}
                </Badge>
              </div>
            </div>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Description</h4>
              <p className="text-sm text-muted-foreground">{item.description}</p>
            </div>
            {item.mitigation && (
              <div>
                <h4 className="text-sm font-medium mb-1">Mitigation Strategy</h4>
                <p className="text-sm text-muted-foreground">{item.mitigation}</p>
              </div>
            )}
            {onEdit && (
              <div className="flex justify-end">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit();
                  }}
                  data-testid={`button-edit-${type}-${item.id}`}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              </div>
            )}
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}

export function RAIDLog({
  projectId,
  risks,
  assumptions,
  issues,
  dependencies,
  onCreateRaid,
  onUpdateRaid,
  isCreating,
  isUpdating,
}: RAIDLogProps) {
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editItem, setEditItem] = useState<RAIDItem | null>(null);
  const [editType, setEditType] = useState<"Risk" | "Assumption" | "Issue" | "Dependency">("Risk");

  const handleEdit = (item: RAIDItem, type: "Risk" | "Assumption" | "Issue" | "Dependency") => {
    setEditItem(item);
    setEditType(type);
    setEditDialogOpen(true);
  };

  return (
    <div className="space-y-4">
      <Tabs defaultValue="risks" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="risks" data-testid="tab-risks">
            <AlertTriangle className="h-4 w-4 mr-2" />
            Risks ({risks.length})
          </TabsTrigger>
          <TabsTrigger value="assumptions" data-testid="tab-assumptions">
            <HelpCircle className="h-4 w-4 mr-2" />
            Assumptions ({assumptions.length})
          </TabsTrigger>
          <TabsTrigger value="issues" data-testid="tab-issues">
            <CheckCircle2 className="h-4 w-4 mr-2" />
            Issues ({issues.length})
          </TabsTrigger>
          <TabsTrigger value="dependencies" data-testid="tab-dependencies">
            <Link2 className="h-4 w-4 mr-2" />
            Dependencies ({dependencies.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="risks" className="space-y-4 mt-6">
          <div className="flex justify-end">
            {onCreateRaid && (
              <RaidLogDialog
                projectId={projectId}
                type="Risk"
                onSubmit={onCreateRaid}
                isPending={isCreating}
                mode="create"
              />
            )}
          </div>
          {risks.length === 0 ? (
            <Card>
              <CardContent className="py-8">
                <p className="text-sm text-muted-foreground text-center">No risks identified</p>
              </CardContent>
            </Card>
          ) : (
            risks.map((risk) => (
              <RAIDItemCard
                key={risk.id}
                item={risk}
                type="risk"
                onEdit={onUpdateRaid ? () => handleEdit(risk, "Risk") : undefined}
              />
            ))
          )}
        </TabsContent>

        <TabsContent value="assumptions" className="space-y-4 mt-6">
          <div className="flex justify-end">
            {onCreateRaid && (
              <RaidLogDialog
                projectId={projectId}
                type="Assumption"
                onSubmit={onCreateRaid}
                isPending={isCreating}
                mode="create"
              />
            )}
          </div>
          {assumptions.length === 0 ? (
            <Card>
              <CardContent className="py-8">
                <p className="text-sm text-muted-foreground text-center">No assumptions documented</p>
              </CardContent>
            </Card>
          ) : (
            assumptions.map((assumption) => (
              <RAIDItemCard
                key={assumption.id}
                item={assumption}
                type="assumption"
                onEdit={onUpdateRaid ? () => handleEdit(assumption, "Assumption") : undefined}
              />
            ))
          )}
        </TabsContent>

        <TabsContent value="issues" className="space-y-4 mt-6">
          <div className="flex justify-end">
            {onCreateRaid && (
              <RaidLogDialog
                projectId={projectId}
                type="Issue"
                onSubmit={onCreateRaid}
                isPending={isCreating}
                mode="create"
              />
            )}
          </div>
          {issues.length === 0 ? (
            <Card>
              <CardContent className="py-8">
                <p className="text-sm text-muted-foreground text-center">No issues logged</p>
              </CardContent>
            </Card>
          ) : (
            issues.map((issue) => (
              <RAIDItemCard
                key={issue.id}
                item={issue}
                type="issue"
                onEdit={onUpdateRaid ? () => handleEdit(issue, "Issue") : undefined}
              />
            ))
          )}
        </TabsContent>

        <TabsContent value="dependencies" className="space-y-4 mt-6">
          <div className="flex justify-end">
            {onCreateRaid && (
              <RaidLogDialog
                projectId={projectId}
                type="Dependency"
                onSubmit={onCreateRaid}
                isPending={isCreating}
                mode="create"
              />
            )}
          </div>
          {dependencies.length === 0 ? (
            <Card>
              <CardContent className="py-8">
                <p className="text-sm text-muted-foreground text-center">No dependencies tracked</p>
              </CardContent>
            </Card>
          ) : (
            dependencies.map((dependency) => (
              <RAIDItemCard
                key={dependency.id}
                item={dependency}
                type="dependency"
                onEdit={onUpdateRaid ? () => handleEdit(dependency, "Dependency") : undefined}
              />
            ))
          )}
        </TabsContent>
      </Tabs>

      {editItem && onUpdateRaid && (
        <RaidLogDialog
          projectId={projectId}
          type={editType}
          raidLog={editItem as any}
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          onSubmit={(data) => onUpdateRaid(editItem.id, data)}
          isPending={isUpdating}
          mode="edit"
        />
      )}
    </div>
  );
}
