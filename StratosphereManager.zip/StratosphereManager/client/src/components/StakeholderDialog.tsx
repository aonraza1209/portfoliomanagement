import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { UserPlus } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertStakeholderSchema, type InsertStakeholder, type Stakeholder } from "@shared/schema";
import { z } from "zod";

const updateStakeholderSchema = insertStakeholderSchema.partial().omit({ projectId: true });
type UpdateStakeholder = z.infer<typeof updateStakeholderSchema>;

interface StakeholderDialogProps {
  projectId: string;
  stakeholder?: Stakeholder | null;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  onSubmit: (data: InsertStakeholder | UpdateStakeholder) => void;
  isPending?: boolean;
  mode?: "create" | "edit";
}

export function StakeholderDialog({
  projectId,
  stakeholder,
  open: externalOpen,
  onOpenChange: externalOnOpenChange,
  onSubmit,
  isPending,
  mode = "create",
}: StakeholderDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);

  const open = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = externalOnOpenChange || setInternalOpen;

  const form = useForm<InsertStakeholder | UpdateStakeholder>({
    resolver: zodResolver(mode === "create" ? insertStakeholderSchema : updateStakeholderSchema),
    defaultValues: {
      projectId: mode === "create" ? projectId : undefined,
      name: "",
      role: "",
      email: "",
      influence: "Medium",
      interest: "Medium",
      engagementStrategy: "",
    },
  });

  useEffect(() => {
    if (stakeholder && mode === "edit") {
      form.reset({
        name: stakeholder.name,
        role: stakeholder.role,
        email: stakeholder.email || "",
        influence: stakeholder.influence,
        interest: stakeholder.interest,
        engagementStrategy: stakeholder.engagementStrategy || "",
      });
    } else if (mode === "create") {
      form.reset({
        projectId,
        name: "",
        role: "",
        email: "",
        influence: "Medium",
        interest: "Medium",
        engagementStrategy: "",
      });
    }
  }, [stakeholder, mode, projectId, form]);

  const handleSubmit = (data: InsertStakeholder | UpdateStakeholder) => {
    onSubmit(data);
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!isPending) {
      setOpen(newOpen);
      if (!newOpen) {
        form.reset();
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      {mode === "create" && (
        <DialogTrigger asChild>
          <Button data-testid="button-add-stakeholder">
            <UserPlus className="h-4 w-4 mr-2" />
            Add Stakeholder
          </Button>
        </DialogTrigger>
      )}
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mode === "edit" ? "Edit Stakeholder" : "Add Stakeholder"}</DialogTitle>
          <DialogDescription>
            {mode === "edit"
              ? "Update stakeholder information"
              : "Add a new stakeholder to the project"}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter stakeholder name"
                      {...field}
                      data-testid="input-stakeholder-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="role"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Role</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter stakeholder role"
                      {...field}
                      data-testid="input-stakeholder-role"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email (optional)</FormLabel>
                  <FormControl>
                    <Input
                      type="email"
                      placeholder="stakeholder@example.com"
                      {...field}
                      value={field.value || ""}
                      data-testid="input-stakeholder-email"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="influence"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Influence Level</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value}
                      data-testid="select-stakeholder-influence"
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select influence level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="interest"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Interest Level</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value}
                      data-testid="select-stakeholder-interest"
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select interest level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="engagementStrategy"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Engagement Strategy (optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe the engagement strategy for this stakeholder"
                      {...field}
                      value={field.value || ""}
                      data-testid="input-stakeholder-strategy"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={isPending}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isPending} data-testid="button-save-stakeholder">
                {isPending ? "Saving..." : mode === "edit" ? "Save Changes" : "Add Stakeholder"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
