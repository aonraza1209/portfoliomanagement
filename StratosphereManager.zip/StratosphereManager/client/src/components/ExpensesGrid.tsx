import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DollarSign, Calendar, Trash2, Edit } from "lucide-react";
import { ExpenseDialog } from "./ExpenseDialog";
import type { Expense, InsertExpense } from "@shared/schema";
import { format } from "date-fns";
import { useState } from "react";

interface ExpensesGridProps {
  projectId: string;
  expenses: Expense[];
  onCreateExpense?: (data: InsertExpense) => void;
  onUpdateExpense?: (id: string, data: Partial<InsertExpense>) => void;
  onDeleteExpense?: (id: string) => void;
  isCreating?: boolean;
  isUpdating?: boolean;
  isDeleting?: boolean;
}

const categoryColors: Record<string, string> = {
  "Labor": "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  "Materials": "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  "Software": "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  "Hardware": "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
  "Travel": "bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200",
  "Training": "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  "Consulting": "bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200",
  "Licensing": "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200",
  "Infrastructure": "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200",
  "Other": "bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-200",
};

export function ExpensesGrid({
  projectId,
  expenses,
  onCreateExpense,
  onUpdateExpense,
  onDeleteExpense,
  isCreating,
  isUpdating,
  isDeleting,
}: ExpensesGridProps) {
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);

  const total = expenses.reduce((sum, expense) => {
    const amount = typeof expense.amount === 'string' ? parseFloat(expense.amount) : expense.amount;
    return sum + amount;
  }, 0);

  const handleEdit = (expense: Expense) => {
    setEditingExpense(expense);
    setEditDialogOpen(true);
  };

  const handleEditSubmit = (data: Partial<InsertExpense>) => {
    if (editingExpense && onUpdateExpense) {
      onUpdateExpense(editingExpense.id, data);
      setEditDialogOpen(false);
      setEditingExpense(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Expenses</h3>
          <p className="text-sm text-muted-foreground">
            Total: ${total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>
        {onCreateExpense && (
          <ExpenseDialog
            projectId={projectId}
            onSubmit={onCreateExpense}
            isPending={isCreating}
            mode="create"
          />
        )}
      </div>

      {expenses.length === 0 ? (
        <Card>
          <CardContent className="py-12">
            <div className="text-center">
              <DollarSign className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-sm text-muted-foreground">No expenses recorded yet</p>
              <p className="text-xs text-muted-foreground mt-1">
                Add expenses to track project spending
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Category</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {expenses.map((expense) => {
                  const amount = typeof expense.amount === 'string' ? parseFloat(expense.amount) : expense.amount;
                  return (
                    <TableRow key={expense.id} data-testid={`row-expense-${expense.id}`}>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={categoryColors[expense.category] || categoryColors["Other"]}
                        >
                          {expense.category}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {format(new Date(expense.date), "MMM d, yyyy")}
                        </div>
                      </TableCell>
                      <TableCell className="max-w-md">
                        <p className="text-sm truncate">
                          {expense.description || <span className="text-muted-foreground">No description</span>}
                        </p>
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        ${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          {onUpdateExpense && (
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(expense)}
                              disabled={isUpdating}
                              data-testid={`button-edit-expense-${expense.id}`}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          )}
                          {onDeleteExpense && (
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => onDeleteExpense(expense.id)}
                              disabled={isDeleting}
                              data-testid={`button-delete-expense-${expense.id}`}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {editingExpense && (
        <ExpenseDialog
          projectId={projectId}
          expense={editingExpense}
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          onSubmit={handleEditSubmit}
          isPending={isUpdating}
          mode="edit"
        />
      )}
    </div>
  );
}
