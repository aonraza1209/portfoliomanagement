import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from "@/components/ui/sidebar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronRight, FolderKanban, Target, LayoutDashboard, CalendarDays } from "lucide-react";
import { useState } from "react";

interface Project {
  id: string;
  name: string;
}

interface SubStream {
  id: string;
  name: string;
  projects: Project[];
}

interface Stream {
  id: string;
  name: string;
  subStreams: SubStream[];
}

interface AppSidebarProps {
  streams: Stream[];
  onNavigate?: (type: 'dashboard' | 'goals' | 'summary' | 'stream' | 'substream' | 'project', id?: string) => void;
  activeId?: string;
}

export function AppSidebar({ streams, onNavigate, activeId }: AppSidebarProps) {
  const [openStreams, setOpenStreams] = useState<Set<string>>(new Set());
  const [openSubStreams, setOpenSubStreams] = useState<Set<string>>(new Set());

  const toggleStream = (streamId: string) => {
    const newOpen = new Set(openStreams);
    if (newOpen.has(streamId)) {
      newOpen.delete(streamId);
    } else {
      newOpen.add(streamId);
    }
    setOpenStreams(newOpen);
  };

  const toggleSubStream = (subStreamId: string) => {
    const newOpen = new Set(openSubStreams);
    if (newOpen.has(subStreamId)) {
      newOpen.delete(subStreamId);
    } else {
      newOpen.add(subStreamId);
    }
    setOpenSubStreams(newOpen);
  };

  return (
    <Sidebar>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => onNavigate?.('dashboard')}
                  isActive={activeId === 'dashboard'}
                  data-testid="nav-dashboard"
                >
                  <LayoutDashboard className="h-4 w-4" />
                  <span>Dashboard</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => onNavigate?.('goals')}
                  isActive={activeId === 'goals'}
                  data-testid="nav-goals"
                >
                  <Target className="h-4 w-4" />
                  <span>Strategic Goals</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => onNavigate?.('summary')}
                  isActive={activeId === 'summary'}
                  data-testid="nav-summary"
                >
                  <CalendarDays className="h-4 w-4" />
                  <span>Weekly Summary</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Streams</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {streams.map((stream) => (
                <Collapsible
                  key={stream.id}
                  open={openStreams.has(stream.id)}
                  onOpenChange={() => toggleStream(stream.id)}
                >
                  <SidebarMenuItem>
                    <div className="flex items-center w-full">
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton className="flex-none w-auto px-2" data-testid={`nav-stream-toggle-${stream.id}`}>
                          <ChevronRight className={`h-4 w-4 transition-transform ${openStreams.has(stream.id) ? 'rotate-90' : ''}`} />
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <SidebarMenuButton
                        className="flex-1"
                        onClick={() => onNavigate?.('stream', stream.id)}
                        data-testid={`nav-stream-${stream.id}`}
                      >
                        <FolderKanban className="h-4 w-4" />
                        <span>{stream.name}</span>
                      </SidebarMenuButton>
                    </div>
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        {stream.subStreams.map((subStream) => (
                          <Collapsible
                            key={subStream.id}
                            open={openSubStreams.has(subStream.id)}
                            onOpenChange={() => toggleSubStream(subStream.id)}
                          >
                            <SidebarMenuSubItem>
                              <div className="flex items-center w-full">
                                <CollapsibleTrigger asChild>
                                  <SidebarMenuSubButton className="flex-none w-auto px-2" data-testid={`nav-substream-toggle-${subStream.id}`}>
                                    <ChevronRight className={`h-4 w-4 transition-transform ${openSubStreams.has(subStream.id) ? 'rotate-90' : ''}`} />
                                  </SidebarMenuSubButton>
                                </CollapsibleTrigger>
                                <SidebarMenuSubButton
                                  className="flex-1"
                                  onClick={() => onNavigate?.('substream', subStream.id)}
                                  data-testid={`nav-substream-${subStream.id}`}
                                >
                                  <span>{subStream.name}</span>
                                </SidebarMenuSubButton>
                              </div>
                              <CollapsibleContent>
                                <SidebarMenuSub>
                                  {subStream.projects.map((project) => (
                                    <SidebarMenuSubItem key={project.id}>
                                      <SidebarMenuSubButton
                                        onClick={() => onNavigate?.('project', project.id)}
                                        isActive={activeId === project.id}
                                        data-testid={`nav-project-${project.id}`}
                                      >
                                        <span className="ml-6">{project.name}</span>
                                      </SidebarMenuSubButton>
                                    </SidebarMenuSubItem>
                                  ))}
                                </SidebarMenuSub>
                              </CollapsibleContent>
                            </SidebarMenuSubItem>
                          </Collapsible>
                        ))}
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  </SidebarMenuItem>
                </Collapsible>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
