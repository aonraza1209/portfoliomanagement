import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { BudgetLineDialog } from "./BudgetLineDialog";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Trash2, Edit } from "lucide-react";
import { useState } from "react";
import type { BudgetLine, InsertBudgetLine, Expense } from "@shared/schema";

interface BudgetLinesGridProps {
  projectId: string;
  budgetLines: BudgetLine[];
  expenses: Expense[];
}

export function BudgetLinesGrid({ projectId, budgetLines, expenses }: BudgetLinesGridProps) {
  const { toast } = useToast();
  const [editingLine, setEditingLine] = useState<BudgetLine | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);

  const createMutation = useMutation({
    mutationFn: async (data: InsertBudgetLine) => {
      return apiRequest("POST", "/api/budget-lines", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "budget-lines"] });
      toast({ title: "Budget line created successfully" });
    },
    onError: () => {
      toast({ variant: "destructive", title: "Failed to create budget line" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertBudgetLine> }) => {
      return apiRequest("PATCH", `/api/budget-lines/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "budget-lines"] });
      setEditDialogOpen(false);
      setEditingLine(null);
      toast({ title: "Budget line updated successfully" });
    },
    onError: () => {
      toast({ variant: "destructive", title: "Failed to update budget line" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/budget-lines/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "budget-lines"] });
      toast({ title: "Budget line deleted successfully" });
    },
    onError: () => {
      toast({ variant: "destructive", title: "Failed to delete budget line" });
    },
  });

  const categoryTotals = budgetLines.reduce((acc, line) => {
    const allocated = parseFloat(line.allocatedAmount || "0");
    acc[line.category] = (acc[line.category] || 0) + allocated;
    return acc;
  }, {} as Record<string, number>);

  const categorySpent = expenses.reduce((acc, expense) => {
    const amount = parseFloat(expense.amount || "0");
    acc[expense.category] = (acc[expense.category] || 0) + amount;
    return acc;
  }, {} as Record<string, number>);

  const totalAllocated = Object.values(categoryTotals).reduce((sum, val) => sum + val, 0);
  const totalSpent = Object.values(categorySpent).reduce((sum, val) => sum + val, 0);

  const categories = Array.from(new Set([...Object.keys(categoryTotals), ...Object.keys(categorySpent)]));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Budget Lines</h3>
        <BudgetLineDialog
          projectId={projectId}
          onSubmit={(data) => createMutation.mutate(data)}
          isPending={createMutation.isPending}
        />
      </div>

      {budgetLines.length === 0 && (
        <div className="text-center py-8 text-muted-foreground">
          No budget lines defined. Click "Add Budget Line" to create planned allocations.
        </div>
      )}

      {budgetLines.length > 0 && (
        <div className="space-y-4">
          <div className="rounded-lg border">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left p-3 font-medium">Category</th>
                  <th className="text-right p-3 font-medium">Allocated</th>
                  <th className="text-right p-3 font-medium">Spent</th>
                  <th className="text-right p-3 font-medium">Remaining</th>
                  <th className="text-right p-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {budgetLines.map((line) => {
                  const allocated = parseFloat(line.allocatedAmount || "0");
                  const spent = categorySpent[line.category] || 0;
                  const remaining = allocated - spent;
                  const isOverBudget = remaining < 0;

                  return (
                    <tr key={line.id} className="border-t">
                      <td className="p-3">{line.category}</td>
                      <td className="p-3 text-right">${allocated.toFixed(2)}</td>
                      <td className="p-3 text-right">${spent.toFixed(2)}</td>
                      <td className={`p-3 text-right font-medium ${isOverBudget ? 'text-destructive' : 'text-foreground'}`}>
                        ${remaining.toFixed(2)}
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setEditingLine(line);
                              setEditDialogOpen(true);
                            }}
                            data-testid={`button-edit-budget-line-${line.id}`}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteMutation.mutate(line.id)}
                            disabled={deleteMutation.isPending}
                            data-testid={`button-delete-budget-line-${line.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                <tr className="border-t font-semibold bg-muted/30">
                  <td className="p-3">Total</td>
                  <td className="p-3 text-right">${totalAllocated.toFixed(2)}</td>
                  <td className="p-3 text-right">${totalSpent.toFixed(2)}</td>
                  <td className={`p-3 text-right ${(totalAllocated - totalSpent) < 0 ? 'text-destructive' : 'text-foreground'}`}>
                    ${(totalAllocated - totalSpent).toFixed(2)}
                  </td>
                  <td className="p-3"></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {editingLine && (
        <BudgetLineDialog
          projectId={projectId}
          budgetLine={editingLine}
          open={editDialogOpen}
          onOpenChange={(open) => {
            setEditDialogOpen(open);
            if (!open) setEditingLine(null);
          }}
          onSubmit={(data) => updateMutation.mutate({ id: editingLine.id, data })}
          isPending={updateMutation.isPending}
          mode="edit"
        />
      )}
    </div>
  );
}
