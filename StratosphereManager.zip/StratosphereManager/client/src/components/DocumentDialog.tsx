import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Upload } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDocumentSchema, type InsertDocument, type Document } from "@shared/schema";
import { z } from "zod";

const updateDocumentSchema = insertDocumentSchema.partial().omit({ projectId: true });
type UpdateDocument = z.infer<typeof updateDocumentSchema>;

interface DocumentDialogProps {
  projectId: string;
  document?: Document | null;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  onSubmit: (data: InsertDocument | UpdateDocument) => void;
  isPending?: boolean;
  mode?: "create" | "edit";
}

export function DocumentDialog({
  projectId,
  document,
  open: externalOpen,
  onOpenChange: externalOnOpenChange,
  onSubmit,
  isPending,
  mode = "create",
}: DocumentDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);

  const open = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = externalOnOpenChange || setInternalOpen;

  const form = useForm<InsertDocument | UpdateDocument>({
    resolver: zodResolver(mode === "create" ? insertDocumentSchema : updateDocumentSchema),
    defaultValues: {
      projectId: mode === "create" ? projectId : undefined,
      name: "",
      url: "",
      type: "Document",
    },
  });

  useEffect(() => {
    if (document && mode === "edit") {
      form.reset({
        name: document.name,
        url: document.url,
        type: document.type,
      });
    } else if (mode === "create") {
      form.reset({
        projectId,
        name: "",
        url: "",
        type: "Document",
      });
    }
  }, [document, mode, projectId, form]);

  const handleSubmit = (data: InsertDocument | UpdateDocument) => {
    onSubmit(data);
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!isPending) {
      setOpen(newOpen);
      if (!newOpen) {
        form.reset();
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      {mode === "create" && (
        <DialogTrigger asChild>
          <Button data-testid="button-upload-document">
            <Upload className="h-4 w-4 mr-2" />
            Upload Document
          </Button>
        </DialogTrigger>
      )}
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{mode === "edit" ? "Edit Document" : "Add Document"}</DialogTitle>
          <DialogDescription>
            {mode === "edit"
              ? "Update document information"
              : "Add a document link to the project library"}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Document Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter document name"
                      {...field}
                      data-testid="input-document-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="url"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Document URL</FormLabel>
                  <FormControl>
                    <Input
                      type="url"
                      placeholder="https://example.com/document.pdf"
                      {...field}
                      data-testid="input-document-url"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Document Type</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value} data-testid="select-document-type">
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select document type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Business Case">Business Case</SelectItem>
                      <SelectItem value="Technical Specification">Technical Specification</SelectItem>
                      <SelectItem value="Requirements">Requirements</SelectItem>
                      <SelectItem value="Design Document">Design Document</SelectItem>
                      <SelectItem value="Test Plan">Test Plan</SelectItem>
                      <SelectItem value="User Guide">User Guide</SelectItem>
                      <SelectItem value="Presentation">Presentation</SelectItem>
                      <SelectItem value="Spreadsheet">Spreadsheet</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={isPending}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isPending} data-testid="button-save-document">
                {isPending ? "Saving..." : mode === "edit" ? "Save Changes" : "Add Document"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
