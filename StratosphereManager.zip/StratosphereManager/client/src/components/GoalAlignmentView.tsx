import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Target, TrendingUp } from "lucide-react";

interface Project {
  id: string;
  name: string;
  progress: number;
}

interface OrganizationalGoal {
  id: string;
  name: string;
  description: string;
  targetProgress: number;
  currentProgress: number;
  linkedProjects: Project[];
}

interface GoalAlignmentViewProps {
  goals: OrganizationalGoal[];
}

export function GoalAlignmentView({ goals }: GoalAlignmentViewProps) {
  return (
    <div className="space-y-6">
      {goals.map((goal) => (
        <Card key={goal.id} data-testid={`card-goal-${goal.id}`}>
          <CardHeader>
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle className="text-lg">{goal.name}</CardTitle>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  {goal.description}
                </p>
              </div>
              <div className="flex flex-col items-end gap-2">
                <Badge variant="outline" className="flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  {goal.currentProgress}% / {goal.targetProgress}%
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Overall goal progress */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Overall Progress</span>
                <span className="font-mono font-medium">{goal.currentProgress}%</span>
              </div>
              <Progress value={goal.currentProgress} className="h-3" />
            </div>

            {/* Linked projects */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium">Contributing Projects</h4>
              <div className="space-y-3">
                {goal.linkedProjects.map((project) => (
                  <div
                    key={project.id}
                    className="flex items-center gap-4 p-3 rounded-md bg-muted/30"
                    data-testid={`project-${project.id}`}
                  >
                    <div className="flex-1">
                      <p className="text-sm font-medium">{project.name}</p>
                    </div>
                    <div className="flex items-center gap-3 min-w-[200px]">
                      <Progress value={project.progress} className="h-2 flex-1" />
                      <span className="font-mono text-xs w-10 text-right">
                        {project.progress}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
