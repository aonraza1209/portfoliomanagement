import { ProjectDetailView } from '../ProjectDetailView';

const mockProject = {
  id: 'proj-1',
  name: 'Customer Portal Redesign',
  description: 'Complete redesign and modernization of customer-facing portal with improved UX and performance',
  status: 'On Track',
  progress: 68,
  startDate: 'Jan 15, 2025',
  endDate: 'Mar 30, 2025',
};

const mockTasks = [
  {
    id: 'task-1',
    name: 'Design database schema',
    priority: 'high' as const,
    assignee: 'Sarah Chen',
    startDate: '2025-01-15',
    endDate: '2025-01-22',
    duration: 7,
    dependencies: [],
    progress: 100,
    status: 'completed' as const,
    isCriticalPath: true,
  },
  {
    id: 'task-2',
    name: 'Implement API endpoints',
    priority: 'high' as const,
    assignee: 'Mike Johnson',
    startDate: '2025-01-23',
    endDate: '2025-02-05',
    duration: 14,
    dependencies: ['task-1'],
    progress: 65,
    status: 'in-progress' as const,
    isCriticalPath: true,
  },
];

const mockRAID = {
  risks: [
    {
      id: 'risk-1',
      title: 'Third-party API availability',
      description: 'External API downtime could impact checkout flow.',
      owner: 'Sarah Chen',
      severity: 'high' as const,
      status: 'Active',
      mitigation: 'Implement fallback payment provider.',
    },
  ],
  assumptions: [
    {
      id: 'assumption-1',
      title: 'User adoption rate',
      description: '70% migration in Q1.',
      owner: 'Emily Rodriguez',
      severity: 'medium' as const,
      status: 'Validated',
    },
  ],
  issues: [
    {
      id: 'issue-1',
      title: 'Database performance',
      description: 'Query times increased 40%.',
      owner: 'David Kim',
      severity: 'high' as const,
      status: 'In Progress',
      mitigation: 'Add indexes.',
    },
  ],
  dependencies: [
    {
      id: 'dep-1',
      title: 'Infrastructure approval',
      description: 'Needs infrastructure team sign-off.',
      owner: 'Sarah Chen',
      severity: 'low' as const,
      status: 'Pending',
    },
  ],
};

const mockDocuments = [
  {
    id: 'doc-1',
    name: 'Project Charter.pdf',
    type: 'PDF',
    size: '2.4 MB',
    uploadDate: '2025-01-10',
    uploader: 'Jennifer Martinez',
    category: 'Business Case',
  },
];

const mockStakeholders = [
  {
    id: 'sh-1',
    name: 'Jennifer Martinez',
    role: 'Project Sponsor',
    email: 'j.martinez@company.com',
    phone: '+1 (555) 123-4567',
    engagement: 'high' as const,
    responsibilities: ['Budget approval', 'Strategic direction'],
  },
  {
    id: 'sh-2',
    name: 'Robert Chen',
    role: 'Technical Lead',
    email: 'r.chen@company.com',
    engagement: 'high' as const,
    responsibilities: ['Technical architecture', 'Code review'],
  },
];

export default function ProjectDetailViewExample() {
  return (
    <ProjectDetailView
      project={mockProject}
      tasks={mockTasks}
      raid={mockRAID}
      documents={mockDocuments}
      stakeholders={mockStakeholders}
    />
  );
}
