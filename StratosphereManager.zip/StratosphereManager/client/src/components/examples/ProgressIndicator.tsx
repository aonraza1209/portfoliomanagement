import { ProgressIndicator } from '../ProgressIndicator';
import { useState } from 'react';

export default function ProgressIndicatorExample() {
  const [progress, setProgress] = useState(65);

  return (
    <div className="flex gap-6 items-center p-6">
      <div className="space-y-2">
        <p className="text-sm text-muted-foreground">Non-editable</p>
        <ProgressIndicator progress={75} />
      </div>
      <div className="space-y-2">
        <p className="text-sm text-muted-foreground">Editable (click to update)</p>
        <ProgressIndicator
          progress={progress}
          onUpdate={(newProgress) => {
            setProgress(newProgress);
            console.log('Progress updated to:', newProgress);
          }}
          editable
          size="lg"
        />
      </div>
    </div>
  );
}
