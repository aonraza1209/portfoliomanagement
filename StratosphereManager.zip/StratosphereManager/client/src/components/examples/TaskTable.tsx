import { TaskTable } from '../TaskTable';

const mockTasks = [
  {
    id: 'task-1',
    name: 'Design database schema',
    priority: 'high' as const,
    assignee: 'Sarah Chen',
    startDate: '2025-01-15',
    endDate: '2025-01-22',
    duration: 7,
    dependencies: [],
    progress: 100,
    status: 'completed' as const,
    isCriticalPath: true,
  },
  {
    id: 'task-2',
    name: 'Implement API endpoints',
    priority: 'high' as const,
    assignee: 'Mike Johnson',
    startDate: '2025-01-23',
    endDate: '2025-02-05',
    duration: 14,
    dependencies: ['task-1'],
    progress: 65,
    status: 'in-progress' as const,
    isCriticalPath: true,
  },
  {
    id: 'task-3',
    name: 'Create UI mockups',
    priority: 'medium' as const,
    assignee: 'Emily Rodriguez',
    startDate: '2025-01-20',
    endDate: '2025-01-27',
    duration: 7,
    dependencies: [],
    progress: 90,
    status: 'in-progress' as const,
  },
  {
    id: 'task-4',
    name: 'Write documentation',
    priority: 'low' as const,
    assignee: 'David Kim',
    startDate: '2025-02-06',
    endDate: '2025-02-10',
    duration: 5,
    dependencies: ['task-2'],
    progress: 0,
    status: 'not-started' as const,
  },
  {
    id: 'task-5',
    name: 'Performance testing',
    priority: 'high' as const,
    assignee: 'Sarah Chen',
    startDate: '2025-01-28',
    endDate: '2025-02-03',
    duration: 7,
    dependencies: ['task-2'],
    progress: 30,
    status: 'delayed' as const,
  },
];

export default function TaskTableExample() {
  return (
    <TaskTable
      tasks={mockTasks}
      onTaskClick={(id) => console.log('Task clicked:', id)}
    />
  );
}
