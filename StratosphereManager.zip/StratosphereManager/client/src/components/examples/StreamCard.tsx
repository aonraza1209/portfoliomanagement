import { StreamCard } from '../StreamCard';

export default function StreamCardExample() {
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      <StreamCard
        name="Urgent Business Needs"
        description="Critical business requirements with immediate priority"
        subStreamCount={4}
        activeProjects={8}
        progress={72}
        onClick={() => console.log('Stream clicked')}
      />
      <StreamCard
        name="Core Modernization"
        description="Infrastructure and platform modernization initiatives"
        subStreamCount={3}
        activeProjects={5}
        progress={45}
        onClick={() => console.log('Stream clicked')}
      />
      <StreamCard
        name="Data Layer"
        description="Data architecture and analytics improvements"
        subStreamCount={2}
        activeProjects={4}
        progress={88}
        onClick={() => console.log('Stream clicked')}
      />
    </div>
  );
}
