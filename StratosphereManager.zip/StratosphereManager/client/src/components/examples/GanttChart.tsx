import { GanttChart } from '../GanttChart';

const mockTasks = [
  {
    id: 'task-1',
    name: 'Design Phase',
    startDate: '2025-01-15',
    endDate: '2025-01-22',
    progress: 100,
    isCriticalPath: true,
  },
  {
    id: 'task-2',
    name: 'Development',
    startDate: '2025-01-23',
    endDate: '2025-02-05',
    progress: 65,
    isCriticalPath: true,
    dependencies: ['task-1'],
  },
  {
    id: 'task-3',
    name: 'UI Implementation',
    startDate: '2025-01-20',
    endDate: '2025-01-30',
    progress: 80,
  },
  {
    id: 'task-4',
    name: 'Testing',
    startDate: '2025-02-01',
    endDate: '2025-02-08',
    progress: 30,
  },
  {
    id: 'task-5',
    name: 'Documentation',
    startDate: '2025-02-06',
    endDate: '2025-02-12',
    progress: 0,
    dependencies: ['task-2'],
  },
];

export default function GanttChartExample() {
  return <GanttChart tasks={mockTasks} title="Project Timeline" />;
}
