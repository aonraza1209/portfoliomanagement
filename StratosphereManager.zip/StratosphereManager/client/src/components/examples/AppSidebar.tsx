import { AppSidebar } from '../AppSidebar';
import { SidebarProvider } from '@/components/ui/sidebar';

const mockStreams = [
  {
    id: 'stream-1',
    name: 'Urgent Business Needs',
    subStreams: [
      {
        id: 'sub-1-1',
        name: 'In-house Development',
        projects: [
          { id: 'proj-1', name: 'Customer Portal Redesign' },
          { id: 'proj-2', name: 'Internal Analytics Dashboard' },
        ],
      },
      {
        id: 'sub-1-2',
        name: 'Off the Shelf',
        projects: [
          { id: 'proj-3', name: 'CRM Implementation' },
        ],
      },
    ],
  },
  {
    id: 'stream-2',
    name: 'Core Modernization',
    subStreams: [
      {
        id: 'sub-2-1',
        name: 'Legacy Migration',
        projects: [
          { id: 'proj-4', name: 'Database Migration' },
          { id: 'proj-5', name: 'API Modernization' },
        ],
      },
    ],
  },
];

export default function AppSidebarExample() {
  const style = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar streams={mockStreams} activeId="dashboard" />
      </div>
    </SidebarProvider>
  );
}
