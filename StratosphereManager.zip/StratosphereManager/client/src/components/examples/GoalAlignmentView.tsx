import { GoalAlignmentView } from '../GoalAlignmentView';

const mockGoals = [
  {
    id: 'goal-1',
    name: 'Digital Transformation',
    description: 'Modernize core business processes and customer touchpoints through technology adoption',
    targetProgress: 100,
    currentProgress: 68,
    linkedProjects: [
      { id: 'proj-1', name: 'Customer Portal Redesign', progress: 85 },
      { id: 'proj-2', name: 'API Modernization', progress: 62 },
      { id: 'proj-3', name: 'Cloud Migration', progress: 58 },
    ],
  },
  {
    id: 'goal-2',
    name: 'Operational Excellence',
    description: 'Improve efficiency and reduce operational costs by 20% through process automation',
    targetProgress: 100,
    currentProgress: 45,
    linkedProjects: [
      { id: 'proj-4', name: 'Workflow Automation', progress: 50 },
      { id: 'proj-5', name: 'Internal Analytics Dashboard', progress: 40 },
    ],
  },
  {
    id: 'goal-3',
    name: 'Data-Driven Decision Making',
    description: 'Enable real-time insights and analytics across all business units',
    targetProgress: 100,
    currentProgress: 72,
    linkedProjects: [
      { id: 'proj-6', name: 'Data Warehouse Implementation', progress: 90 },
      { id: 'proj-7', name: 'BI Tool Integration', progress: 65 },
      { id: 'proj-8', name: 'Data Governance Framework', progress: 60 },
    ],
  },
];

export default function GoalAlignmentViewExample() {
  return <GoalAlignmentView goals={mockGoals} />;
}
