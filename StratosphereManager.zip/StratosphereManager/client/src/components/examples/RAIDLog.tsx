import { RAIDLog } from '../RAIDLog';

const mockRAID = {
  risks: [
    {
      id: 'risk-1',
      title: 'Third-party API availability',
      description: 'The external payment API has experienced downtime in the past, which could impact our checkout flow.',
      owner: 'Sarah Chen',
      severity: 'high' as const,
      status: 'Active',
      mitigation: 'Implement fallback payment provider and circuit breaker pattern with automatic failover.',
    },
    {
      id: 'risk-2',
      title: 'Resource availability',
      description: 'Key team members may be unavailable during critical sprint phases.',
      owner: 'Mike Johnson',
      severity: 'medium' as const,
      status: 'Monitoring',
      mitigation: 'Cross-train team members and maintain detailed documentation.',
    },
  ],
  assumptions: [
    {
      id: 'assumption-1',
      title: 'User adoption rate',
      description: 'Assuming 70% of current users will migrate to the new platform within first quarter.',
      owner: 'Emily Rodriguez',
      severity: 'medium' as const,
      status: 'Validated',
    },
  ],
  issues: [
    {
      id: 'issue-1',
      title: 'Database performance degradation',
      description: 'Query response times have increased by 40% over the past week.',
      owner: 'David Kim',
      severity: 'high' as const,
      status: 'In Progress',
      mitigation: 'Add database indexes and implement query optimization.',
    },
  ],
  dependencies: [
    {
      id: 'dep-1',
      title: 'Infrastructure team approval',
      description: 'Cloud infrastructure changes require approval from infrastructure team.',
      owner: 'Sarah Chen',
      severity: 'low' as const,
      status: 'Pending',
    },
  ],
};

export default function RAIDLogExample() {
  return <RAIDLog {...mockRAID} />;
}
