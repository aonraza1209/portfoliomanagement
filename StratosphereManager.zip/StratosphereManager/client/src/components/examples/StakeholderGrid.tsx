import { StakeholderGrid } from '../StakeholderGrid';

const mockStakeholders = [
  {
    id: 'sh-1',
    name: 'Jennifer Martinez',
    role: 'Project Sponsor',
    email: 'j.martinez@company.com',
    phone: '+1 (555) 123-4567',
    engagement: 'high' as const,
    responsibilities: [
      'Budget approval',
      'Strategic direction',
      'Executive stakeholder management',
    ],
  },
  {
    id: 'sh-2',
    name: 'Robert Chen',
    role: 'Technical Lead',
    email: 'r.chen@company.com',
    phone: '+1 (555) 234-5678',
    engagement: 'high' as const,
    responsibilities: [
      'Technical architecture decisions',
      'Code review and quality assurance',
      'Team mentorship',
    ],
  },
  {
    id: 'sh-3',
    name: 'Amanda Johnson',
    role: 'Product Owner',
    email: 'a.johnson@company.com',
    engagement: 'high' as const,
    responsibilities: [
      'Requirements definition',
      'User story prioritization',
      'Acceptance criteria validation',
    ],
  },
  {
    id: 'sh-4',
    name: 'Michael Kim',
    role: 'Business Analyst',
    email: 'm.kim@company.com',
    phone: '+1 (555) 345-6789',
    engagement: 'medium' as const,
    responsibilities: [
      'Requirements gathering',
      'Process documentation',
    ],
  },
  {
    id: 'sh-5',
    name: 'Sarah Williams',
    role: 'QA Manager',
    email: 's.williams@company.com',
    engagement: 'medium' as const,
    responsibilities: [
      'Test strategy development',
      'Quality metrics reporting',
    ],
  },
  {
    id: 'sh-6',
    name: 'David Thompson',
    role: 'Legal Advisor',
    email: 'd.thompson@company.com',
    engagement: 'low' as const,
    responsibilities: [
      'Contract review',
      'Compliance guidance',
    ],
  },
];

export default function StakeholderGridExample() {
  return <StakeholderGrid stakeholders={mockStakeholders} />;
}
