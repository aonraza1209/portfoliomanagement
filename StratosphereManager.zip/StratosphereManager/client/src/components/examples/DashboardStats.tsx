import { DashboardStats } from '../DashboardStats';

export default function DashboardStatsExample() {
  return (
    <DashboardStats
      totalStreams={4}
      activeProjects={12}
      atRiskItems={3}
      overallProgress={67}
    />
  );
}
