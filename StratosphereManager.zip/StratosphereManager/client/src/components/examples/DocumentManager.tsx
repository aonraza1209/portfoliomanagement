import { DocumentManager } from '../DocumentManager';

const mockDocuments = [
  {
    id: 'doc-1',
    name: 'Project Charter.pdf',
    type: 'PDF',
    size: '2.4 MB',
    uploadDate: '2025-01-10',
    uploader: 'Jennifer Martinez',
    category: 'Business Case',
  },
  {
    id: 'doc-2',
    name: 'Technical Architecture.docx',
    type: 'Word Document',
    size: '1.8 MB',
    uploadDate: '2025-01-15',
    uploader: 'Robert Chen',
    category: 'Technical',
  },
  {
    id: 'doc-3',
    name: 'Requirements Specification.xlsx',
    type: 'Excel',
    size: '856 KB',
    uploadDate: '2025-01-18',
    uploader: 'Amanda Johnson',
    category: 'Requirements',
  },
  {
    id: 'doc-4',
    name: 'Risk Assessment.pdf',
    type: 'PDF',
    size: '1.2 MB',
    uploadDate: '2025-01-20',
    uploader: 'Michael Kim',
    category: 'Business Case',
  },
];

export default function DocumentManagerExample() {
  return (
    <DocumentManager
      documents={mockDocuments}
      onUpload={() => console.log('Upload clicked')}
      onDownload={(id) => console.log('Download clicked:', id)}
      onPreview={(id) => console.log('Preview clicked:', id)}
    />
  );
}
