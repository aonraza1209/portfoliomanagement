import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FolderKanban, Activity, AlertTriangle, TrendingUp } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  description?: string;
}

function StatCard({ title, value, icon, description }: StatCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold" data-testid={`stat-${title.toLowerCase().replace(/\s+/g, '-')}`}>{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        )}
      </CardContent>
    </Card>
  );
}

interface DashboardStatsProps {
  totalStreams: number;
  activeProjects: number;
  atRiskItems: number;
  overallProgress: number;
}

export function DashboardStats({
  totalStreams,
  activeProjects,
  atRiskItems,
  overallProgress,
}: DashboardStatsProps) {
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title="Total Streams"
        value={totalStreams}
        icon={<FolderKanban className="h-4 w-4 text-muted-foreground" />}
      />
      <StatCard
        title="Active Projects"
        value={activeProjects}
        icon={<Activity className="h-4 w-4 text-muted-foreground" />}
      />
      <StatCard
        title="At-Risk Items"
        value={atRiskItems}
        icon={<AlertTriangle className="h-4 w-4 text-destructive" />}
      />
      <StatCard
        title="Overall Progress"
        value={`${overallProgress}%`}
        icon={<TrendingUp className="h-4 w-4 text-muted-foreground" />}
      />
    </div>
  );
}
