import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Mail } from "lucide-react";
import { StakeholderDialog } from "./StakeholderDialog";
import type { Stakeholder } from "@shared/schema";

type EngagementLevel = "high" | "medium" | "low";

interface StakeholderGridProps {
  projectId: string;
  stakeholders: Stakeholder[];
  onCreateStakeholder?: (data: any) => void;
  isCreating?: boolean;
}

const engagementConfig = {
  high: { variant: "default" as const, label: "High Engagement" },
  medium: { variant: "secondary" as const, label: "Medium Engagement" },
  low: { variant: "outline" as const, label: "Low Engagement" },
};

export function StakeholderGrid({ projectId, stakeholders, onCreateStakeholder, isCreating }: StakeholderGridProps) {
  return (
    <div className="space-y-6">
      {onCreateStakeholder && (
        <div className="flex justify-end">
          <StakeholderDialog
            projectId={projectId}
            onSubmit={onCreateStakeholder}
            isPending={isCreating}
            mode="create"
          />
        </div>
      )}
      {stakeholders.length === 0 ? (
        <Card>
          <CardContent className="py-12">
            <p className="text-sm text-muted-foreground text-center">No stakeholders added yet</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {stakeholders.map((stakeholder) => (
            <Card key={stakeholder.id} data-testid={`card-stakeholder-${stakeholder.id}`}>
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback>
                        {stakeholder.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <CardTitle className="text-base">{stakeholder.name}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">
                        {stakeholder.role}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <Badge variant="outline" className="text-xs">
                      Influence: {stakeholder.influence}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      Interest: {stakeholder.interest}
                    </Badge>
                  </div>

                  {stakeholder.email && (
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Mail className="h-4 w-4" />
                        <a
                          href={`mailto:${stakeholder.email}`}
                          className="hover:text-foreground transition-colors"
                          data-testid={`link-email-${stakeholder.id}`}
                        >
                          {stakeholder.email}
                        </a>
                      </div>
                    </div>
                  )}

                  {stakeholder.engagementStrategy && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Engagement Strategy</h4>
                      <p className="text-sm text-muted-foreground">{stakeholder.engagementStrategy}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          )}
        </div>
      )}
    </div>
  );
}
