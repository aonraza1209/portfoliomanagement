import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertRaidLogSchema, type InsertRaidLog, type RaidLog } from "@shared/schema";
import { z } from "zod";

const updateRaidLogSchema = insertRaidLogSchema.partial().omit({ projectId: true });
type UpdateRaidLog = z.infer<typeof updateRaidLogSchema>;

interface RaidLogDialogProps {
  projectId: string;
  type: "Risk" | "Assumption" | "Issue" | "Dependency";
  raidLog?: RaidLog | null;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  onSubmit: (data: InsertRaidLog | UpdateRaidLog) => void;
  isPending?: boolean;
  mode?: "create" | "edit";
}

export function RaidLogDialog({
  projectId,
  type,
  raidLog,
  open: externalOpen,
  onOpenChange: externalOnOpenChange,
  onSubmit,
  isPending,
  mode = "create",
}: RaidLogDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);

  const open = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = externalOnOpenChange || setInternalOpen;

  const form = useForm<InsertRaidLog | UpdateRaidLog>({
    resolver: zodResolver(mode === "create" ? insertRaidLogSchema : updateRaidLogSchema),
    defaultValues: {
      projectId: mode === "create" ? projectId : undefined,
      type: type,
      title: "",
      description: "",
      status: "Open",
      severity: "Medium",
      mitigationPlan: "",
    },
  });

  useEffect(() => {
    if (raidLog && mode === "edit") {
      form.reset({
        type: raidLog.type,
        title: raidLog.title,
        description: raidLog.description,
        status: raidLog.status,
        severity: raidLog.severity || "Medium",
        mitigationPlan: raidLog.mitigationPlan || "",
      });
    } else if (mode === "create") {
      form.reset({
        projectId,
        type,
        title: "",
        description: "",
        status: "Open",
        severity: "Medium",
        mitigationPlan: "",
      });
    }
  }, [raidLog, mode, projectId, type, form]);

  const handleSubmit = (data: InsertRaidLog | UpdateRaidLog) => {
    onSubmit(data);
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!isPending) {
      setOpen(newOpen);
      if (!newOpen) {
        form.reset();
      }
    }
  };

  const getTitle = () => {
    if (mode === "edit") return `Edit ${type}`;
    return `Add ${type}`;
  };

  const getDescription = () => {
    if (mode === "edit") return `Update ${type.toLowerCase()} details`;
    return `Add a new ${type.toLowerCase()} to the RAID log`;
  };

  const getTriggerText = () => {
    return `Add ${type}`;
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      {mode === "create" && (
        <DialogTrigger asChild>
          <Button size="sm" data-testid={`button-add-${type.toLowerCase()}`}>
            <Plus className="h-4 w-4 mr-2" />
            {getTriggerText()}
          </Button>
        </DialogTrigger>
      )}
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{getTitle()}</DialogTitle>
          <DialogDescription>{getDescription()}</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input
                      placeholder={`Enter ${type.toLowerCase()} title`}
                      {...field}
                      data-testid={`input-${type.toLowerCase()}-title`}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder={`Describe the ${type.toLowerCase()} in detail`}
                      {...field}
                      data-testid={`input-${type.toLowerCase()}-description`}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value}
                      data-testid={`select-${type.toLowerCase()}-status`}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Open">Open</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Resolved">Resolved</SelectItem>
                        <SelectItem value="Closed">Closed</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="severity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Severity</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value || "Medium"}
                      data-testid={`select-${type.toLowerCase()}-severity`}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select severity" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="mitigationPlan"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    {type === "Risk" ? "Mitigation Plan" : type === "Issue" ? "Resolution Plan" : "Action Plan"}
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder={`Describe the ${
                        type === "Risk" ? "mitigation" : type === "Issue" ? "resolution" : "action"
                      } plan`}
                      {...field}
                      value={field.value || ""}
                      data-testid={`input-${type.toLowerCase()}-mitigation`}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={isPending}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isPending} data-testid={`button-save-${type.toLowerCase()}`}>
                {isPending ? "Saving..." : mode === "edit" ? "Save Changes" : `Add ${type}`}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
