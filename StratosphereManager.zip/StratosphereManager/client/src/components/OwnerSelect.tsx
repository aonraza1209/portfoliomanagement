import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

interface OwnerSelectProps {
  value?: string | null;
  onValueChange: (value: string | undefined) => void;
  placeholder?: string;
  allowNone?: boolean;
  testId?: string;
}

export function OwnerSelect({ 
  value, 
  onValueChange, 
  placeholder = "Select owner", 
  allowNone = true,
  testId = "select-owner" 
}: OwnerSelectProps) {
  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ['/api/users'],
  });

  const handleValueChange = (val: string) => {
    if (val === "__none__") {
      onValueChange(undefined);
    } else {
      onValueChange(val);
    }
  };

  const selectValue = value ?? (allowNone ? "__none__" : undefined);

  return (
    <Select 
      value={selectValue} 
      onValueChange={handleValueChange}
      disabled={isLoading}
    >
      <SelectTrigger data-testid={testId}>
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {allowNone && (
          <SelectItem value="__none__">No owner assigned</SelectItem>
        )}
        {users.map((user) => (
          <SelectItem key={user.id} value={user.id}>
            {user.username}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
