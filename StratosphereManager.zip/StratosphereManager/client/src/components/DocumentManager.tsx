import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { FileText, ExternalLink } from "lucide-react";
import { format } from "date-fns";
import { DocumentDialog } from "./DocumentDialog";
import type { Document } from "@shared/schema";

interface DocumentManagerProps {
  projectId: string;
  documents: Document[];
  onCreateDocument?: (data: any) => void;
  isCreating?: boolean;
}

const categoryColors: Record<string, "default" | "secondary" | "outline"> = {
  'Business Case': 'default',
  'Technical': 'secondary',
  'Requirements': 'outline',
};

export function DocumentManager({
  projectId,
  documents,
  onCreateDocument,
  isCreating,
}: DocumentManagerProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div>
            <CardTitle>Document Library</CardTitle>
            <CardDescription className="mt-1">
              Manage project documentation and files
            </CardDescription>
          </div>
          {onCreateDocument && (
            <DocumentDialog
              projectId={projectId}
              onSubmit={onCreateDocument}
              isPending={isCreating}
              mode="create"
            />
          )}
        </div>
      </CardHeader>
      <CardContent>
        {documents.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-sm text-muted-foreground">No documents uploaded yet</p>
          </div>
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Document Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Size</TableHead>
                  <TableHead>Uploaded By</TableHead>
                  <TableHead>Upload Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {documents.map((doc) => (
                  <TableRow key={doc.id} data-testid={`row-document-${doc.id}`}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        {doc.name}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={categoryColors[doc.type] || 'outline'}>
                        {doc.type}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new URL(doc.url).hostname}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      -
                    </TableCell>
                    <TableCell className="text-sm">{doc.uploadedBy || "Unknown"}</TableCell>
                    <TableCell className="text-sm font-mono">
                      {format(new Date(doc.uploadedAt), 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => window.open(doc.url, '_blank')}
                          data-testid={`button-open-${doc.id}`}
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
