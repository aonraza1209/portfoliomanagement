import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PlusCircle } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBudgetLineSchema, type InsertBudgetLine, type BudgetLine } from "@shared/schema";

const BUDGET_CATEGORIES = [
  "Labor",
  "Materials",
  "Software",
  "Hardware",
  "Travel",
  "Training",
  "Consulting",
  "Licensing",
  "Infrastructure",
  "Other",
];

interface BudgetLineDialogProps {
  projectId: string;
  budgetLine?: BudgetLine | null;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  onSubmit: (data: InsertBudgetLine) => void;
  isPending?: boolean;
  mode?: "create" | "edit";
}

export function BudgetLineDialog({
  projectId,
  budgetLine,
  open: externalOpen,
  onOpenChange: externalOnOpenChange,
  onSubmit,
  isPending,
  mode = "create",
}: BudgetLineDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);

  const open = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = externalOnOpenChange || setInternalOpen;

  const formSchema = mode === "create" ? insertBudgetLineSchema : insertBudgetLineSchema.partial().omit({ projectId: true });

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      projectId: mode === "create" ? projectId : undefined,
      category: "Labor",
      allocatedAmount: "",
      description: "",
    },
  });

  useEffect(() => {
    if (budgetLine && mode === "edit") {
      form.reset({
        category: budgetLine.category,
        allocatedAmount: budgetLine.allocatedAmount?.toString() || "",
        description: budgetLine.description || "",
      });
    } else if (mode === "create") {
      form.reset({
        projectId,
        category: "Labor",
        allocatedAmount: "",
        description: "",
      });
    }
  }, [budgetLine, mode, projectId, form]);

  const handleSubmit = (data: any) => {
    onSubmit(data);
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!isPending) {
      setOpen(newOpen);
      if (!newOpen) {
        form.reset();
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      {mode === "create" && (
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" data-testid="button-create-budget-line">
            <PlusCircle className="h-4 w-4 mr-2" />
            Add Budget Line
          </Button>
        </DialogTrigger>
      )}
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Add Budget Line" : "Edit Budget Line"}</DialogTitle>
          <DialogDescription>
            {mode === "create"
              ? "Define a planned budget allocation for a specific category."
              : "Update budget line details."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-budget-category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {BUDGET_CATEGORIES.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="allocatedAmount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Allocated Amount</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      {...field}
                      data-testid="input-allocated-amount"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description (Optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Budget line details..."
                      className="resize-none"
                      {...field}
                      data-testid="textarea-budget-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={isPending}
                data-testid="button-cancel-budget-line"
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isPending} data-testid="button-submit-budget-line">
                {isPending ? "Saving..." : mode === "create" ? "Add Budget Line" : "Update Budget Line"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
