import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTaskSchema, type InsertTask, type Task, type Milestone, type TaskDependency } from "@shared/schema";
import { z } from "zod";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const updateTaskSchema = insertTaskSchema.partial().extend({
  progress: z.number().min(0).max(100).optional(),
  selectedDependencies: z.array(z.string()).default([]),
});

type UpdateTask = z.infer<typeof updateTaskSchema>;

interface EditTaskDialogProps {
  task: Task | null;
  milestones?: Milestone[];
  tasks?: Task[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: UpdateTask, dependencyIds: string[], existingDependencyIds: string[]) => void;
  isPending?: boolean;
}

export function EditTaskDialog({ task, milestones = [], tasks = [], open, onOpenChange, onSubmit, isPending }: EditTaskDialogProps) {
  const { toast } = useToast();
  const { data: existingDependencies = [], isLoading: isDependenciesLoading, isError: isDependenciesError } = useQuery<TaskDependency[]>({
    queryKey: task?.id ? ["/api/tasks", task.id, "dependencies"] : ["disabled"],
    queryFn: async () => {
      if (!task?.id) return [];
      const res = await apiRequest("GET", `/api/tasks/${task.id}/dependencies`);
      return await res.json() as TaskDependency[];
    },
    enabled: !!task?.id && open,
    retry: 2,
  });

  const form = useForm<UpdateTask>({
    resolver: zodResolver(updateTaskSchema),
    defaultValues: {
      name: "",
      description: "",
      status: "Not Started",
      priority: "Medium",
      startDate: undefined,
      endDate: undefined,
      progress: 0,
      estimatedHours: undefined,
      milestoneId: "none",
      parentTaskId: "none",
      selectedDependencies: [],
    },
  });

  useEffect(() => {
    if (task && !isDependenciesLoading) {
      const depIds = existingDependencies.map(dep => dep.dependsOnId);
      
      const formatDateForInput = (date: Date | string | null | undefined): string | undefined => {
        if (!date) return undefined;
        if (typeof date === 'string') return date;
        if (date instanceof Date) return date.toISOString().split('T')[0];
        return undefined;
      };
      
      form.reset({
        name: task.name,
        description: task.description || "",
        status: task.status,
        priority: task.priority,
        startDate: formatDateForInput(task.startDate),
        endDate: formatDateForInput(task.endDate),
        progress: task.progress,
        estimatedHours: task.estimatedHours || undefined,
        milestoneId: task.milestoneId || "none",
        parentTaskId: task.parentTaskId || "none",
        selectedDependencies: depIds,
      });
    }
  }, [task, existingDependencies, isDependenciesLoading, form]);

  const handleSubmit = (data: UpdateTask) => {
    if (isDependenciesError) {
      toast({
        variant: "destructive",
        title: "Cannot Update Task",
        description: "Failed to load current dependencies. Please close and try again.",
      });
      return;
    }
    
    const { selectedDependencies, ...rest } = data;
    const updates: UpdateTask = {
      ...rest,
      milestoneId: data.milestoneId === "none" ? null : data.milestoneId,
      parentTaskId: data.parentTaskId === "none" ? null : data.parentTaskId,
    };
    const existingDepIds = existingDependencies.map(dep => dep.dependsOnId);
    onSubmit(updates, selectedDependencies || [], existingDepIds);
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!isPending) {
      onOpenChange(newOpen);
      if (!newOpen) {
        form.reset();
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Task</DialogTitle>
          <DialogDescription>
            Update task information and progress
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Task Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter task name" 
                      {...field} 
                      data-testid="input-task-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Task description"
                      {...field}
                      value={field.value || ""}
                      data-testid="input-task-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value}
                      data-testid="select-task-status"
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Not Started">Not Started</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Completed">Completed</SelectItem>
                        <SelectItem value="On Hold">On Hold</SelectItem>
                        <SelectItem value="Cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Priority</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value}
                      data-testid="select-task-priority"
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Start Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className="justify-start text-left font-normal"
                            data-testid="button-start-date"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {field.value ? format(new Date(field.value), "PPP") : <span>Pick a date</span>}
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value ? new Date(field.value) : undefined}
                          onSelect={(date) => field.onChange(date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>End Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className="justify-start text-left font-normal"
                            data-testid="button-end-date"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {field.value ? format(new Date(field.value), "PPP") : <span>Pick a date</span>}
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value ? new Date(field.value) : undefined}
                          onSelect={(date) => field.onChange(date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="progress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Progress (%)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        placeholder="0"
                        {...field}
                        onChange={(e) => field.onChange(e.target.valueAsNumber)}
                        data-testid="input-task-progress"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="estimatedHours"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Estimated Hours</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        placeholder="0"
                        {...field}
                        onChange={(e) => field.onChange(e.target.valueAsNumber || undefined)}
                        value={field.value || ""}
                        data-testid="input-task-hours"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="milestoneId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Milestone (Optional)</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    value={field.value || "none"}
                    defaultValue="none"
                  >
                    <FormControl>
                      <SelectTrigger data-testid="select-task-milestone">
                        <SelectValue placeholder="Link to milestone" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="none">No Milestone</SelectItem>
                      {milestones.map((milestone) => (
                        <SelectItem key={milestone.id} value={milestone.id}>
                          {milestone.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="parentTaskId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Parent Task (Optional)</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    value={field.value || "none"}
                    defaultValue="none"
                  >
                    <FormControl>
                      <SelectTrigger data-testid="select-parent-task">
                        <SelectValue placeholder="Select parent task" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="none">No Parent Task</SelectItem>
                      {tasks.filter(t => t.id !== task?.id).map((task) => (
                        <SelectItem key={task.id} value={task.id}>
                          {task.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="selectedDependencies"
              render={() => (
                <FormItem>
                  <FormLabel>Dependencies (Optional)</FormLabel>
                  <FormDescription className="text-sm text-muted-foreground">
                    Select tasks that must be completed before this task can start
                  </FormDescription>
                  <div className="space-y-2 max-h-40 overflow-y-auto border rounded-md p-3">
                    {tasks.filter(t => t.id !== task?.id).length === 0 ? (
                      <p className="text-sm text-muted-foreground">No other tasks available</p>
                    ) : (
                      tasks.filter(t => t.id !== task?.id).map((availableTask) => (
                        <FormField
                          key={availableTask.id}
                          control={form.control}
                          name="selectedDependencies"
                          render={({ field }) => {
                            return (
                              <FormItem
                                key={availableTask.id}
                                className="flex flex-row items-start space-x-3 space-y-0"
                              >
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(availableTask.id)}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, availableTask.id])
                                        : field.onChange(
                                            field.value?.filter(
                                              (value) => value !== availableTask.id
                                            )
                                          );
                                    }}
                                    data-testid={`checkbox-dependency-${availableTask.id}`}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal cursor-pointer">
                                  {availableTask.name}
                                </FormLabel>
                              </FormItem>
                            );
                          }}
                        />
                      ))
                    )}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={isPending}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={isPending || isDependenciesLoading || isDependenciesError}
                data-testid="button-save-task"
              >
                {isPending ? "Saving..." : isDependenciesLoading ? "Loading..." : isDependenciesError ? "Error Loading Dependencies" : "Save Changes"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
