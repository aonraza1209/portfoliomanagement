import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { UserMenu } from "@/components/UserMenu";
import Dashboard from "@/pages/Dashboard";
import Goals from "@/pages/Goals";
import Summary from "@/pages/Summary";
import StreamDashboard from "@/pages/StreamDashboard";
import SubStreamDashboard from "@/pages/SubStreamDashboard";
import ProjectDetail from "@/pages/ProjectDetail";
import NotFound from "@/pages/not-found";
import { Building2 } from "lucide-react";
import type { Stream, SubStream, Project } from "@shared/schema";

function Router() {
  const [, setLocation] = useLocation();
  
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/goals" component={Goals} />
      <Route path="/summary" component={Summary} />
      <Route path="/stream/:id">
        {(params) => (
          <StreamDashboard
            streamId={params.id}
            onBack={() => setLocation('/')}
            onNavigateToSubStream={(subStreamId) => setLocation(`/substream/${subStreamId}`)}
          />
        )}
      </Route>
      <Route path="/substream/:id">
        {(params) => (
          <SubStreamDashboard
            subStreamId={params.id}
            onBack={() => setLocation('/stream/stream-1')}
            onNavigateToProject={(projectId) => setLocation(`/project/${projectId}`)}
          />
        )}
      </Route>
      <Route path="/project/:id">
        {(params) => <ProjectDetail projectId={params.id} onBack={() => setLocation('/')} />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const [location, setLocation] = useLocation();

  const { data: streams = [], isLoading: streamsLoading, isError: streamsError } = useQuery<Stream[]>({
    queryKey: ['/api/streams'],
  });

  const { data: subStreams = [], isLoading: subStreamsLoading } = useQuery<SubStream[]>({
    queryKey: ['/api/substreams'],
  });

  const { data: projects = [], isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });

  const sidebarLoading = streamsLoading || subStreamsLoading || projectsLoading;

  const transformedStreams = sidebarLoading || streamsError ? [] : streams.map(stream => ({
    id: stream.id,
    name: stream.name,
    subStreams: subStreams
      .filter(sub => sub.streamId === stream.id)
      .map(sub => ({
        id: sub.id,
        name: sub.name,
        projects: projects
          .filter(proj => proj.subStreamId === sub.id)
          .map(proj => ({
            id: proj.id,
            name: proj.name,
          })),
      })),
  }));

  const getActiveId = () => {
    if (location === '/') return 'dashboard';
    if (location === '/goals') return 'goals';
    if (location === '/summary') return 'summary';
    if (location.startsWith('/project/')) {
      return location.split('/')[2];
    }
    return 'dashboard';
  };

  const handleNavigate = (type: string, id?: string) => {
    if (type === 'dashboard') {
      setLocation('/');
    } else if (type === 'goals') {
      setLocation('/goals');
    } else if (type === 'summary') {
      setLocation('/summary');
    } else if (type === 'stream' && id) {
      setLocation(`/stream/${id}`);
    } else if (type === 'substream' && id) {
      setLocation(`/substream/${id}`);
    } else if (type === 'project' && id) {
      setLocation(`/project/${id}`);
    }
  };

  const style = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <>
      <SidebarProvider style={style as React.CSSProperties}>
        <div className="flex h-screen w-full">
          <AppSidebar
            streams={transformedStreams}
            onNavigate={handleNavigate}
            activeId={getActiveId()}
          />
          <div className="flex flex-col flex-1 overflow-hidden">
            <header className="flex items-center justify-between p-4 border-b">
              <div className="flex items-center gap-4">
                <SidebarTrigger data-testid="button-sidebar-toggle" />
                <div className="flex items-center gap-2">
                  <Building2 className="h-6 w-6 text-primary" />
                  <span className="font-semibold text-lg hidden md:inline">Portfolio Hub</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <ThemeToggle />
                <UserMenu />
              </div>
            </header>
            <main className="flex-1 overflow-auto p-8">
              <Router />
            </main>
          </div>
        </div>
      </SidebarProvider>
      <Toaster />
    </>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
