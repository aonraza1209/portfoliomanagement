import { DashboardStats } from "@/components/DashboardStats";
import { StreamCard } from "@/components/StreamCard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock } from "lucide-react";
import { format } from "date-fns";
import { CreateStreamDialog } from "@/components/CreateStreamDialog";
import { EditStreamDialog } from "@/components/EditStreamDialog";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useState } from "react";
import type { InsertStream, Stream, SubStream, Project } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [editingStream, setEditingStream] = useState<Stream | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);

  const { data: streams = [], isLoading: streamsLoading } = useQuery<Stream[]>({
    queryKey: ["/api/streams"],
  });

  const { data: allSubStreams = [] } = useQuery<SubStream[]>({
    queryKey: ["/api/substreams"],
  });

  const { data: allProjects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const createStreamMutation = useMutation({
    mutationFn: async (data: InsertStream) => {
      return await apiRequest("POST", "/api/streams", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      toast({
        title: "Stream created",
        description: "The stream has been created successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create stream. Please try again.",
      });
    },
  });

  const updateStreamMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertStream> }) => {
      return await apiRequest("PATCH", `/api/streams/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/substreams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setEditDialogOpen(false);
      setEditingStream(null);
      toast({
        title: "Stream updated",
        description: "The stream has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update stream. Please try again.",
      });
    },
  });

  const recentActivity = [
    {
      id: '1',
      title: 'Customer Portal Redesign marked 85% complete',
      timestamp: new Date(2025, 0, 20, 14, 30),
      type: 'progress',
    },
    {
      id: '2',
      title: 'New risk added to API Modernization project',
      timestamp: new Date(2025, 0, 20, 11, 15),
      type: 'risk',
    },
    {
      id: '3',
      title: 'Database Migration moved to critical path',
      timestamp: new Date(2025, 0, 19, 16, 45),
      type: 'alert',
    },
    {
      id: '4',
      title: 'Cloud Infrastructure approved by stakeholders',
      timestamp: new Date(2025, 0, 19, 9, 20),
      type: 'approval',
    },
    {
      id: '5',
      title: 'Workflow Automation completed milestone 2',
      timestamp: new Date(2025, 0, 18, 13, 10),
      type: 'milestone',
    },
  ];

  const typeColors: Record<string, "default" | "destructive" | "secondary" | "outline"> = {
    progress: 'default',
    risk: 'destructive',
    alert: 'secondary',
    approval: 'outline',
    milestone: 'default',
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-semibold">Portfolio Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Overview of all streams, projects, and portfolio health
        </p>
      </div>

      {streamsLoading ? (
        <div className="grid gap-6 md:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <div className="h-4 bg-muted rounded w-24 animate-pulse" />
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-muted rounded w-16 animate-pulse" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <DashboardStats
          totalStreams={streams.length}
          activeProjects={allProjects.filter(p => p.status === 'In Progress').length}
          atRiskItems={allProjects.filter(p => p.status === 'At Risk').length}
          overallProgress={allProjects.length > 0 ? Math.round(
            allProjects.reduce((sum, p) => sum + (p.progress || 0), 0) / allProjects.length
          ) : 0}
        />
      )}

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Streams Overview</h2>
          <CreateStreamDialog onSubmit={(data) => createStreamMutation.mutate(data)} />
        </div>
        {streamsLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2">
            {[1, 2].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <div className="h-5 bg-muted rounded w-48 animate-pulse" />
                  <div className="h-4 bg-muted rounded w-full mt-2 animate-pulse" />
                </CardHeader>
                <CardContent>
                  <div className="h-4 bg-muted rounded w-32 animate-pulse" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : streams.length === 0 ? (
          <Card>
            <CardContent className="py-8">
              <p className="text-center text-muted-foreground">
                No streams yet. Create your first stream to get started.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2">
            {streams.map((stream) => {
              const streamSubStreams = allSubStreams.filter(ss => ss.streamId === stream.id);
              const streamProjects = allProjects.filter(p => 
                streamSubStreams.some(ss => ss.id === p.subStreamId)
              );
              
              return (
                <StreamCard
                  key={stream.id}
                  {...stream}
                  subStreamCount={streamSubStreams.length}
                  activeProjects={streamProjects.filter(p => p.status === 'In Progress').length}
                  onClick={() => setLocation(`/stream/${stream.id}`)}
                  onEdit={() => {
                    setEditingStream(stream);
                    setEditDialogOpen(true);
                  }}
                />
              );
            })}
          </div>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Latest updates across all projects</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivity.map((activity) => (
              <div
                key={activity.id}
                className="flex items-start gap-4 pb-4 border-b last:border-0 last:pb-0"
                data-testid={`activity-${activity.id}`}
              >
                <Clock className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div className="flex-1 space-y-1">
                  <p className="text-sm">{activity.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {format(activity.timestamp, 'MMM d, yyyy • h:mm a')}
                  </p>
                </div>
                <Badge variant={typeColors[activity.type]} className="text-xs">
                  {activity.type}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <EditStreamDialog
        stream={editingStream}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        onSubmit={(data) => {
          if (editingStream) {
            updateStreamMutation.mutate({ id: editingStream.id, data });
          }
        }}
        isPending={updateStreamMutation.isPending}
      />
    </div>
  );
}
