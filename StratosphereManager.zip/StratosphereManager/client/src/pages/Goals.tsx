import { CreateGoalDialog } from "@/components/CreateGoalDialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { RefreshCw, TrendingUp, Target, FileText } from "lucide-react";
import type { StrategicGoal, Project, InsertStrategicGoal } from "@shared/schema";

export default function Goals() {
  const { toast } = useToast();
  const [goalDialogOpen, setGoalDialogOpen] = useState(false);

  const { data: goals = [], isLoading: goalsLoading } = useQuery<StrategicGoal[]>({
    queryKey: ['/api/strategic-goals'],
  });

  const createGoalMutation = useMutation({
    mutationFn: async (data: InsertStrategicGoal) => {
      const payload = {
        ...data,
        targetDate: data.targetDate ? new Date(data.targetDate).toISOString() : null,
      };
      return await apiRequest("POST", "/api/strategic-goals", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/strategic-goals"] });
      setGoalDialogOpen(false);
      toast({
        title: "Goal created",
        description: "The strategic goal has been created successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create goal. Please try again.",
      });
    },
  });

  const recalculateProgressMutation = useMutation({
    mutationFn: async (goalId: string) => {
      return await apiRequest("POST", `/api/strategic-goals/${goalId}/calculate-progress`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/strategic-goals"] });
      toast({
        title: "Progress recalculated",
        description: "Strategic goal progress has been updated.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to recalculate progress. Please try again.",
      });
    },
  });

  if (goalsLoading) {
    return (
      <div className="space-y-8">
        <div className="h-8 bg-muted rounded w-48 animate-pulse" />
        <div className="grid gap-6 md:grid-cols-2">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="py-12">
                <div className="h-4 bg-muted rounded w-48 animate-pulse" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold" data-testid="text-page-title">Strategic Goals</h1>
          <p className="text-muted-foreground mt-1">
            Track organizational goals with quantitative metrics, qualitative status, and project alignment
          </p>
        </div>
        <CreateGoalDialog 
          open={goalDialogOpen}
          onOpenChange={setGoalDialogOpen}
          onSubmit={(data) => createGoalMutation.mutate(data)} 
          isPending={createGoalMutation.isPending}
        />
      </div>

      {goals.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">No strategic goals yet. Create one to get started.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6" data-testid="list-goals">
          {goals.map((goal) => (
            <GoalCard 
              key={goal.id} 
              goal={goal} 
              onRecalculate={() => recalculateProgressMutation.mutate(goal.id)}
              isRecalculating={recalculateProgressMutation.isPending}
            />
          ))}
        </div>
      )}
    </div>
  );
}

interface GoalCardProps {
  goal: StrategicGoal;
  onRecalculate: () => void;
  isRecalculating: boolean;
}

function GoalCard({ goal, onRecalculate, isRecalculating }: GoalCardProps) {
  const { data: linkedProjects = [] } = useQuery<Project[]>({
    queryKey: ['/api/strategic-goals', goal.id, 'projects'],
  });

  const hasQuantitative = goal.targetValue && goal.unit;
  const hasQualitative = goal.qualitativeTarget;
  
  const quantitativeProgress = hasQuantitative && goal.currentValue && goal.targetValue
    ? Math.min(100, Math.round((parseFloat(goal.currentValue) / parseFloat(goal.targetValue)) * 100))
    : null;

  const projectProgress = linkedProjects.length > 0
    ? Math.round(linkedProjects.reduce((sum, p) => sum + (p.progress || 0), 0) / linkedProjects.length)
    : null;

  return (
    <Card data-testid={`card-goal-${goal.id}`}>
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline" data-testid={`badge-goal-status-${goal.id}`}>
                {goal.status}
              </Badge>
            </div>
            <CardTitle className="text-xl" data-testid={`text-goal-name-${goal.id}`}>
              {goal.name}
            </CardTitle>
            <p className="text-sm text-muted-foreground mt-1" data-testid={`text-goal-description-${goal.id}`}>
              {goal.description}
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={onRecalculate}
            disabled={isRecalculating}
            data-testid={`button-recalculate-${goal.id}`}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isRecalculating ? 'animate-spin' : ''}`} />
            Recalculate
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Overall Progress</span>
            <span className="text-sm font-semibold" data-testid={`text-goal-progress-${goal.id}`}>
              {goal.progress}%
            </span>
          </div>
          <Progress value={goal.progress} className="h-2" />
          
          {(projectProgress !== null || quantitativeProgress !== null) && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              {projectProgress !== null && (
                <span>Projects {projectProgress}%</span>
              )}
              {projectProgress !== null && quantitativeProgress !== null && <span>•</span>}
              {quantitativeProgress !== null && (
                <span>KPI {quantitativeProgress}%</span>
              )}
            </div>
          )}
        </div>

        {hasQuantitative && (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium">
              <TrendingUp className="h-4 w-4" />
              Quantitative Target
            </div>
            <div className="grid grid-cols-3 gap-4 p-4 bg-muted rounded-md">
              <div>
                <p className="text-xs text-muted-foreground">Target</p>
                <p className="text-sm font-semibold" data-testid={`text-goal-target-${goal.id}`}>
                  {goal.targetValue} {goal.unit}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Current</p>
                <p className="text-sm font-semibold" data-testid={`text-goal-current-${goal.id}`}>
                  {goal.currentValue || '0'} {goal.unit}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Progress</p>
                <p className="text-sm font-semibold">
                  {quantitativeProgress !== null ? `${quantitativeProgress}%` : 'N/A'}
                </p>
              </div>
            </div>
          </div>
        )}

        {hasQualitative && (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Target className="h-4 w-4" />
              Qualitative Assessment
            </div>
            <div className="grid grid-cols-2 gap-4 p-4 bg-muted rounded-md">
              <div>
                <p className="text-xs text-muted-foreground">Target State</p>
                <p className="text-sm font-medium" data-testid={`text-goal-qual-target-${goal.id}`}>
                  {goal.qualitativeTarget}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Current Status</p>
                <Badge variant="secondary" data-testid={`badge-goal-qual-status-${goal.id}`}>
                  {goal.qualitativeStatus || 'Not Set'}
                </Badge>
              </div>
            </div>
          </div>
        )}

        {linkedProjects.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-medium">
              <FileText className="h-4 w-4" />
              Linked Projects ({linkedProjects.length})
            </div>
            <div className="space-y-2">
              {linkedProjects.map((project) => (
                <div key={project.id} className="space-y-1" data-testid={`project-${project.id}`}>
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">{project.name}</span>
                    <span className="text-muted-foreground">{project.progress}%</span>
                  </div>
                  <Progress value={project.progress} className="h-1" />
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
