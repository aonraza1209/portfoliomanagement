import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalendarDays, ListTodo, AlertTriangle, TrendingUp } from "lucide-react";
import { format, subDays, addDays, isWithinInterval } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import type { Task, Activity, RaidLog, Project } from "@shared/schema";

export default function Summary() {
  const today = new Date();
  const pastWeekStart = subDays(today, 7);
  const nextWeekEnd = addDays(today, 7);

  const { data: tasks = [], isLoading: tasksLoading, isError: tasksError } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });

  const { data: activities = [], isLoading: activitiesLoading, isError: activitiesError } = useQuery<Activity[]>({
    queryKey: ['/api/activities'],
  });

  const { data: raidLogs = [], isLoading: raidLogsLoading, isError: raidLogsError } = useQuery<RaidLog[]>({
    queryKey: ['/api/raid-logs'],
  });

  const { data: projects = [], isLoading: projectsLoading, isError: projectsError } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });

  const isLoading = tasksLoading || activitiesLoading || raidLogsLoading || projectsLoading;
  const isError = tasksError || activitiesError || raidLogsError || projectsError;

  const getProjectName = (projectId: string) => {
    const project = projects.find(p => p.id === projectId);
    return project?.name || 'Unknown Project';
  };

  const getProjectNameFromTask = (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    return task ? getProjectName(task.projectId) : 'Unknown Project';
  };

  const tasksWithProjects = tasks.map(task => ({
    ...task,
    projectName: getProjectName(task.projectId),
  }));

  const activitiesWithProjects = activities.map(activity => ({
    ...activity,
    projectName: getProjectNameFromTask(activity.taskId),
  }));

  const risksWithProjects = raidLogs
    .filter(log => log.type === 'Risk')
    .map(risk => ({
      ...risk,
      projectName: getProjectName(risk.projectId),
    }));

  const filterByDate = (items: any[], dateField: string, period: 'past' | 'next') => {
    return items.filter(item => {
      const itemDate = item[dateField];
      if (!itemDate) return false;
      const date = itemDate instanceof Date ? itemDate : new Date(itemDate);
      if (period === 'past') {
        return isWithinInterval(date, { start: pastWeekStart, end: today });
      } else {
        return isWithinInterval(date, { start: today, end: nextWeekEnd });
      }
    });
  };

  const pastWeekTasks = filterByDate(tasksWithProjects, 'endDate', 'past');
  const nextWeekTasks = filterByDate(tasksWithProjects, 'endDate', 'next');
  const pastWeekActivities = filterByDate(activitiesWithProjects, 'endDate', 'past');
  const nextWeekActivities = filterByDate(activitiesWithProjects, 'endDate', 'next');
  const pastWeekRisks = filterByDate(risksWithProjects, 'identifiedDate', 'past');
  const recentRisks = risksWithProjects.filter(r => r.status !== 'Closed').slice(0, 5);

  const getStatusVariant = (status: string) => {
    if (status === 'Completed' || status === 'Closed') return 'default';
    if (status === 'In Progress') return 'secondary';
    if (status === 'Critical' || status === 'High') return 'destructive';
    return 'outline';
  };

  const getPriorityVariant = (priority: string) => {
    if (priority === 'Critical' || priority === 'High') return 'destructive';
    if (priority === 'Medium') return 'secondary';
    return 'outline';
  };

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-semibold">Weekly Summary</h1>
          <p className="text-muted-foreground mt-1">
            Overview of tasks, activities, and risks for the past and upcoming week
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <div className="h-4 bg-muted rounded w-24 animate-pulse" />
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-muted rounded w-12 animate-pulse" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-semibold">Weekly Summary</h1>
          <p className="text-muted-foreground mt-1">
            Overview of tasks, activities, and risks for the past and upcoming week
          </p>
        </div>
        <Card className="border-destructive">
          <CardHeader>
            <CardTitle className="text-destructive">Error Loading Data</CardTitle>
            <CardDescription>
              Unable to load summary data. Please try refreshing the page or check your connection.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-semibold">Weekly Summary</h1>
        <p className="text-muted-foreground mt-1">
          Overview of tasks, activities, and risks for the past and upcoming week
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Past Week Tasks</CardTitle>
            <ListTodo className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pastWeekTasks.length}</div>
            <p className="text-xs text-muted-foreground">Due in past 7 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Next Week Tasks</CardTitle>
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{nextWeekTasks.length}</div>
            <p className="text-xs text-muted-foreground">Due in next 7 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Risks</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{recentRisks.length}</div>
            <p className="text-xs text-muted-foreground">Requiring attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Activities</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{nextWeekActivities.length}</div>
            <p className="text-xs text-muted-foreground">Scheduled next week</p>
          </CardContent>
        </Card>
      </div>

      {/* Weekly View Tabs */}
      <Tabs defaultValue="next-week" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="past-week" data-testid="tab-past-week">
            Past Week
          </TabsTrigger>
          <TabsTrigger value="next-week" data-testid="tab-next-week">
            Next Week
          </TabsTrigger>
        </TabsList>

        <TabsContent value="past-week" className="space-y-6 mt-6">
          {/* Past Week Tasks */}
          <Card>
            <CardHeader>
              <CardTitle>Tasks Completed/Due</CardTitle>
              <CardDescription>Tasks from the past 7 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pastWeekTasks.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No tasks in the past week</p>
                ) : (
                  pastWeekTasks.map((task) => (
                    <div key={task.id} className="flex items-center justify-between gap-4 p-4 border rounded-md">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium">{task.name}</p>
                          <Badge variant={getPriorityVariant(task.priority || 'Medium')} className="text-xs">
                            {task.priority || 'Medium'}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{task.projectName}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-sm text-muted-foreground">Due</p>
                          <p className="text-sm font-medium">{task.endDate ? format(new Date(task.endDate), 'MMM d') : 'N/A'}</p>
                        </div>
                        <Badge variant={getStatusVariant(task.status)}>{task.status}</Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Past Week Activities */}
          <Card>
            <CardHeader>
              <CardTitle>Activities</CardTitle>
              <CardDescription>Activities from the past 7 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pastWeekActivities.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No activities in the past week</p>
                ) : (
                  pastWeekActivities.map((activity) => (
                    <div key={activity.id} className="flex items-center justify-between gap-4 p-4 border rounded-md">
                      <div className="flex-1">
                        <p className="font-medium">{activity.name}</p>
                        <p className="text-sm text-muted-foreground">{activity.projectName}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant={getStatusVariant(activity.status)}>{activity.status}</Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Past Week Risks */}
          <Card>
            <CardHeader>
              <CardTitle>Risks Identified</CardTitle>
              <CardDescription>Risks raised in the past 7 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pastWeekRisks.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No new risks in the past week</p>
                ) : (
                  pastWeekRisks.map((risk) => (
                    <div key={risk.id} className="flex items-center justify-between gap-4 p-4 border rounded-md">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium">{risk.title}</p>
                          <Badge variant={getPriorityVariant(risk.severity || 'Medium')} className="text-xs">
                            {risk.severity || 'Medium'}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{risk.projectName}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant={getStatusVariant(risk.status)}>{risk.status}</Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="next-week" className="space-y-6 mt-6">
          {/* Next Week Tasks */}
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Tasks</CardTitle>
              <CardDescription>Tasks due in the next 7 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {nextWeekTasks.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No tasks due next week</p>
                ) : (
                  nextWeekTasks.map((task) => (
                    <div key={task.id} className="flex items-center justify-between gap-4 p-4 border rounded-md">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium">{task.name}</p>
                          <Badge variant={getPriorityVariant(task.priority || 'Medium')} className="text-xs">
                            {task.priority || 'Medium'}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{task.projectName}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-sm text-muted-foreground">Due</p>
                          <p className="text-sm font-medium">{task.endDate ? format(new Date(task.endDate), 'MMM d') : 'N/A'}</p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Next Week Activities */}
          <Card>
            <CardHeader>
              <CardTitle>Scheduled Activities</CardTitle>
              <CardDescription>Activities planned for the next 7 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {nextWeekActivities.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No activities scheduled next week</p>
                ) : (
                  nextWeekActivities.map((activity) => (
                    <div key={activity.id} className="flex items-center justify-between gap-4 p-4 border rounded-md">
                      <div className="flex-1">
                        <p className="font-medium">{activity.name}</p>
                        <p className="text-sm text-muted-foreground">{activity.projectName}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-sm text-muted-foreground">Due</p>
                          <p className="text-sm font-medium">{activity.endDate ? format(new Date(activity.endDate), 'MMM d') : 'N/A'}</p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Active Risks */}
          <Card>
            <CardHeader>
              <CardTitle>Active Risks</CardTitle>
              <CardDescription>Risks requiring attention</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentRisks.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No active risks</p>
                ) : (
                  recentRisks.map((risk) => (
                    <div key={risk.id} className="flex items-center justify-between gap-4 p-4 border rounded-md">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium">{risk.title}</p>
                          <Badge variant={getPriorityVariant(risk.severity || 'Medium')} className="text-xs">
                            {risk.severity || 'Medium'}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{risk.projectName}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant={getStatusVariant(risk.status)}>{risk.status}</Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
