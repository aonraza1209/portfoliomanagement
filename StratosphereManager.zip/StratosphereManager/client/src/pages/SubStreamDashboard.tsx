import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { ArrowLeft, TrendingUp, FolderKanban, Clock, Edit } from "lucide-react";
import { CreateProjectDialog } from "@/components/CreateProjectDialog";
import { EditSubStreamDialog } from "@/components/EditSubStreamDialog";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { InsertProject, InsertSubStream, SubStream, Project, Stream } from "@shared/schema";
import { format } from "date-fns";

interface SubStreamDashboardProps {
  subStreamId?: string;
  onBack?: () => void;
  onNavigateToProject?: (projectId: string) => void;
}

export default function SubStreamDashboard({ subStreamId, onBack, onNavigateToProject }: SubStreamDashboardProps) {
  const { toast } = useToast();
  const [editDialogOpen, setEditDialogOpen] = useState(false);

  const { data: subStream, isLoading: subStreamLoading, isError: subStreamError } = useQuery<SubStream>({
    queryKey: ['/api/substreams', subStreamId],
    enabled: !!subStreamId,
  });

  const { data: stream } = useQuery<Stream>({
    queryKey: ['/api/streams', subStream?.streamId],
    enabled: !!subStream?.streamId,
  });

  const { data: projects = [], isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ['/api/substreams', subStreamId, 'projects'],
    enabled: !!subStreamId,
  });

  const createProjectMutation = useMutation({
    mutationFn: async (data: InsertProject) => {
      return await apiRequest("POST", "/api/projects", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/substreams", subStreamId, "projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/substreams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      toast({
        title: "Project created",
        description: "The project has been created successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create project. Please try again.",
      });
    },
  });

  const updateSubStreamMutation = useMutation({
    mutationFn: async (data: Partial<InsertSubStream>) => {
      if (!subStreamId) {
        throw new Error("Sub-stream ID is required");
      }
      return await apiRequest("PATCH", `/api/substreams/${subStreamId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/substreams', subStreamId, 'projects'] });
      queryClient.invalidateQueries({ queryKey: ['/api/substreams', subStreamId] });
      queryClient.invalidateQueries({ queryKey: ['/api/substreams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/streams'] });
      setEditDialogOpen(false);
      toast({
        title: "Sub-stream updated",
        description: "The sub-stream has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update sub-stream. Please try again.",
      });
    },
  });

  if (subStreamLoading || projectsLoading) {
    return (
      <div className="space-y-8">
        <div className="h-8 bg-muted rounded w-48 animate-pulse" />
        <div className="grid gap-6 md:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <div className="h-4 bg-muted rounded w-24 animate-pulse" />
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-muted rounded w-16 animate-pulse" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (subStreamError || !subStream) {
    return (
      <div className="space-y-8">
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-4"
          data-testid="button-back"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Card>
          <CardHeader>
            <CardTitle>Error</CardTitle>
            <CardDescription>Failed to load sub-stream data. Please try again.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const avgProgress = projects.length > 0 
    ? Math.round(projects.reduce((sum, p) => sum + (p.progress || 0), 0) / projects.length)
    : 0;

  const keyMetrics = [
    { label: 'Total Projects', value: projects.length.toString(), icon: FolderKanban },
    { label: 'Avg Progress', value: `${avgProgress}%`, icon: TrendingUp },
    { label: 'Active', value: projects.filter(p => p.status === 'Active').length.toString(), icon: FolderKanban },
    { label: 'Completed', value: projects.filter(p => p.status === 'Completed').length.toString(), icon: TrendingUp },
  ];

  const statusVariant = subStream.status === 'Active' ? 'default' : subStream.status === 'On Hold' ? 'secondary' : 'outline';

  return (
    <div className="space-y-8">
      <div>
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-4"
          data-testid="button-back"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to {stream?.name || 'Stream'}
        </Button>
        
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
              <span>{stream?.name || 'Stream'}</span>
              <span>›</span>
              <span>{subStream.name}</span>
            </div>
            <h1 className="text-3xl font-semibold">{subStream.name}</h1>
            <p className="text-muted-foreground mt-1">{subStream.description || 'No description provided'}</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setEditDialogOpen(true)}
              data-testid="button-edit-substream"
            >
              <Edit className="h-4 w-4 mr-2" />
              Edit Sub-Stream
            </Button>
            <Badge variant={statusVariant} data-testid="badge-status">
              {subStream.status}
            </Badge>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {keyMetrics.map((metric, idx) => {
          const Icon = metric.icon;
          return (
            <Card key={idx}>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{metric.label}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metric.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Overall Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Sub-Stream Progress</CardTitle>
          <CardDescription>Aggregate progress across all projects in this sub-stream</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Overall Completion</p>
                <p className="text-3xl font-bold font-mono">{avgProgress}%</p>
              </div>
            </div>
            <Progress value={avgProgress} className="h-3" />
          </div>
        </CardContent>
      </Card>

      {/* Projects */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Projects</h2>
          <CreateProjectDialog
            subStreamId={subStream.id}
            onSubmit={(data) => createProjectMutation.mutate(data)}
          />
        </div>
        {projects.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">No projects yet. Create one to get started.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {projects.map((project) => (
              <Card
                key={project.id}
                className="hover-elevate cursor-pointer"
                onClick={() => onNavigateToProject?.(project.id)}
                data-testid={`card-project-${project.id}`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <CardTitle className="text-lg">{project.name}</CardTitle>
                        <Badge variant="secondary" data-testid="badge-progress">
                          {project.progress || 0}%
                        </Badge>
                      </div>
                      <CardDescription className="mt-2">
                        {project.description || 'No description'}
                      </CardDescription>
                    </div>
                    <Badge variant={project.status === 'Active' ? 'default' : project.status === 'Completed' ? 'outline' : 'secondary'}>
                      {project.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6 md:grid-cols-3 mb-4">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Timeline</p>
                      <div className="flex items-center gap-1 text-sm">
                        <Clock className="h-3 w-3" />
                        <span className="font-mono text-xs">
                          {project.startDate ? format(new Date(project.startDate), 'MMM d, yyyy') : 'Not set'} - {project.endDate ? format(new Date(project.endDate), 'MMM d, yyyy') : 'Not set'}
                        </span>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Budget</p>
                      <p className="text-sm font-medium">{project.budget ? `$${project.budget.toLocaleString()}` : 'Not set'}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Expected ROI</p>
                      <p className="text-sm font-medium">{project.roi ? `${project.roi}%` : 'Not set'}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Progress</span>
                      <span className="font-mono">{project.progress || 0}%</span>
                    </div>
                    <Progress value={project.progress || 0} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <EditSubStreamDialog
        subStream={subStream}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        onSubmit={(data) => updateSubStreamMutation.mutate(data)}
        isPending={updateSubStreamMutation.isPending}
      />
    </div>
  );
}
