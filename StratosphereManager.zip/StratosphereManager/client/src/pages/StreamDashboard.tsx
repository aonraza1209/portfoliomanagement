import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { CreateSubStreamDialog } from "@/components/CreateSubStreamDialog";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { InsertSubStream, Stream, SubStream } from "@shared/schema";

interface StreamDashboardProps {
  streamId?: string;
  onBack?: () => void;
  onNavigateToSubStream?: (subStreamId: string) => void;
}

export default function StreamDashboard({ streamId, onBack, onNavigateToSubStream }: StreamDashboardProps) {
  const { toast } = useToast();

  const { data: stream, isLoading: streamLoading, isError } = useQuery<Stream>({
    queryKey: ['/api/streams', streamId],
    enabled: !!streamId,
  });

  const { data: streamSubStreams = [] } = useQuery<SubStream[]>({
    queryKey: ['/api/streams', streamId, 'substreams'],
    enabled: !!streamId,
  });

  const createSubStreamMutation = useMutation({
    mutationFn: async (data: InsertSubStream) => {
      return await apiRequest("POST", "/api/substreams", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams", streamId, "substreams"] });
      toast({
        title: "Sub-stream created",
        description: "The sub-stream has been created successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create sub-stream. Please try again.",
      });
    },
  });

  if (streamLoading) {
    return (
      <div className="space-y-8">
        <div className="h-8 bg-muted rounded w-48 animate-pulse" />
        <div className="grid gap-6 md:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <div className="h-4 bg-muted rounded w-24 animate-pulse" />
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-muted rounded w-16 animate-pulse" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (isError || !stream) {
    return (
      <div className="space-y-8">
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-4"
          data-testid="button-back"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Portfolio
        </Button>
        <Card>
          <CardHeader>
            <CardTitle>Error</CardTitle>
            <CardDescription>Failed to load stream data. Please try again.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const statusVariant = stream.status === 'Active' ? 'default' : stream.status === 'On Hold' ? 'secondary' : 'outline';

  return (
    <div className="space-y-8">
      <div>
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-4"
          data-testid="button-back"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Portfolio
        </Button>
        
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold">{stream.name}</h1>
            <p className="text-muted-foreground mt-1">{stream.description || 'No description provided'}</p>
          </div>
          <Badge variant={statusVariant} data-testid="badge-status">
            {stream.status}
          </Badge>
        </div>
      </div>

      {/* Sub-Streams */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Sub-Streams</h2>
          <CreateSubStreamDialog
            streamId={stream.id}
            onSubmit={(data) => createSubStreamMutation.mutate(data)}
          />
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {streamSubStreams.length === 0 ? (
            <p className="text-muted-foreground col-span-2">No sub-streams yet. Create one to get started.</p>
          ) : (
            streamSubStreams.map((subStream) => (
              <Card
                key={subStream.id}
                className="hover-elevate cursor-pointer"
                onClick={() => onNavigateToSubStream?.(subStream.id)}
                data-testid={`card-substream-${subStream.id}`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{subStream.name}</CardTitle>
                      {subStream.description && (
                        <CardDescription className="mt-1">
                          {subStream.description}
                        </CardDescription>
                      )}
                    </div>
                    <Badge variant="secondary">
                      {subStream.status}
                    </Badge>
                  </div>
                </CardHeader>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
