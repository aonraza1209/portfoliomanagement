import { ProjectDetailView } from "@/components/ProjectDetailView";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { EditProjectDialog } from "@/components/EditProjectDialog";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Project, Task, RaidLog, Document, Stakeholder, Benefit, Expense, BudgetLine, Milestone, InsertProject, InsertMilestone } from "@shared/schema";

interface ProjectDetailProps {
  projectId?: string;
  onBack?: () => void;
}

export default function ProjectDetail({ projectId, onBack }: ProjectDetailProps) {
  const { toast } = useToast();
  const [editDialogOpen, setEditDialogOpen] = useState(false);

  const { data: project, isLoading: projectLoading, isError: projectError } = useQuery<Project>({
    queryKey: ['/api/projects', projectId],
    enabled: !!projectId,
  });

  const { data: tasks = [], isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ['/api/projects', projectId, 'tasks'],
    enabled: !!projectId,
  });

  const { data: allRaidLogs = [], isLoading: raidLoading } = useQuery<RaidLog[]>({
    queryKey: ['/api/projects', projectId, 'raid-logs'],
    enabled: !!projectId,
  });

  const { data: documents = [], isLoading: documentsLoading } = useQuery<Document[]>({
    queryKey: ['/api/projects', projectId, 'documents'],
    enabled: !!projectId,
  });

  const { data: stakeholders = [], isLoading: stakeholdersLoading } = useQuery<Stakeholder[]>({
    queryKey: ['/api/projects', projectId, 'stakeholders'],
    enabled: !!projectId,
  });

  const { data: benefits = [], isLoading: benefitsLoading } = useQuery<Benefit[]>({
    queryKey: ['/api/projects', projectId, 'benefits'],
    enabled: !!projectId,
  });

  const { data: expenses = [], isLoading: expensesLoading } = useQuery<Expense[]>({
    queryKey: ['/api/projects', projectId, 'expenses'],
    enabled: !!projectId,
  });

  const { data: budgetLines = [], isLoading: budgetLinesLoading } = useQuery<BudgetLine[]>({
    queryKey: ['/api/projects', projectId, 'budget-lines'],
    enabled: !!projectId,
  });

  const { data: milestones = [], isLoading: milestonesLoading } = useQuery<Milestone[]>({
    queryKey: ['/api/projects', projectId, 'milestones'],
    enabled: !!projectId,
  });

  const updateProjectMutation = useMutation({
    mutationFn: async (data: Partial<InsertProject>) => {
      if (!projectId) {
        throw new Error("Project ID is required");
      }
      return await apiRequest("PATCH", `/api/projects/${projectId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId, 'tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId, 'raid-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId, 'documents'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId, 'stakeholders'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId, 'benefits'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId, 'expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      queryClient.invalidateQueries({ queryKey: ['/api/substreams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/streams'] });
      setEditDialogOpen(false);
      toast({
        title: "Project updated",
        description: "The project has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update project. Please try again.",
      });
    },
  });

  const createMilestoneMutation = useMutation({
    mutationFn: async (data: InsertMilestone) => {
      return await apiRequest("POST", "/api/milestones", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId, 'milestones'] });
      queryClient.invalidateQueries({ queryKey: ['/api/milestones'] });
      toast({
        title: "Milestone created",
        description: "The milestone has been created successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create milestone. Please try again.",
      });
    },
  });

  if (projectLoading || tasksLoading || raidLoading || documentsLoading || stakeholdersLoading || benefitsLoading || expensesLoading || milestonesLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 bg-muted rounded w-48 animate-pulse" />
        <div className="grid gap-6 md:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <div className="h-4 bg-muted rounded w-24 animate-pulse" />
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-muted rounded w-16 animate-pulse" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (projectError || !project) {
    return (
      <div className="space-y-6">
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-2"
          data-testid="button-back"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Card>
          <CardHeader>
            <CardTitle>Error</CardTitle>
            <CardDescription>Failed to load project data. Please try again.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const raid = {
    risks: allRaidLogs.filter(log => log.type === 'Risk'),
    assumptions: allRaidLogs.filter(log => log.type === 'Assumption'),
    issues: allRaidLogs.filter(log => log.type === 'Issue'),
    dependencies: allRaidLogs.filter(log => log.type === 'Dependency'),
  };

  return (
    <div className="space-y-6">
      <Button
        variant="ghost"
        onClick={onBack}
        className="mb-2"
        data-testid="button-back"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Dashboard
      </Button>

      <ProjectDetailView
        project={project}
        tasks={tasks}
        raid={raid}
        documents={documents}
        stakeholders={stakeholders}
        benefits={benefits}
        expenses={expenses}
        budgetLines={budgetLines}
        milestones={milestones}
        onEdit={() => setEditDialogOpen(true)}
        onCreateMilestone={(data) => createMilestoneMutation.mutate(data)}
      />

      <EditProjectDialog
        project={project}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        onSubmit={(data) => updateProjectMutation.mutate(data)}
        isPending={updateProjectMutation.isPending}
      />
    </div>
  );
}
