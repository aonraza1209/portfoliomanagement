# Portfolio Management Platform - Design Guidelines

## Design Approach

**System-Based Approach**: Drawing from Linear's clean efficiency and Material Design's data-handling patterns. This enterprise PM tool prioritizes clarity, information density, and workflow efficiency over visual flair.

**Key Principles**: Hierarchical clarity, data-first layouts, action-oriented interfaces, and scannable information architecture.

---

## Typography System

**Font Stack**: Inter (primary) via Google Fonts CDN for excellent readability at small sizes and professional appearance.

**Hierarchy**:
- Page Headers: text-2xl font-semibold (Streams, Sub-Streams overview)
- Section Headers: text-lg font-semibold (Project names, module titles)
- Card Titles: text-base font-medium
- Body Text: text-sm (default for most content)
- Metadata/Labels: text-xs text-gray-600 uppercase tracking-wide
- Numerical Data: font-mono for progress percentages, dates, metrics

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, and 8 consistently.
- Component padding: p-4 or p-6
- Card spacing: space-y-4
- Section gaps: gap-6 or gap-8
- Page margins: p-6 or p-8

**Grid Strategy**:
- Dashboard overview: 3-column grid (lg:grid-cols-3) for Stream cards
- Project lists: 2-column (lg:grid-cols-2) with flexible single column detail views
- Task tables: Full-width data tables with fixed column widths
- Sidebar navigation: Fixed 240px width with collapsible option

---

## Core Layout Structure

**Three-Panel Dashboard Pattern**:
1. **Left Sidebar** (240px fixed): Hierarchical navigation tree showing Streams → Sub-Streams → Projects with expand/collapse functionality, search bar at top, quick filters
2. **Main Content Area**: Dynamic based on selection, includes breadcrumb navigation, action toolbar with primary CTAs (+ New Project, Export, etc.)
3. **Right Panel** (conditional, 320px): Context-sensitive details, upcoming deadlines, recent activity feed, quick stats

**Dashboard Home View**:
- Top Stats Bar: 4-metric overview (Total Streams, Active Projects, At-Risk Items, Overall Progress) using 1/4 width cards
- Stream Overview Grid: Cards showing each Stream with nested Sub-Stream counts, active project count, and aggregate progress bar
- Recent Activity Timeline: Chronological feed of updates with timestamps

---

## Component Library

**Navigation Cards** (Stream/Sub-Stream):
- Card with border, rounded corners, p-6
- Header with title and metadata (project count, status indicator)
- Horizontal progress bar (full width, h-2, rounded-full)
- Percentage displayed prominently (text-2xl font-bold)
- Icon library: Heroicons for consistent iconography

**Project Detail View**:
- Tabbed interface for Business Case, Schedule, Tasks, RAID Log, Documents, Stakeholders
- Tab bar sticky at top below header
- Each tab reveals dedicated workspace

**Gantt Chart Scheduler**:
- Timeline header with date markers
- Task rows with dependency connectors (SVG lines)
- Critical path tasks highlighted with distinct border treatment
- Draggable task bars for rescheduling
- Milestone markers (diamond shapes)
- Today indicator (vertical line)

**Task/Activity Table**:
- Sortable columns: Name, Priority, Assignee, Start/End, Duration, Dependencies, Progress
- Inline edit capability (click to edit fields)
- Row expansion for additional details
- Priority indicators: High (urgent flag icon), Medium (default), Low (dimmed)
- Progress shown as both percentage and mini progress bar in cell

**RAID Log Component**:
- Four-section layout: Risks, Assumptions, Issues, Dependencies
- Each item as expandable card showing summary, owner, status, mitigation
- Color-coded severity indicators (without using actual colors - use opacity/weight variations)

**Goal Alignment View**:
- Tree diagram showing Organizational Goals at top
- Branching down to linked Projects
- Visual connection lines between nodes
- Progress aggregation flowing upward
- Interactive nodes that expand to show details

**Document Management**:
- Upload dropzone with drag-and-drop
- File list with name, type, size, upload date, uploader
- Version history for tracked documents
- Preview capability for common formats

**Stakeholder Management**:
- Grid of stakeholder cards with avatar placeholder, name, role, contact info
- Communication history log
- Engagement level indicator

---

## Interaction Patterns

**Critical Path Alerts**:
- Toast notifications in top-right for delayed tasks
- Inline warning badges on affected task rows
- Dashboard alert banner when critical items at risk

**Progress Updates**:
- Click percentage to open update modal
- Slider or number input for new percentage
- Auto-calculation of rollup percentages
- Visual animation showing progress bar update

**Dependency Management**:
- Modal for adding dependencies with searchable project/task list
- Visual connector preview before confirming
- Validation preventing circular dependencies

---

## Data Visualization

**Progress Indicators**:
- Circular progress (donut chart) for individual projects showing percentage
- Horizontal bars for Stream/Sub-Stream aggregate progress
- Mini sparklines showing progress trend over time

**Dashboard Charts**:
- Burndown chart for project timeline
- Resource allocation heatmap
- Risk distribution pie chart

---

## Responsive Behavior

**Desktop-First**: Primary use case is desktop project managers
- Sidebar collapses to icon-only on smaller screens
- Tables become horizontally scrollable on tablets
- Cards stack to single column on mobile
- Gantt chart requires minimum 1024px width, shows simplified timeline view below that

---

## Forms & Inputs

**Consistent Form Elements**:
- Labels above fields with required indicator
- Input fields with border, rounded, p-2
- Dropdowns using native select styled consistently
- Date pickers with calendar overlay
- Multi-select for assignees with tag chips
- Rich text editor for business case and descriptions

**Quick Actions**:
- Floating action button (+) in bottom-right for rapid task creation
- Keyboard shortcuts displayed in tooltips
- Batch operations via checkbox selection

---

## Performance Considerations

- Virtual scrolling for task lists exceeding 100 items
- Lazy loading for document previews
- Debounced search inputs
- Optimistic UI updates for progress changes

This design creates a professional, data-dense enterprise platform that prioritizes usability and information clarity while maintaining a modern, clean aesthetic.