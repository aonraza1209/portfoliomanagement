import {
  type User,
  type InsertUser,
  type Stream,
  type InsertStream,
  type SubStream,
  type InsertSubStream,
  type Project,
  type InsertProject,
  type Task,
  type InsertTask,
  type Activity,
  type InsertActivity,
  type RaidLog,
  type InsertRaidLog,
  type Document,
  type InsertDocument,
  type Stakeholder,
  type InsertStakeholder,
  type StrategicGoal,
  type InsertStrategicGoal,
  type Milestone,
  type InsertMilestone,
  type Benefit,
  type InsertBenefit,
  type Expense,
  type InsertExpense,
  type BudgetLine,
  type InsertBudgetLine,
  type AuditLog,
  type InsertAuditLog,
  type TaskDependency,
  type InsertTaskDependency,
  type MilestoneDependency,
  type InsertMilestoneDependency,
  users,
  streams,
  subStreams,
  projects,
  tasks,
  activities,
  raidLogs,
  documents,
  stakeholders,
  strategicGoals,
  milestones,
  benefits,
  expenses,
  budgetLines,
  auditLogs,
  taskDependencies,
  milestoneDependencies,
} from "@shared/schema";
import { randomUUID } from "crypto";
import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool, neonConfig } from "@neondatabase/serverless";
import { eq, and, sql as drizzleSql, desc } from "drizzle-orm";
import ws from "ws";

const sql = drizzleSql;

neonConfig.webSocketConstructor = ws;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

export interface IStorage {
  getAllUsers(): Promise<User[]>;
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllStreams(): Promise<Stream[]>;
  getStream(id: string): Promise<Stream | undefined>;
  createStream(stream: InsertStream): Promise<Stream>;
  updateStream(id: string, stream: Partial<InsertStream>): Promise<Stream | undefined>;
  updateStreamBudget(id: string, spentToDate: string): Promise<Stream | undefined>;
  updateStreamProgress(id: string, progress: number): Promise<Stream | undefined>;
  deleteStream(id: string): Promise<boolean>;
  
  getAllSubStreams(): Promise<SubStream[]>;
  getSubStream(id: string): Promise<SubStream | undefined>;
  getSubStreamsByStreamId(streamId: string): Promise<SubStream[]>;
  createSubStream(subStream: InsertSubStream): Promise<SubStream>;
  updateSubStream(id: string, subStream: Partial<InsertSubStream>): Promise<SubStream | undefined>;
  updateSubStreamBudget(id: string, spentToDate: string): Promise<SubStream | undefined>;
  updateSubStreamProgress(id: string, progress: number): Promise<SubStream | undefined>;
  deleteSubStream(id: string): Promise<boolean>;
  
  getAllProjects(): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  getProjectsBySubStreamId(subStreamId: string): Promise<Project[]>;
  getProjectsByStrategicGoalId(strategicGoalId: string): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<InsertProject>): Promise<Project | undefined>;
  updateProjectBudget(id: string, spent: string): Promise<Project | undefined>;
  updateProjectProgress(id: string, progress: number): Promise<Project | undefined>;
  deleteProject(id: string): Promise<boolean>;
  
  getAllTasks(): Promise<Task[]>;
  getTask(id: string): Promise<Task | undefined>;
  getTasksByProjectId(projectId: string): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: string): Promise<boolean>;
  
  getAllActivities(): Promise<Activity[]>;
  getActivity(id: string): Promise<Activity | undefined>;
  getActivitiesByTaskId(taskId: string): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  updateActivity(id: string, activity: Partial<InsertActivity>): Promise<Activity | undefined>;
  deleteActivity(id: string): Promise<boolean>;
  
  getAllRaidLogs(): Promise<RaidLog[]>;
  getRaidLog(id: string): Promise<RaidLog | undefined>;
  getRaidLogsByProjectId(projectId: string): Promise<RaidLog[]>;
  createRaidLog(raidLog: InsertRaidLog): Promise<RaidLog>;
  updateRaidLog(id: string, raidLog: Partial<InsertRaidLog>): Promise<RaidLog | undefined>;
  deleteRaidLog(id: string): Promise<boolean>;
  
  getAllDocuments(): Promise<Document[]>;
  getDocument(id: string): Promise<Document | undefined>;
  getDocumentsByProjectId(projectId: string): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  deleteDocument(id: string): Promise<boolean>;
  
  getAllStakeholders(): Promise<Stakeholder[]>;
  getStakeholder(id: string): Promise<Stakeholder | undefined>;
  getStakeholdersByProjectId(projectId: string): Promise<Stakeholder[]>;
  createStakeholder(stakeholder: InsertStakeholder): Promise<Stakeholder>;
  updateStakeholder(id: string, stakeholder: Partial<InsertStakeholder>): Promise<Stakeholder | undefined>;
  deleteStakeholder(id: string): Promise<boolean>;
  
  getAllStrategicGoals(): Promise<StrategicGoal[]>;
  getStrategicGoal(id: string): Promise<StrategicGoal | undefined>;
  createStrategicGoal(goal: InsertStrategicGoal): Promise<StrategicGoal>;
  updateStrategicGoal(id: string, goal: Partial<InsertStrategicGoal>): Promise<StrategicGoal | undefined>;
  deleteStrategicGoal(id: string): Promise<boolean>;
  
  getAllMilestones(): Promise<Milestone[]>;
  getMilestone(id: string): Promise<Milestone | undefined>;
  getMilestonesByProjectId(projectId: string): Promise<Milestone[]>;
  createMilestone(milestone: InsertMilestone): Promise<Milestone>;
  updateMilestone(id: string, milestone: Partial<InsertMilestone>): Promise<Milestone | undefined>;
  deleteMilestone(id: string): Promise<boolean>;
  getMilestoneDependencies(milestoneId: string): Promise<MilestoneDependency[]>;
  createMilestoneDependency(dependency: InsertMilestoneDependency): Promise<MilestoneDependency>;
  deleteMilestoneDependency(id: string): Promise<boolean>;
  
  getAllBenefits(): Promise<Benefit[]>;
  getBenefit(id: string): Promise<Benefit | undefined>;
  getBenefitsByProjectId(projectId: string): Promise<Benefit[]>;
  createBenefit(benefit: InsertBenefit): Promise<Benefit>;
  updateBenefit(id: string, benefit: Partial<InsertBenefit>): Promise<Benefit | undefined>;
  deleteBenefit(id: string): Promise<boolean>;
  
  getAllExpenses(): Promise<Expense[]>;
  getExpense(id: string): Promise<Expense | undefined>;
  getExpensesByProjectId(projectId: string): Promise<Expense[]>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: string, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: string): Promise<boolean>;
  
  getAllBudgetLines(): Promise<BudgetLine[]>;
  getBudgetLine(id: string): Promise<BudgetLine | undefined>;
  getBudgetLinesByProjectId(projectId: string): Promise<BudgetLine[]>;
  createBudgetLine(budgetLine: InsertBudgetLine): Promise<BudgetLine>;
  updateBudgetLine(id: string, budgetLine: Partial<InsertBudgetLine>): Promise<BudgetLine | undefined>;
  deleteBudgetLine(id: string): Promise<boolean>;
  
  getAllAuditLogs(): Promise<AuditLog[]>;
  getAuditLog(id: string): Promise<AuditLog | undefined>;
  getAuditLogsByEntity(entityType: string, entityId: string): Promise<AuditLog[]>;
  getAuditLogsByProject(projectId: string): Promise<AuditLog[]>;
  createAuditLog(auditLog: InsertAuditLog): Promise<AuditLog>;
  
  getTaskDependencies(taskId: string): Promise<TaskDependency[]>;
  createTaskDependency(dependency: InsertTaskDependency): Promise<TaskDependency>;
  deleteTaskDependency(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private streams: Map<string, Stream>;
  private subStreams: Map<string, SubStream>;
  private projects: Map<string, Project>;
  private tasks: Map<string, Task>;
  private activities: Map<string, Activity>;
  private raidLogs: Map<string, RaidLog>;
  private documents: Map<string, Document>;
  private stakeholders: Map<string, Stakeholder>;
  private strategicGoals: Map<string, StrategicGoal>;
  private milestones: Map<string, Milestone>;
  private benefits: Map<string, Benefit>;
  private expenses: Map<string, Expense>;
  private budgetLines: Map<string, BudgetLine>;

  constructor() {
    this.users = new Map();
    this.streams = new Map();
    this.subStreams = new Map();
    this.projects = new Map();
    this.tasks = new Map();
    this.activities = new Map();
    this.raidLogs = new Map();
    this.documents = new Map();
    this.stakeholders = new Map();
    this.strategicGoals = new Map();
    this.milestones = new Map();
    this.benefits = new Map();
    this.expenses = new Map();
    this.budgetLines = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getAllStreams(): Promise<Stream[]> {
    return Array.from(this.streams.values());
  }

  async getStream(id: string): Promise<Stream | undefined> {
    return this.streams.get(id);
  }

  async createStream(insertStream: InsertStream): Promise<Stream> {
    const id = randomUUID();
    const stream: Stream = {
      ...insertStream,
      id,
      status: insertStream.status || 'Active',
      ownerId: insertStream.ownerId || null,
      strategicGoalIds: insertStream.strategicGoalIds || null,
      allocatedBudget: insertStream.allocatedBudget || null,
      spentToDate: '0',
      progress: 0,
    };
    this.streams.set(id, stream);
    return stream;
  }

  async updateStream(id: string, updates: Partial<InsertStream>): Promise<Stream | undefined> {
    const stream = this.streams.get(id);
    if (!stream) return undefined;
    const updated = { ...stream, ...updates };
    this.streams.set(id, updated);
    return updated;
  }

  async updateStreamBudget(id: string, spentToDate: string): Promise<Stream | undefined> {
    const stream = this.streams.get(id);
    if (!stream) return undefined;
    const updated = { ...stream, spentToDate };
    this.streams.set(id, updated);
    return updated;
  }

  async updateStreamProgress(id: string, progress: number): Promise<Stream | undefined> {
    const stream = this.streams.get(id);
    if (!stream) return undefined;
    const updated = { ...stream, progress };
    this.streams.set(id, updated);
    return updated;
  }

  async deleteStream(id: string): Promise<boolean> {
    return this.streams.delete(id);
  }

  async getAllSubStreams(): Promise<SubStream[]> {
    return Array.from(this.subStreams.values());
  }

  async getSubStream(id: string): Promise<SubStream | undefined> {
    return this.subStreams.get(id);
  }

  async getSubStreamsByStreamId(streamId: string): Promise<SubStream[]> {
    return Array.from(this.subStreams.values()).filter(
      (ss) => ss.streamId === streamId,
    );
  }

  async createSubStream(insertSubStream: InsertSubStream): Promise<SubStream> {
    const id = randomUUID();
    const subStream: SubStream = {
      ...insertSubStream,
      id,
      status: insertSubStream.status || 'Active',
      ownerId: insertSubStream.ownerId || null,
      spentToDate: '0',
      progress: 0,
    };
    this.subStreams.set(id, subStream);
    return subStream;
  }

  async updateSubStream(id: string, updates: Partial<InsertSubStream>): Promise<SubStream | undefined> {
    const subStream = this.subStreams.get(id);
    if (!subStream) return undefined;
    const updated = { ...subStream, ...updates };
    this.subStreams.set(id, updated);
    return updated;
  }

  async updateSubStreamBudget(id: string, spentToDate: string): Promise<SubStream | undefined> {
    const subStream = this.subStreams.get(id);
    if (!subStream) return undefined;
    const updated = { ...subStream, spentToDate };
    this.subStreams.set(id, updated);
    return updated;
  }

  async updateSubStreamProgress(id: string, progress: number): Promise<SubStream | undefined> {
    const subStream = this.subStreams.get(id);
    if (!subStream) return undefined;
    const updated = { ...subStream, progress };
    this.subStreams.set(id, updated);
    return updated;
  }

  async deleteSubStream(id: string): Promise<boolean> {
    return this.subStreams.delete(id);
  }

  async getAllProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getProjectsBySubStreamId(subStreamId: string): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(
      (p) => p.subStreamId === subStreamId,
    );
  }

  async getProjectsByStrategicGoalId(strategicGoalId: string): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(
      (p) => p.strategicGoalId === strategicGoalId,
    );
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const project: Project = {
      ...insertProject,
      id,
      status: insertProject.status || 'Planning',
      strategicGoalId: insertProject.strategicGoalId ?? null,
      startDate: insertProject.startDate || null,
      endDate: insertProject.endDate || null,
      budget: insertProject.budget || null,
      spent: "0",
      progress: insertProject.progress || 0,
      ownerId: insertProject.ownerId || null,
      businessCase: insertProject.businessCase || null,
      expectedBenefits: insertProject.expectedBenefits || null,
      actualBenefits: null,
      roi: insertProject.roi || null,
      paybackPeriod: insertProject.paybackPeriod || null,
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: string, updates: Partial<InsertProject>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    const updated = { ...project, ...updates };
    this.projects.set(id, updated);
    return updated;
  }

  async updateProjectBudget(id: string, spent: string): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    const updated = { ...project, spent };
    this.projects.set(id, updated);
    return updated;
  }

  async updateProjectProgress(id: string, progress: number): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    const updated = { ...project, progress };
    this.projects.set(id, updated);
    return updated;
  }

  async deleteProject(id: string): Promise<boolean> {
    return this.projects.delete(id);
  }

  async getAllTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }

  async getTask(id: string): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async getTasksByProjectId(projectId: string): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (t) => t.projectId === projectId,
    );
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = randomUUID();
    const task: Task = {
      id,
      name: insertTask.name as unknown as string,
      projectId: insertTask.projectId as unknown as string,
      milestoneId: (insertTask.milestoneId ?? null) as string | null,
      parentTaskId: (insertTask.parentTaskId ?? null) as string | null,
      description: (insertTask.description ?? null) as string | null,
      assignedTo: (insertTask.assignedTo ?? null) as string | null,
      status: (insertTask.status ?? 'Not Started') as string,
      priority: (insertTask.priority ?? 'Medium') as string,
      startDate: (insertTask.startDate ?? null) as Date | null,
      endDate: (insertTask.endDate ?? null) as Date | null,
      progress: (insertTask.progress ?? 0) as number,
      dependencyIds: (insertTask.dependencyIds ?? null) as string[] | null,
      isCriticalPath: false,
      estimatedHours: (insertTask.estimatedHours ?? null) as number | null,
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: string, updates: Partial<InsertTask>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    const updated = { ...task, ...updates } as Task;
    this.tasks.set(id, updated);
    return updated;
  }

  async deleteTask(id: string): Promise<boolean> {
    return this.tasks.delete(id);
  }

  async getAllActivities(): Promise<Activity[]> {
    return Array.from(this.activities.values());
  }

  async getActivity(id: string): Promise<Activity | undefined> {
    return this.activities.get(id);
  }

  async getActivitiesByTaskId(taskId: string): Promise<Activity[]> {
    return Array.from(this.activities.values()).filter(
      (a) => a.taskId === taskId,
    );
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = randomUUID();
    const activity: Activity = {
      ...insertActivity,
      id,
      description: insertActivity.description || null,
      assignedTo: insertActivity.assignedTo || null,
      status: insertActivity.status || 'Not Started',
      startDate: insertActivity.startDate || null,
      endDate: insertActivity.endDate || null,
      progress: insertActivity.progress || 0,
    };
    this.activities.set(id, activity);
    return activity;
  }

  async updateActivity(id: string, updates: Partial<InsertActivity>): Promise<Activity | undefined> {
    const activity = this.activities.get(id);
    if (!activity) return undefined;
    const updated = { ...activity, ...updates };
    this.activities.set(id, updated);
    return updated;
  }

  async deleteActivity(id: string): Promise<boolean> {
    return this.activities.delete(id);
  }

  async getAllRaidLogs(): Promise<RaidLog[]> {
    return Array.from(this.raidLogs.values());
  }

  async getRaidLog(id: string): Promise<RaidLog | undefined> {
    return this.raidLogs.get(id);
  }

  async getRaidLogsByProjectId(projectId: string): Promise<RaidLog[]> {
    return Array.from(this.raidLogs.values()).filter(
      (r) => r.projectId === projectId,
    );
  }

  async createRaidLog(insertRaidLog: InsertRaidLog): Promise<RaidLog> {
    const id = randomUUID();
    const raidLog: RaidLog = {
      ...insertRaidLog,
      id,
      status: insertRaidLog.status || 'Open',
      severity: insertRaidLog.severity || null,
      owner: insertRaidLog.owner || null,
      mitigationPlan: insertRaidLog.mitigationPlan || null,
      dateRaised: new Date(),
    };
    this.raidLogs.set(id, raidLog);
    return raidLog;
  }

  async updateRaidLog(id: string, updates: Partial<InsertRaidLog>): Promise<RaidLog | undefined> {
    const raidLog = this.raidLogs.get(id);
    if (!raidLog) return undefined;
    const updated = { ...raidLog, ...updates };
    this.raidLogs.set(id, updated);
    return updated;
  }

  async deleteRaidLog(id: string): Promise<boolean> {
    return this.raidLogs.delete(id);
  }

  async getAllDocuments(): Promise<Document[]> {
    return Array.from(this.documents.values());
  }

  async getDocument(id: string): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getDocumentsByProjectId(projectId: string): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(
      (d) => d.projectId === projectId,
    );
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = randomUUID();
    const document: Document = {
      ...insertDocument,
      id,
      uploadedBy: insertDocument.uploadedBy || null,
      uploadedAt: new Date(),
    };
    this.documents.set(id, document);
    return document;
  }

  async deleteDocument(id: string): Promise<boolean> {
    return this.documents.delete(id);
  }

  async getAllStakeholders(): Promise<Stakeholder[]> {
    return Array.from(this.stakeholders.values());
  }

  async getStakeholder(id: string): Promise<Stakeholder | undefined> {
    return this.stakeholders.get(id);
  }

  async getStakeholdersByProjectId(projectId: string): Promise<Stakeholder[]> {
    return Array.from(this.stakeholders.values()).filter(
      (s) => s.projectId === projectId,
    );
  }

  async createStakeholder(insertStakeholder: InsertStakeholder): Promise<Stakeholder> {
    const id = randomUUID();
    const stakeholder: Stakeholder = {
      ...insertStakeholder,
      id,
      email: insertStakeholder.email || null,
      engagementStrategy: insertStakeholder.engagementStrategy || null,
    };
    this.stakeholders.set(id, stakeholder);
    return stakeholder;
  }

  async updateStakeholder(id: string, updates: Partial<InsertStakeholder>): Promise<Stakeholder | undefined> {
    const stakeholder = this.stakeholders.get(id);
    if (!stakeholder) return undefined;
    const updated = { ...stakeholder, ...updates };
    this.stakeholders.set(id, updated);
    return updated;
  }

  async deleteStakeholder(id: string): Promise<boolean> {
    return this.stakeholders.delete(id);
  }

  async getAllStrategicGoals(): Promise<StrategicGoal[]> {
    return Array.from(this.strategicGoals.values());
  }

  async getStrategicGoal(id: string): Promise<StrategicGoal | undefined> {
    return this.strategicGoals.get(id);
  }

  async createStrategicGoal(insertGoal: InsertStrategicGoal): Promise<StrategicGoal> {
    const id = randomUUID();
    const goal: StrategicGoal = {
      ...insertGoal,
      id,
      status: insertGoal.status || 'Active',
      progress: 0,
      targetDate: insertGoal.targetDate || null,
      targetValue: insertGoal.targetValue || null,
      currentValue: null,
      unit: insertGoal.unit || null,
      qualitativeTarget: insertGoal.qualitativeTarget || null,
      qualitativeStatus: insertGoal.qualitativeStatus || null,
    };
    this.strategicGoals.set(id, goal);
    return goal;
  }

  async updateStrategicGoal(id: string, updates: Partial<InsertStrategicGoal>): Promise<StrategicGoal | undefined> {
    const goal = this.strategicGoals.get(id);
    if (!goal) return undefined;
    const updated = { ...goal, ...updates };
    this.strategicGoals.set(id, updated);
    return updated;
  }

  async deleteStrategicGoal(id: string): Promise<boolean> {
    return this.strategicGoals.delete(id);
  }

  async getAllMilestones(): Promise<Milestone[]> {
    return Array.from(this.milestones.values());
  }

  async getMilestone(id: string): Promise<Milestone | undefined> {
    return this.milestones.get(id);
  }

  async getMilestonesByProjectId(projectId: string): Promise<Milestone[]> {
    return Array.from(this.milestones.values()).filter(
      (m) => m.projectId === projectId,
    );
  }

  async createMilestone(insertMilestone: InsertMilestone): Promise<Milestone> {
    const id = randomUUID();
    const milestone: Milestone = {
      ...insertMilestone,
      id,
      description: insertMilestone.description || null,
      status: insertMilestone.status || 'Pending',
      completedDate: null,
      ownerId: insertMilestone.ownerId || null,
    };
    this.milestones.set(id, milestone);
    return milestone;
  }

  async updateMilestone(id: string, updates: Partial<InsertMilestone>): Promise<Milestone | undefined> {
    const milestone = this.milestones.get(id);
    if (!milestone) return undefined;
    const updated = { ...milestone, ...updates };
    this.milestones.set(id, updated);
    return updated;
  }

  async deleteMilestone(id: string): Promise<boolean> {
    return this.milestones.delete(id);
  }

  async getMilestoneDependencies(milestoneId: string): Promise<MilestoneDependency[]> {
    return [];
  }
  
  async createMilestoneDependency(dependency: InsertMilestoneDependency): Promise<MilestoneDependency> {
    const dep: MilestoneDependency = {
      id: randomUUID(),
      ...dependency,
      createdAt: new Date(),
    };
    return dep;
  }
  
  async deleteMilestoneDependency(id: string): Promise<boolean> {
    return true;
  }

  async getAllBenefits(): Promise<Benefit[]> {
    return Array.from(this.benefits.values());
  }

  async getBenefit(id: string): Promise<Benefit | undefined> {
    return this.benefits.get(id);
  }

  async getBenefitsByProjectId(projectId: string): Promise<Benefit[]> {
    return Array.from(this.benefits.values()).filter(
      (b) => b.projectId === projectId,
    );
  }

  async createBenefit(insertBenefit: InsertBenefit): Promise<Benefit> {
    const id = randomUUID();
    const benefit: Benefit = {
      ...insertBenefit,
      id,
      type: insertBenefit.type || 'Qualitative',
      description: insertBenefit.description || null,
      targetValue: insertBenefit.targetValue || null,
      actualValue: null,
      unit: insertBenefit.unit || null,
      status: insertBenefit.status || 'Planned',
      achievementDate: insertBenefit.achievementDate || null,
      notes: insertBenefit.notes || null,
      category: insertBenefit.category || 'Other',
    };
    this.benefits.set(id, benefit);
    return benefit;
  }

  async updateBenefit(id: string, updates: Partial<InsertBenefit>): Promise<Benefit | undefined> {
    const benefit = this.benefits.get(id);
    if (!benefit) return undefined;
    const updated = { ...benefit, ...updates };
    this.benefits.set(id, updated);
    return updated;
  }

  async deleteBenefit(id: string): Promise<boolean> {
    return this.benefits.delete(id);
  }
  
  async getAllExpenses(): Promise<Expense[]> {
    return Array.from(this.expenses.values());
  }
  
  async getExpense(id: string): Promise<Expense | undefined> {
    return this.expenses.get(id);
  }
  
  async getExpensesByProjectId(projectId: string): Promise<Expense[]> {
    return Array.from(this.expenses.values()).filter(expense => expense.projectId === projectId);
  }
  
  async createExpense(expense: InsertExpense): Promise<Expense> {
    const newExpense: Expense = {
      ...expense,
      id: randomUUID(),
      description: expense.description || null,
      createdAt: new Date(),
    };
    this.expenses.set(newExpense.id, newExpense);
    return newExpense;
  }
  
  async updateExpense(id: string, expense: Partial<InsertExpense>): Promise<Expense | undefined> {
    const existing = this.expenses.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...expense };
    this.expenses.set(id, updated);
    return updated;
  }
  
  async deleteExpense(id: string): Promise<boolean> {
    return this.expenses.delete(id);
  }

  async getAllBudgetLines(): Promise<BudgetLine[]> {
    return Array.from(this.budgetLines.values());
  }

  async getBudgetLine(id: string): Promise<BudgetLine | undefined> {
    return this.budgetLines.get(id);
  }

  async getBudgetLinesByProjectId(projectId: string): Promise<BudgetLine[]> {
    return Array.from(this.budgetLines.values()).filter(bl => bl.projectId === projectId);
  }

  async createBudgetLine(budgetLine: InsertBudgetLine): Promise<BudgetLine> {
    const id = randomUUID();
    const newBudgetLine: BudgetLine = {
      ...budgetLine,
      id,
      description: budgetLine.description || null,
      createdAt: new Date(),
    };
    this.budgetLines.set(id, newBudgetLine);
    return newBudgetLine;
  }

  async updateBudgetLine(id: string, budgetLine: Partial<InsertBudgetLine>): Promise<BudgetLine | undefined> {
    const existing = this.budgetLines.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...budgetLine };
    this.budgetLines.set(id, updated);
    return updated;
  }

  async deleteBudgetLine(id: string): Promise<boolean> {
    return this.budgetLines.delete(id);
  }

  async getAllAuditLogs(): Promise<AuditLog[]> {
    return [];
  }

  async getAuditLog(id: string): Promise<AuditLog | undefined> {
    return undefined;
  }

  async getAuditLogsByEntity(entityType: string, entityId: string): Promise<AuditLog[]> {
    return [];
  }

  async getAuditLogsByProject(projectId: string): Promise<AuditLog[]> {
    return [];
  }

  async createAuditLog(auditLog: InsertAuditLog): Promise<AuditLog> {
    const log: AuditLog = {
      id: randomUUID(),
      ...auditLog,
      timestamp: new Date(),
      performedBy: auditLog.performedBy || null,
      parentEntityId: auditLog.parentEntityId || null,
      changes: auditLog.changes || null,
    };
    return log;
  }
  
  async getTaskDependencies(taskId: string): Promise<TaskDependency[]> {
    return [];
  }
  
  async createTaskDependency(dependency: InsertTaskDependency): Promise<TaskDependency> {
    const dep: TaskDependency = {
      id: randomUUID(),
      ...dependency,
      createdAt: new Date(),
    };
    return dep;
  }
  
  async deleteTaskDependency(id: string): Promise<boolean> {
    return true;
  }
}

export class DbStorage implements IStorage {
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async getAllStreams(): Promise<Stream[]> {
    return await db.select().from(streams);
  }

  async getStream(id: string): Promise<Stream | undefined> {
    const result = await db.select().from(streams).where(eq(streams.id, id)).limit(1);
    return result[0];
  }

  async createStream(stream: InsertStream): Promise<Stream> {
    const result = await db.insert(streams).values(stream).returning();
    return result[0];
  }

  async updateStream(id: string, updates: Partial<InsertStream>): Promise<Stream | undefined> {
    const existing = await this.getStream(id);
    if (!existing) return undefined;
    const result = await db.update(streams).set(updates).where(eq(streams.id, id)).returning();
    return result[0];
  }

  async updateStreamBudget(id: string, spentToDate: string): Promise<Stream | undefined> {
    const existing = await this.getStream(id);
    if (!existing) return undefined;
    const result = await db.update(streams).set({ spentToDate }).where(eq(streams.id, id)).returning();
    return result[0];
  }

  async updateStreamProgress(id: string, progress: number): Promise<Stream | undefined> {
    const existing = await this.getStream(id);
    if (!existing) return undefined;
    const result = await db.update(streams).set({ progress }).where(eq(streams.id, id)).returning();
    return result[0];
  }

  async deleteStream(id: string): Promise<boolean> {
    const result = await db.delete(streams).where(eq(streams.id, id)).returning();
    return result.length > 0;
  }

  async getAllSubStreams(): Promise<SubStream[]> {
    return await db.select().from(subStreams);
  }

  async getSubStream(id: string): Promise<SubStream | undefined> {
    const result = await db.select().from(subStreams).where(eq(subStreams.id, id)).limit(1);
    return result[0];
  }

  async getSubStreamsByStreamId(streamId: string): Promise<SubStream[]> {
    return await db.select().from(subStreams).where(eq(subStreams.streamId, streamId));
  }

  async createSubStream(subStream: InsertSubStream): Promise<SubStream> {
    const result = await db.insert(subStreams).values(subStream).returning();
    return result[0];
  }

  async updateSubStream(id: string, updates: Partial<InsertSubStream>): Promise<SubStream | undefined> {
    const existing = await this.getSubStream(id);
    if (!existing) return undefined;
    const result = await db.update(subStreams).set(updates).where(eq(subStreams.id, id)).returning();
    return result[0];
  }

  async updateSubStreamBudget(id: string, spentToDate: string): Promise<SubStream | undefined> {
    const existing = await this.getSubStream(id);
    if (!existing) return undefined;
    const result = await db.update(subStreams).set({ spentToDate }).where(eq(subStreams.id, id)).returning();
    return result[0];
  }

  async updateSubStreamProgress(id: string, progress: number): Promise<SubStream | undefined> {
    const existing = await this.getSubStream(id);
    if (!existing) return undefined;
    const result = await db.update(subStreams).set({ progress }).where(eq(subStreams.id, id)).returning();
    return result[0];
  }

  async deleteSubStream(id: string): Promise<boolean> {
    const result = await db.delete(subStreams).where(eq(subStreams.id, id)).returning();
    return result.length > 0;
  }

  async getAllProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }

  async getProject(id: string): Promise<Project | undefined> {
    const result = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
    return result[0];
  }

  async getProjectsBySubStreamId(subStreamId: string): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.subStreamId, subStreamId));
  }

  async getProjectsByStrategicGoalId(strategicGoalId: string): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.strategicGoalId, strategicGoalId));
  }

  async createProject(project: InsertProject): Promise<Project> {
    const result = await db.insert(projects).values(project).returning();
    return result[0];
  }

  async updateProject(id: string, updates: Partial<InsertProject>): Promise<Project | undefined> {
    const existing = await this.getProject(id);
    if (!existing) return undefined;
    const result = await db.update(projects).set(updates).where(eq(projects.id, id)).returning();
    return result[0];
  }

  async updateProjectBudget(id: string, spent: string): Promise<Project | undefined> {
    const existing = await this.getProject(id);
    if (!existing) return undefined;
    const result = await db.update(projects).set({ spent }).where(eq(projects.id, id)).returning();
    return result[0];
  }

  async updateProjectProgress(id: string, progress: number): Promise<Project | undefined> {
    const existing = await this.getProject(id);
    if (!existing) return undefined;
    const result = await db.update(projects).set({ progress }).where(eq(projects.id, id)).returning();
    return result[0];
  }

  async deleteProject(id: string): Promise<boolean> {
    const result = await db.delete(projects).where(eq(projects.id, id)).returning();
    return result.length > 0;
  }

  async getAllTasks(): Promise<Task[]> {
    return await db.select().from(tasks) as Task[];
  }

  async getTask(id: string): Promise<Task | undefined> {
    const result = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1) as Task[];
    return result[0];
  }

  async getTasksByProjectId(projectId: string): Promise<Task[]> {
    return await db.select().from(tasks).where(eq(tasks.projectId, projectId)) as Task[];
  }

  async createTask(task: InsertTask): Promise<Task> {
    const result = await db.insert(tasks).values(task).returning() as Task[];
    return result[0];
  }

  async updateTask(id: string, updates: Partial<InsertTask>): Promise<Task | undefined> {
    const existing = await this.getTask(id);
    if (!existing) return undefined;
    const result = await db.update(tasks).set(updates).where(eq(tasks.id, id)).returning() as Task[];
    return result[0];
  }

  async deleteTask(id: string): Promise<boolean> {
    const result = await db.delete(tasks).where(eq(tasks.id, id)).returning() as Task[];
    return result.length > 0;
  }

  async getAllActivities(): Promise<Activity[]> {
    return await db.select().from(activities);
  }

  async getActivity(id: string): Promise<Activity | undefined> {
    const result = await db.select().from(activities).where(eq(activities.id, id)).limit(1);
    return result[0];
  }

  async getActivitiesByTaskId(taskId: string): Promise<Activity[]> {
    return await db.select().from(activities).where(eq(activities.taskId, taskId));
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const result = await db.insert(activities).values(activity).returning();
    return result[0];
  }

  async updateActivity(id: string, updates: Partial<InsertActivity>): Promise<Activity | undefined> {
    const existing = await this.getActivity(id);
    if (!existing) return undefined;
    const result = await db.update(activities).set(updates).where(eq(activities.id, id)).returning();
    return result[0];
  }

  async deleteActivity(id: string): Promise<boolean> {
    const result = await db.delete(activities).where(eq(activities.id, id)).returning();
    return result.length > 0;
  }

  async getAllRaidLogs(): Promise<RaidLog[]> {
    return await db.select().from(raidLogs);
  }

  async getRaidLog(id: string): Promise<RaidLog | undefined> {
    const result = await db.select().from(raidLogs).where(eq(raidLogs.id, id)).limit(1);
    return result[0];
  }

  async getRaidLogsByProjectId(projectId: string): Promise<RaidLog[]> {
    return await db.select().from(raidLogs).where(eq(raidLogs.projectId, projectId));
  }

  async createRaidLog(raidLog: InsertRaidLog): Promise<RaidLog> {
    const result = await db.insert(raidLogs).values(raidLog).returning();
    return result[0];
  }

  async updateRaidLog(id: string, updates: Partial<InsertRaidLog>): Promise<RaidLog | undefined> {
    const existing = await this.getRaidLog(id);
    if (!existing) return undefined;
    const result = await db.update(raidLogs).set(updates).where(eq(raidLogs.id, id)).returning();
    return result[0];
  }

  async deleteRaidLog(id: string): Promise<boolean> {
    const result = await db.delete(raidLogs).where(eq(raidLogs.id, id)).returning();
    return result.length > 0;
  }

  async getAllDocuments(): Promise<Document[]> {
    return await db.select().from(documents);
  }

  async getDocument(id: string): Promise<Document | undefined> {
    const result = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
    return result[0];
  }

  async getDocumentsByProjectId(projectId: string): Promise<Document[]> {
    return await db.select().from(documents).where(eq(documents.projectId, projectId));
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const result = await db.insert(documents).values(document).returning();
    return result[0];
  }

  async deleteDocument(id: string): Promise<boolean> {
    const result = await db.delete(documents).where(eq(documents.id, id)).returning();
    return result.length > 0;
  }

  async getAllStakeholders(): Promise<Stakeholder[]> {
    return await db.select().from(stakeholders);
  }

  async getStakeholder(id: string): Promise<Stakeholder | undefined> {
    const result = await db.select().from(stakeholders).where(eq(stakeholders.id, id)).limit(1);
    return result[0];
  }

  async getStakeholdersByProjectId(projectId: string): Promise<Stakeholder[]> {
    return await db.select().from(stakeholders).where(eq(stakeholders.projectId, projectId));
  }

  async createStakeholder(stakeholder: InsertStakeholder): Promise<Stakeholder> {
    const result = await db.insert(stakeholders).values(stakeholder).returning();
    return result[0];
  }

  async updateStakeholder(id: string, updates: Partial<InsertStakeholder>): Promise<Stakeholder | undefined> {
    const existing = await this.getStakeholder(id);
    if (!existing) return undefined;
    const result = await db.update(stakeholders).set(updates).where(eq(stakeholders.id, id)).returning();
    return result[0];
  }

  async deleteStakeholder(id: string): Promise<boolean> {
    const result = await db.delete(stakeholders).where(eq(stakeholders.id, id)).returning();
    return result.length > 0;
  }

  async getAllStrategicGoals(): Promise<StrategicGoal[]> {
    return await db.select().from(strategicGoals);
  }

  async getStrategicGoal(id: string): Promise<StrategicGoal | undefined> {
    const result = await db.select().from(strategicGoals).where(eq(strategicGoals.id, id)).limit(1);
    return result[0];
  }

  async createStrategicGoal(goal: InsertStrategicGoal): Promise<StrategicGoal> {
    const result = await db.insert(strategicGoals).values(goal).returning();
    return result[0];
  }

  async updateStrategicGoal(id: string, updates: Partial<InsertStrategicGoal>): Promise<StrategicGoal | undefined> {
    const existing = await this.getStrategicGoal(id);
    if (!existing) return undefined;
    const result = await db.update(strategicGoals).set(updates).where(eq(strategicGoals.id, id)).returning();
    return result[0];
  }

  async deleteStrategicGoal(id: string): Promise<boolean> {
    const result = await db.delete(strategicGoals).where(eq(strategicGoals.id, id)).returning();
    return result.length > 0;
  }

  async getAllMilestones(): Promise<Milestone[]> {
    return await db.select().from(milestones);
  }

  async getMilestone(id: string): Promise<Milestone | undefined> {
    const result = await db.select().from(milestones).where(eq(milestones.id, id)).limit(1);
    return result[0];
  }

  async getMilestonesByProjectId(projectId: string): Promise<Milestone[]> {
    return await db.select().from(milestones).where(eq(milestones.projectId, projectId));
  }

  async createMilestone(milestone: InsertMilestone): Promise<Milestone> {
    const result = await db.insert(milestones).values(milestone).returning();
    return result[0];
  }

  async updateMilestone(id: string, updates: Partial<InsertMilestone>): Promise<Milestone | undefined> {
    const existing = await this.getMilestone(id);
    if (!existing) return undefined;
    const result = await db.update(milestones).set(updates).where(eq(milestones.id, id)).returning();
    return result[0];
  }

  async deleteMilestone(id: string): Promise<boolean> {
    const result = await db.delete(milestones).where(eq(milestones.id, id)).returning();
    return result.length > 0;
  }

  async getMilestoneDependencies(milestoneId: string): Promise<MilestoneDependency[]> {
    return await db.select().from(milestoneDependencies).where(eq(milestoneDependencies.milestoneId, milestoneId));
  }
  
  async createMilestoneDependency(dependency: InsertMilestoneDependency): Promise<MilestoneDependency> {
    const result = await db.insert(milestoneDependencies).values(dependency).returning();
    return result[0];
  }
  
  async deleteMilestoneDependency(id: string): Promise<boolean> {
    const result = await db.delete(milestoneDependencies).where(eq(milestoneDependencies.id, id)).returning();
    return result.length > 0;
  }

  async getAllBenefits(): Promise<Benefit[]> {
    return await db.select().from(benefits);
  }

  async getBenefit(id: string): Promise<Benefit | undefined> {
    const result = await db.select().from(benefits).where(eq(benefits.id, id)).limit(1);
    return result[0];
  }

  async getBenefitsByProjectId(projectId: string): Promise<Benefit[]> {
    return await db.select().from(benefits).where(eq(benefits.projectId, projectId));
  }

  async createBenefit(benefit: InsertBenefit): Promise<Benefit> {
    const result = await db.insert(benefits).values(benefit).returning();
    return result[0];
  }

  async updateBenefit(id: string, updates: Partial<InsertBenefit>): Promise<Benefit | undefined> {
    const existing = await this.getBenefit(id);
    if (!existing) return undefined;
    const result = await db.update(benefits).set(updates).where(eq(benefits.id, id)).returning();
    return result[0];
  }

  async deleteBenefit(id: string): Promise<boolean> {
    const result = await db.delete(benefits).where(eq(benefits.id, id)).returning();
    return result.length > 0;
  }

  async getAllExpenses(): Promise<Expense[]> {
    return await db.select().from(expenses);
  }

  async getExpense(id: string): Promise<Expense | undefined> {
    const result = await db.select().from(expenses).where(eq(expenses.id, id)).limit(1);
    return result[0];
  }

  async getExpensesByProjectId(projectId: string): Promise<Expense[]> {
    return await db.select().from(expenses).where(eq(expenses.projectId, projectId));
  }

  async createExpense(expense: InsertExpense): Promise<Expense> {
    const result = await db.insert(expenses).values(expense).returning();
    return result[0];
  }

  async updateExpense(id: string, updates: Partial<InsertExpense>): Promise<Expense | undefined> {
    const existing = await this.getExpense(id);
    if (!existing) return undefined;
    const result = await db.update(expenses).set(updates).where(eq(expenses.id, id)).returning();
    return result[0];
  }

  async deleteExpense(id: string): Promise<boolean> {
    const result = await db.delete(expenses).where(eq(expenses.id, id)).returning();
    return result.length > 0;
  }

  async getAllBudgetLines(): Promise<BudgetLine[]> {
    return await db.select().from(budgetLines);
  }

  async getBudgetLine(id: string): Promise<BudgetLine | undefined> {
    const result = await db.select().from(budgetLines).where(eq(budgetLines.id, id)).limit(1);
    return result[0];
  }

  async getBudgetLinesByProjectId(projectId: string): Promise<BudgetLine[]> {
    return await db.select().from(budgetLines).where(eq(budgetLines.projectId, projectId));
  }

  async createBudgetLine(budgetLine: InsertBudgetLine): Promise<BudgetLine> {
    const result = await db.insert(budgetLines).values(budgetLine).returning();
    return result[0];
  }

  async updateBudgetLine(id: string, updates: Partial<InsertBudgetLine>): Promise<BudgetLine | undefined> {
    const existing = await this.getBudgetLine(id);
    if (!existing) return undefined;
    const result = await db.update(budgetLines).set(updates).where(eq(budgetLines.id, id)).returning();
    return result[0];
  }

  async deleteBudgetLine(id: string): Promise<boolean> {
    const result = await db.delete(budgetLines).where(eq(budgetLines.id, id)).returning();
    return result.length > 0;
  }

  async getAllAuditLogs(): Promise<AuditLog[]> {
    return await db.select().from(auditLogs).orderBy(desc(auditLogs.timestamp));
  }

  async getAuditLog(id: string): Promise<AuditLog | undefined> {
    const result = await db.select().from(auditLogs).where(eq(auditLogs.id, id)).limit(1);
    return result[0];
  }

  async getAuditLogsByEntity(entityType: string, entityId: string): Promise<AuditLog[]> {
    return await db.select().from(auditLogs)
      .where(and(eq(auditLogs.entityType, entityType), eq(auditLogs.entityId, entityId)))
      .orderBy(desc(auditLogs.timestamp));
  }

  async getAuditLogsByProject(projectId: string): Promise<AuditLog[]> {
    const result = await db.select().from(auditLogs).where(
      sql`${auditLogs.entityId} = ${projectId} OR ${auditLogs.parentEntityId} = ${projectId}`
    ).orderBy(desc(auditLogs.timestamp));
    return result;
  }

  async createAuditLog(auditLog: InsertAuditLog): Promise<AuditLog> {
    const result = await db.insert(auditLogs).values(auditLog).returning();
    return result[0];
  }
  
  async getTaskDependencies(taskId: string): Promise<TaskDependency[]> {
    return await db.select().from(taskDependencies).where(eq(taskDependencies.taskId, taskId));
  }
  
  async createTaskDependency(dependency: InsertTaskDependency): Promise<TaskDependency> {
    const result = await db.insert(taskDependencies).values(dependency).returning();
    return result[0];
  }
  
  async deleteTaskDependency(id: string): Promise<boolean> {
    const result = await db.delete(taskDependencies).where(eq(taskDependencies.id, id)).returning();
    return result.length > 0;
  }
}

export const storage = new DbStorage();
