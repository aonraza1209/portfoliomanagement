import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertStreamSchema,
  insertSubStreamSchema,
  insertProjectSchema,
  insertTaskSchema,
  insertActivitySchema,
  insertRaidLogSchema,
  insertDocumentSchema,
  insertStakeholderSchema,
  insertStrategicGoalSchema,
  insertMilestoneSchema,
  updateMilestoneSchema,
  insertBenefitSchema,
  insertExpenseSchema,
  insertBudgetLineSchema,
  insertTaskDependencySchema,
  insertMilestoneDependencySchema,
  type InsertAuditLog,
} from "@shared/schema";

async function logAuditEvent(data: {
  entityType: string;
  entityId: string;
  action: 'create' | 'update' | 'delete' | 'status_change';
  parentEntityId?: string;
  changes?: any;
  performedBy?: string;
}) {
  const auditLog: InsertAuditLog = {
    entityType: data.entityType,
    entityId: data.entityId,
    action: data.action,
    parentEntityId: data.parentEntityId || null,
    changes: data.changes ? JSON.stringify(data.changes) : null,
    performedBy: data.performedBy || null,
  };
  
  try {
    await storage.createAuditLog(auditLog);
  } catch (error) {
    console.error('Failed to create audit log:', error);
  }
}

async function recalculateStrategicGoalProgress(goalId: string) {
  const goal = await storage.getStrategicGoal(goalId);
  if (!goal) return;
  
  const linkedProjects = await storage.getProjectsByStrategicGoalId(goalId);
  let calculatedProgress = 0;
  
  if (linkedProjects.length > 0) {
    const totalProgress = linkedProjects.reduce((sum, p) => sum + (p.progress || 0), 0);
    calculatedProgress = Math.round(totalProgress / linkedProjects.length);
  }
  
  if (goal.targetValue && goal.currentValue) {
    const target = parseFloat(goal.targetValue);
    const current = parseFloat(goal.currentValue);
    if (!isNaN(target) && !isNaN(current) && target > 0) {
      const quantitativeProgress = Math.round((current / target) * 100);
      calculatedProgress = linkedProjects.length > 0 
        ? Math.round((calculatedProgress + quantitativeProgress) / 2)
        : quantitativeProgress;
    }
  }
  
  const currentGoal = await storage.getStrategicGoal(goalId);
  if (currentGoal) {
    const updated = await storage.updateStrategicGoal(goalId, {});
    if (updated) {
      (updated as any).progress = calculatedProgress;
      await storage.updateStrategicGoal(goalId, updated);
    }
  }
}

async function recalculateBudgetRollups(projectId: string) {
  const expenses = await storage.getExpensesByProjectId(projectId);
  const projectTotalSpent = expenses.reduce((sum, expense) => {
    const amount = parseFloat(expense.amount);
    return sum + (isNaN(amount) ? 0 : amount);
  }, 0);
  
  await storage.updateProjectBudget(projectId, projectTotalSpent.toString());
  
  const project = await storage.getProject(projectId);
  if (!project) return;
  
  const subStream = await storage.getSubStream(project.subStreamId);
  if (!subStream) return;
  
  const subStreamProjects = await storage.getProjectsBySubStreamId(subStream.id);
  const subStreamTotalSpent = subStreamProjects.reduce((sum, p) => {
    const spent = parseFloat(p.spent || '0');
    return sum + (isNaN(spent) ? 0 : spent);
  }, 0);
  
  await storage.updateSubStreamBudget(subStream.id, subStreamTotalSpent.toString());
  
  const allSubStreams = await storage.getSubStreamsByStreamId(subStream.streamId);
  const streamTotalSpent = allSubStreams.reduce((sum, ss) => {
    const spent = parseFloat(ss.spentToDate || '0');
    return sum + (isNaN(spent) ? 0 : spent);
  }, 0);
  
  await storage.updateStreamBudget(subStream.streamId, streamTotalSpent.toString());
}

async function recalculateProgressRollups(projectId: string) {
  // Calculate project progress from tasks
  const tasks = await storage.getTasksByProjectId(projectId);
  let projectProgress = 0;
  
  if (tasks.length > 0) {
    // Calculate weighted average by estimated hours if available
    const totalEstimatedHours = tasks.reduce((sum, task) => sum + (task.estimatedHours || 0), 0);
    
    if (totalEstimatedHours > 0) {
      // Weighted by estimated hours
      const weightedProgress = tasks.reduce((sum, task) => {
        const hours = task.estimatedHours || 0;
        return sum + (task.progress * hours);
      }, 0);
      projectProgress = Math.round(weightedProgress / totalEstimatedHours);
    } else {
      // Simple average when no estimated hours
      const totalProgress = tasks.reduce((sum, task) => sum + task.progress, 0);
      projectProgress = Math.round(totalProgress / tasks.length);
    }
  }
  
  await storage.updateProjectProgress(projectId, projectProgress);
  
  // Get project and propagate up the hierarchy
  const project = await storage.getProject(projectId);
  if (!project) return;
  
  await recalculateSubStreamProgress(project.subStreamId);
}

async function recalculateSubStreamProgress(subStreamId: string) {
  const subStream = await storage.getSubStream(subStreamId);
  if (!subStream) return;
  
  // Calculate sub-stream progress from its projects
  const subStreamProjects = await storage.getProjectsBySubStreamId(subStream.id);
  let subStreamProgress = 0;
  
  if (subStreamProjects.length > 0) {
    const totalProgress = subStreamProjects.reduce((sum, p) => sum + p.progress, 0);
    subStreamProgress = Math.round(totalProgress / subStreamProjects.length);
  }
  
  await storage.updateSubStreamProgress(subStream.id, subStreamProgress);
  
  await recalculateStreamProgress(subStream.streamId);
}

async function recalculateStreamProgress(streamId: string) {
  const stream = await storage.getStream(streamId);
  if (!stream) return;
  
  // Calculate stream progress from its sub-streams
  const allSubStreams = await storage.getSubStreamsByStreamId(stream.id);
  let streamProgress = 0;
  
  if (allSubStreams.length > 0) {
    const totalProgress = allSubStreams.reduce((sum, ss) => sum + ss.progress, 0);
    streamProgress = Math.round(totalProgress / allSubStreams.length);
  }
  
  await storage.updateStreamProgress(stream.id, streamProgress);
}

async function recalculateStreamRollups(streamId: string) {
  const subStreams = await storage.getSubStreamsByStreamId(streamId);
  let streamTotal = 0;
  
  for (const subStream of subStreams) {
    const projects = await storage.getProjectsBySubStreamId(subStream.id);
    let subStreamTotal = 0;
    
    if (projects.length === 0) {
      await storage.updateSubStreamBudget(subStream.id, "0");
    } else {
      for (const project of projects) {
        const expenses = await storage.getExpensesByProjectId(project.id);
        const projectTotalSpent = expenses.reduce((sum, expense) => {
          const amount = parseFloat(expense.amount);
          return sum + (isNaN(amount) ? 0 : amount);
        }, 0);
        
        await storage.updateProjectBudget(project.id, projectTotalSpent.toString());
        subStreamTotal += projectTotalSpent;
      }
      
      await storage.updateSubStreamBudget(subStream.id, subStreamTotal.toString());
    }
    
    streamTotal += subStreamTotal;
  }
  
  await storage.updateStreamBudget(streamId, streamTotal.toString());
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/users", async (_req, res) => {
    const users = await storage.getAllUsers();
    res.json(users);
  });

  app.get("/api/streams", async (_req, res) => {
    const streams = await storage.getAllStreams();
    res.json(streams);
  });

  app.get("/api/streams/:id", async (req, res) => {
    const stream = await storage.getStream(req.params.id);
    if (!stream) return res.status(404).json({ error: "Stream not found" });
    res.json(stream);
  });

  app.post("/api/streams", async (req, res) => {
    const result = insertStreamSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const stream = await storage.createStream(result.data);
    res.status(201).json(stream);
  });

  app.patch("/api/streams/:id", async (req, res) => {
    const result = insertStreamSchema.partial().safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const stream = await storage.updateStream(req.params.id, result.data);
    if (!stream) return res.status(404).json({ error: "Stream not found" });
    
    await recalculateStreamRollups(req.params.id);
    
    res.json(stream);
  });

  app.delete("/api/streams/:id", async (req, res) => {
    const deleted = await storage.deleteStream(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Stream not found" });
    res.status(204).send();
  });

  app.get("/api/substreams", async (_req, res) => {
    const subStreams = await storage.getAllSubStreams();
    res.json(subStreams);
  });

  app.get("/api/streams/:streamId/substreams", async (req, res) => {
    const subStreams = await storage.getSubStreamsByStreamId(req.params.streamId);
    res.json(subStreams);
  });

  app.get("/api/substreams/:id", async (req, res) => {
    const subStream = await storage.getSubStream(req.params.id);
    if (!subStream) return res.status(404).json({ error: "Sub-stream not found" });
    res.json(subStream);
  });

  app.post("/api/substreams", async (req, res) => {
    const result = insertSubStreamSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const subStream = await storage.createSubStream(result.data);
    res.status(201).json(subStream);
  });

  app.patch("/api/substreams/:id", async (req, res) => {
    const result = insertSubStreamSchema.partial().safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const subStream = await storage.updateSubStream(req.params.id, result.data);
    if (!subStream) return res.status(404).json({ error: "Sub-stream not found" });
    
    if (subStream.streamId) {
      await recalculateStreamRollups(subStream.streamId);
    }
    
    res.json(subStream);
  });

  app.delete("/api/substreams/:id", async (req, res) => {
    const deleted = await storage.deleteSubStream(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Sub-stream not found" });
    res.status(204).send();
  });

  app.get("/api/projects", async (_req, res) => {
    const projects = await storage.getAllProjects();
    res.json(projects);
  });

  app.get("/api/substreams/:subStreamId/projects", async (req, res) => {
    const projects = await storage.getProjectsBySubStreamId(req.params.subStreamId);
    res.json(projects);
  });

  app.get("/api/projects/:id", async (req, res) => {
    const project = await storage.getProject(req.params.id);
    if (!project) return res.status(404).json({ error: "Project not found" });
    res.json(project);
  });

  app.post("/api/projects", async (req, res) => {
    const result = insertProjectSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    
    if (result.data.strategicGoalId) {
      const goal = await storage.getStrategicGoal(result.data.strategicGoalId);
      if (!goal) {
        return res.status(400).json({ error: "Strategic goal not found" });
      }
    }
    
    const project = await storage.createProject(result.data);
    
    await logAuditEvent({
      entityType: 'project',
      entityId: project.id,
      action: 'create',
      parentEntityId: project.subStreamId,
      changes: { name: project.name, status: project.status },
    });
    
    if (project.strategicGoalId) {
      await recalculateStrategicGoalProgress(project.strategicGoalId);
    }
    
    await recalculateSubStreamProgress(project.subStreamId);
    
    res.status(201).json(project);
  });

  app.patch("/api/projects/:id", async (req, res) => {
    const result = insertProjectSchema.partial().safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    const existingProject = await storage.getProject(req.params.id);
    if (!existingProject) return res.status(404).json({ error: "Project not found" });
    
    if (result.data.strategicGoalId) {
      const goal = await storage.getStrategicGoal(result.data.strategicGoalId);
      if (!goal) {
        return res.status(400).json({ error: "Strategic goal not found" });
      }
    }
    
    const project = await storage.updateProject(req.params.id, result.data);
    if (!project) return res.status(404).json({ error: "Project not found" });
    
    const changes: any = {};
    if (result.data.name !== undefined && result.data.name !== existingProject.name) {
      changes.name = { from: existingProject.name, to: result.data.name };
    }
    if (result.data.status !== undefined && result.data.status !== existingProject.status) {
      changes.status = { from: existingProject.status, to: result.data.status };
    }
    
    if (Object.keys(changes).length > 0) {
      await logAuditEvent({
        entityType: 'project',
        entityId: project.id,
        action: result.data.status !== undefined && result.data.status !== existingProject.status ? 'status_change' : 'update',
        parentEntityId: project.subStreamId,
        changes,
      });
    }
    
    const affectedGoals = new Set<string>();
    if (existingProject.strategicGoalId) affectedGoals.add(existingProject.strategicGoalId);
    if (project.strategicGoalId) affectedGoals.add(project.strategicGoalId);
    
    for (const goalId of Array.from(affectedGoals)) {
      await recalculateStrategicGoalProgress(goalId);
    }
    
    if (existingProject.subStreamId !== project.subStreamId) {
      await recalculateBudgetRollups(req.params.id);
      if (existingProject.subStreamId) {
        const oldSubStreamProjects = await storage.getProjectsBySubStreamId(existingProject.subStreamId);
        if (oldSubStreamProjects.length > 0) {
          await recalculateBudgetRollups(oldSubStreamProjects[0].id);
        }
        await recalculateSubStreamProgress(existingProject.subStreamId);
      }
      await recalculateSubStreamProgress(project.subStreamId);
    } else {
      await recalculateBudgetRollups(req.params.id);
      await recalculateSubStreamProgress(project.subStreamId);
    }
    
    res.json(project);
  });

  app.delete("/api/projects/:id", async (req, res) => {
    const project = await storage.getProject(req.params.id);
    const deleted = await storage.deleteProject(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Project not found" });
    
    if (project) {
      await logAuditEvent({
        entityType: 'project',
        entityId: project.id,
        action: 'delete',
        parentEntityId: project.subStreamId,
        changes: { name: project.name, status: project.status },
      });
      
      if (project.strategicGoalId) {
        await recalculateStrategicGoalProgress(project.strategicGoalId);
      }
      
      if (project.subStreamId) {
        await recalculateSubStreamProgress(project.subStreamId);
      }
    }
    
    res.status(204).send();
  });

  app.get("/api/tasks", async (_req, res) => {
    const tasks = await storage.getAllTasks();
    res.json(tasks);
  });

  app.get("/api/projects/:projectId/tasks", async (req, res) => {
    const tasks = await storage.getTasksByProjectId(req.params.projectId);
    res.json(tasks);
  });

  app.get("/api/tasks/:id", async (req, res) => {
    const task = await storage.getTask(req.params.id);
    if (!task) return res.status(404).json({ error: "Task not found" });
    res.json(task);
  });

  app.post("/api/tasks", async (req, res) => {
    const result = insertTaskSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const task = await storage.createTask(result.data);
    await recalculateProgressRollups(task.projectId);
    res.status(201).json(task);
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    const body = {
      ...req.body,
      startDate: req.body.startDate ? (typeof req.body.startDate === 'string' ? new Date(req.body.startDate) : req.body.startDate) : null,
      endDate: req.body.endDate ? (typeof req.body.endDate === 'string' ? new Date(req.body.endDate) : req.body.endDate) : null,
    };
    const task = await storage.updateTask(req.params.id, body);
    if (!task) return res.status(404).json({ error: "Task not found" });
    await recalculateProgressRollups(task.projectId);
    res.json(task);
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    const task = await storage.getTask(req.params.id);
    const deleted = await storage.deleteTask(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Task not found" });
    if (task) {
      await recalculateProgressRollups(task.projectId);
    }
    res.status(204).send();
  });

  app.get("/api/tasks/:taskId/dependencies", async (req, res) => {
    const dependencies = await storage.getTaskDependencies(req.params.taskId);
    res.json(dependencies);
  });

  app.get("/api/projects/:projectId/dependencies", async (req, res) => {
    const tasks = await storage.getTasksByProjectId(req.params.projectId);
    const allDependencies = [];
    
    for (const task of tasks) {
      const deps = await storage.getTaskDependencies(task.id);
      allDependencies.push(...deps);
    }
    
    res.json(allDependencies);
  });

  app.post("/api/task-dependencies", async (req, res) => {
    const result = insertTaskDependencySchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    
    const { taskId, dependsOnId } = result.data;
    
    if (taskId === dependsOnId) {
      return res.status(400).json({ error: "A task cannot depend on itself" });
    }
    
    const task = await storage.getTask(taskId);
    const dependsOnTask = await storage.getTask(dependsOnId);
    
    if (!task || !dependsOnTask) {
      return res.status(404).json({ error: "One or both tasks not found" });
    }
    
    if (task.projectId !== dependsOnTask.projectId) {
      return res.status(400).json({ error: "Tasks must be in the same project" });
    }
    
    const existingDeps = await storage.getTaskDependencies(taskId);
    const alreadyExists = existingDeps.some(dep => dep.dependsOnId === dependsOnId);
    if (alreadyExists) {
      return res.status(400).json({ error: "This dependency already exists" });
    }
    
    async function hasCircularDependency(startTaskId: string, targetTaskId: string): Promise<boolean> {
      const visited = new Set<string>();
      const stack = [startTaskId];
      
      while (stack.length > 0) {
        const currentTaskId = stack.pop()!;
        
        if (currentTaskId === targetTaskId) return true;
        if (visited.has(currentTaskId)) continue;
        
        visited.add(currentTaskId);
        const deps = await storage.getTaskDependencies(currentTaskId);
        
        for (const dep of deps) {
          if (!visited.has(dep.dependsOnId)) {
            stack.push(dep.dependsOnId);
          }
        }
      }
      
      return false;
    }
    
    const wouldCreateCycle = await hasCircularDependency(dependsOnId, taskId);
    if (wouldCreateCycle) {
      return res.status(400).json({ error: "This dependency would create a circular reference" });
    }
    
    const dependency = await storage.createTaskDependency(result.data);
    res.status(201).json(dependency);
  });

  app.delete("/api/task-dependencies/:id", async (req, res) => {
    const deleted = await storage.deleteTaskDependency(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Dependency not found" });
    res.status(204).send();
  });

  app.get("/api/activities", async (_req, res) => {
    const activities = await storage.getAllActivities();
    res.json(activities);
  });

  app.get("/api/tasks/:taskId/activities", async (req, res) => {
    const activities = await storage.getActivitiesByTaskId(req.params.taskId);
    res.json(activities);
  });

  app.get("/api/activities/:id", async (req, res) => {
    const activity = await storage.getActivity(req.params.id);
    if (!activity) return res.status(404).json({ error: "Activity not found" });
    res.json(activity);
  });

  app.post("/api/activities", async (req, res) => {
    const result = insertActivitySchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const activity = await storage.createActivity(result.data);
    res.status(201).json(activity);
  });

  app.patch("/api/activities/:id", async (req, res) => {
    const activity = await storage.updateActivity(req.params.id, req.body);
    if (!activity) return res.status(404).json({ error: "Activity not found" });
    res.json(activity);
  });

  app.delete("/api/activities/:id", async (req, res) => {
    const deleted = await storage.deleteActivity(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Activity not found" });
    res.status(204).send();
  });

  app.get("/api/raid-logs", async (_req, res) => {
    const raidLogs = await storage.getAllRaidLogs();
    res.json(raidLogs);
  });

  app.get("/api/projects/:projectId/raid-logs", async (req, res) => {
    const raidLogs = await storage.getRaidLogsByProjectId(req.params.projectId);
    res.json(raidLogs);
  });

  app.get("/api/raid-logs/:id", async (req, res) => {
    const raidLog = await storage.getRaidLog(req.params.id);
    if (!raidLog) return res.status(404).json({ error: "RAID log not found" });
    res.json(raidLog);
  });

  app.post("/api/raid-logs", async (req, res) => {
    const result = insertRaidLogSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const raidLog = await storage.createRaidLog(result.data);
    res.status(201).json(raidLog);
  });

  app.patch("/api/raid-logs/:id", async (req, res) => {
    const raidLog = await storage.updateRaidLog(req.params.id, req.body);
    if (!raidLog) return res.status(404).json({ error: "RAID log not found" });
    res.json(raidLog);
  });

  app.delete("/api/raid-logs/:id", async (req, res) => {
    const deleted = await storage.deleteRaidLog(req.params.id);
    if (!deleted) return res.status(404).json({ error: "RAID log not found" });
    res.status(204).send();
  });

  app.get("/api/documents", async (_req, res) => {
    const documents = await storage.getAllDocuments();
    res.json(documents);
  });

  app.get("/api/projects/:projectId/documents", async (req, res) => {
    const documents = await storage.getDocumentsByProjectId(req.params.projectId);
    res.json(documents);
  });

  app.get("/api/documents/:id", async (req, res) => {
    const document = await storage.getDocument(req.params.id);
    if (!document) return res.status(404).json({ error: "Document not found" });
    res.json(document);
  });

  app.post("/api/documents", async (req, res) => {
    const result = insertDocumentSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const document = await storage.createDocument(result.data);
    res.status(201).json(document);
  });

  app.delete("/api/documents/:id", async (req, res) => {
    const deleted = await storage.deleteDocument(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Document not found" });
    res.status(204).send();
  });

  app.get("/api/stakeholders", async (_req, res) => {
    const stakeholders = await storage.getAllStakeholders();
    res.json(stakeholders);
  });

  app.get("/api/projects/:projectId/stakeholders", async (req, res) => {
    const stakeholders = await storage.getStakeholdersByProjectId(req.params.projectId);
    res.json(stakeholders);
  });

  app.get("/api/stakeholders/:id", async (req, res) => {
    const stakeholder = await storage.getStakeholder(req.params.id);
    if (!stakeholder) return res.status(404).json({ error: "Stakeholder not found" });
    res.json(stakeholder);
  });

  app.post("/api/stakeholders", async (req, res) => {
    const result = insertStakeholderSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const stakeholder = await storage.createStakeholder(result.data);
    res.status(201).json(stakeholder);
  });

  app.patch("/api/stakeholders/:id", async (req, res) => {
    const stakeholder = await storage.updateStakeholder(req.params.id, req.body);
    if (!stakeholder) return res.status(404).json({ error: "Stakeholder not found" });
    res.json(stakeholder);
  });

  app.delete("/api/stakeholders/:id", async (req, res) => {
    const deleted = await storage.deleteStakeholder(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Stakeholder not found" });
    res.status(204).send();
  });

  app.get("/api/strategic-goals", async (_req, res) => {
    const goals = await storage.getAllStrategicGoals();
    res.json(goals);
  });

  app.get("/api/strategic-goals/:id", async (req, res) => {
    const goal = await storage.getStrategicGoal(req.params.id);
    if (!goal) return res.status(404).json({ error: "Strategic goal not found" });
    res.json(goal);
  });

  app.post("/api/strategic-goals", async (req, res) => {
    let targetDate = null;
    if (req.body.targetDate) {
      const parsedDate = new Date(req.body.targetDate);
      if (isNaN(parsedDate.getTime())) {
        return res.status(400).json({ error: "Invalid target date" });
      }
      targetDate = parsedDate;
    }
    
    const payload = {
      ...req.body,
      targetDate,
    };
    const result = insertStrategicGoalSchema.safeParse(payload);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const goal = await storage.createStrategicGoal(result.data);
    res.status(201).json(goal);
  });

  app.patch("/api/strategic-goals/:id", async (req, res) => {
    const goal = await storage.updateStrategicGoal(req.params.id, req.body);
    if (!goal) return res.status(404).json({ error: "Strategic goal not found" });
    res.json(goal);
  });

  app.delete("/api/strategic-goals/:id", async (req, res) => {
    const deleted = await storage.deleteStrategicGoal(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Strategic goal not found" });
    res.status(204).send();
  });

  app.get("/api/strategic-goals/:id/projects", async (req, res) => {
    const projects = await storage.getProjectsByStrategicGoalId(req.params.id);
    res.json(projects);
  });

  app.post("/api/strategic-goals/:id/calculate-progress", async (req, res) => {
    const goal = await storage.getStrategicGoal(req.params.id);
    if (!goal) return res.status(404).json({ error: "Strategic goal not found" });

    await recalculateStrategicGoalProgress(req.params.id);
    
    const updated = await storage.getStrategicGoal(req.params.id);
    res.json(updated);
  });

  app.get("/api/milestones", async (_req, res) => {
    const milestones = await storage.getAllMilestones();
    res.json(milestones);
  });

  app.get("/api/projects/:projectId/milestones", async (req, res) => {
    const milestones = await storage.getMilestonesByProjectId(req.params.projectId);
    res.json(milestones);
  });

  app.get("/api/milestones/:id", async (req, res) => {
    const milestone = await storage.getMilestone(req.params.id);
    if (!milestone) return res.status(404).json({ error: "Milestone not found" });
    res.json(milestone);
  });

  app.post("/api/milestones", async (req, res) => {
    const result = insertMilestoneSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const milestone = await storage.createMilestone(result.data);
    res.status(201).json(milestone);
  });

  app.patch("/api/milestones/:id", async (req, res) => {
    const result = updateMilestoneSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const milestone = await storage.updateMilestone(req.params.id, result.data);
    if (!milestone) return res.status(404).json({ error: "Milestone not found" });
    
    await logAuditEvent({
      entityType: 'milestone',
      entityId: milestone.id,
      action: 'update',
      parentEntityId: milestone.projectId,
      changes: req.body,
    });
    
    res.json(milestone);
  });

  app.delete("/api/milestones/:id", async (req, res) => {
    const milestone = await storage.getMilestone(req.params.id);
    if (!milestone) return res.status(404).json({ error: "Milestone not found" });
    
    const deleted = await storage.deleteMilestone(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Milestone not found" });
    
    await logAuditEvent({
      entityType: 'milestone',
      entityId: req.params.id,
      action: 'delete',
      parentEntityId: milestone.projectId,
    });
    
    res.status(204).send();
  });

  app.get("/api/milestones/:id/dependencies", async (req, res) => {
    const dependencies = await storage.getMilestoneDependencies(req.params.id);
    res.json(dependencies);
  });

  app.post("/api/milestone-dependencies", async (req, res) => {
    const result = insertMilestoneDependencySchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    if (result.data.milestoneId === result.data.dependsOnId) {
      return res.status(400).json({ error: "A milestone cannot depend on itself" });
    }

    const milestone = await storage.getMilestone(result.data.milestoneId);
    if (!milestone) {
      return res.status(400).json({ error: "Milestone not found" });
    }

    const dependsOnMilestone = await storage.getMilestone(result.data.dependsOnId);
    if (!dependsOnMilestone) {
      return res.status(400).json({ error: "Dependency milestone not found" });
    }

    if (milestone.projectId !== dependsOnMilestone.projectId) {
      return res.status(400).json({ error: "Cannot create dependencies between milestones in different projects" });
    }

    const existingDependencies = await storage.getMilestoneDependencies(result.data.milestoneId);
    const dependencyExists = existingDependencies.some(
      dep => dep.dependsOnId === result.data.dependsOnId
    );
    if (dependencyExists) {
      return res.status(400).json({ error: "Dependency already exists" });
    }

    async function hasCircularDependency(milestoneId: string, dependsOnId: string, visited = new Set<string>()): Promise<boolean> {
      if (visited.has(dependsOnId)) return false;
      if (dependsOnId === milestoneId) return true;
      visited.add(dependsOnId);
      
      const dependencies = await storage.getMilestoneDependencies(dependsOnId);
      for (const dep of dependencies) {
        if (await hasCircularDependency(milestoneId, dep.dependsOnId, visited)) {
          return true;
        }
      }
      return false;
    }

    const hasCircular = await hasCircularDependency(result.data.milestoneId, result.data.dependsOnId);
    if (hasCircular) {
      return res.status(400).json({ error: "Creating this dependency would create a circular dependency" });
    }

    const dependency = await storage.createMilestoneDependency(result.data);
    res.json(dependency);
  });

  app.delete("/api/milestone-dependencies/:id", async (req, res) => {
    const deleted = await storage.deleteMilestoneDependency(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Dependency not found" });
    res.status(204).send();
  });

  app.get("/api/benefits", async (req, res) => {
    const benefits = await storage.getAllBenefits();
    res.json(benefits);
  });

  app.get("/api/projects/:projectId/benefits", async (req, res) => {
    const benefits = await storage.getBenefitsByProjectId(req.params.projectId);
    res.json(benefits);
  });

  app.post("/api/benefits", async (req, res) => {
    const result = insertBenefitSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    
    if (result.data.type === 'Quantitative') {
      if (!result.data.targetValue || !result.data.unit) {
        return res.status(400).json({ 
          error: "Quantitative benefits require targetValue and unit" 
        });
      }
    }
    
    const benefit = await storage.createBenefit(result.data);
    res.status(201).json(benefit);
  });

  app.patch("/api/benefits/:id", async (req, res) => {
    const existing = await storage.getBenefit(req.params.id);
    if (!existing) {
      return res.status(404).json({ error: "Benefit not found" });
    }
    
    const resultingType = req.body.type ?? existing.type;
    
    if (resultingType === 'Quantitative') {
      const targetValue = req.body.targetValue ?? existing.targetValue;
      const unit = req.body.unit ?? existing.unit;
      
      if (!targetValue || !unit) {
        return res.status(400).json({ 
          error: "Quantitative benefits require targetValue and unit" 
        });
      }
    }
    
    const benefit = await storage.updateBenefit(req.params.id, req.body);
    res.json(benefit);
  });

  app.delete("/api/benefits/:id", async (req, res) => {
    const deleted = await storage.deleteBenefit(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Benefit not found" });
    res.status(204).send();
  });

  app.get("/api/expenses", async (_req, res) => {
    const expenses = await storage.getAllExpenses();
    res.json(expenses);
  });

  app.get("/api/expenses/:id", async (req, res) => {
    const expense = await storage.getExpense(req.params.id);
    if (!expense) return res.status(404).json({ error: "Expense not found" });
    res.json(expense);
  });

  app.get("/api/projects/:id/expenses", async (req, res) => {
    const expenses = await storage.getExpensesByProjectId(req.params.id);
    res.json(expenses);
  });

  app.post("/api/expenses", async (req, res) => {
    const result = insertExpenseSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const expense = await storage.createExpense(result.data);
    await recalculateBudgetRollups(expense.projectId);
    res.status(201).json(expense);
  });

  app.patch("/api/expenses/:id", async (req, res) => {
    const result = insertExpenseSchema.partial().safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const expense = await storage.updateExpense(req.params.id, result.data);
    if (!expense) return res.status(404).json({ error: "Expense not found" });
    await recalculateBudgetRollups(expense.projectId);
    res.json(expense);
  });

  app.delete("/api/expenses/:id", async (req, res) => {
    const expense = await storage.getExpense(req.params.id);
    const deleted = await storage.deleteExpense(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Expense not found" });
    if (expense) {
      await recalculateBudgetRollups(expense.projectId);
    }
    res.status(204).send();
  });

  app.get("/api/budget-lines", async (_req, res) => {
    const budgetLines = await storage.getAllBudgetLines();
    res.json(budgetLines);
  });

  app.get("/api/budget-lines/:id", async (req, res) => {
    const budgetLine = await storage.getBudgetLine(req.params.id);
    if (!budgetLine) return res.status(404).json({ error: "Budget line not found" });
    res.json(budgetLine);
  });

  app.get("/api/projects/:id/budget-lines", async (req, res) => {
    const budgetLines = await storage.getBudgetLinesByProjectId(req.params.id);
    res.json(budgetLines);
  });

  app.post("/api/budget-lines", async (req, res) => {
    const result = insertBudgetLineSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const budgetLine = await storage.createBudgetLine(result.data);
    res.status(201).json(budgetLine);
  });

  app.patch("/api/budget-lines/:id", async (req, res) => {
    const result = insertBudgetLineSchema.partial().safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const budgetLine = await storage.updateBudgetLine(req.params.id, result.data);
    if (!budgetLine) return res.status(404).json({ error: "Budget line not found" });
    res.json(budgetLine);
  });

  app.delete("/api/budget-lines/:id", async (req, res) => {
    const deleted = await storage.deleteBudgetLine(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Budget line not found" });
    res.status(204).send();
  });

  app.get("/api/audit-logs", async (req, res) => {
    const { scope, id } = req.query;
    
    if (scope === "project" && typeof id === "string") {
      const logs = await storage.getAuditLogsByProject(id);
      return res.json(logs);
    }
    
    const logs = await storage.getAllAuditLogs();
    res.json(logs);
  });

  app.get("/api/audit-logs/:id", async (req, res) => {
    const log = await storage.getAuditLog(req.params.id);
    if (!log) return res.status(404).json({ error: "Audit log not found" });
    res.json(log);
  });

  app.get("/api/audit-logs/entity/:entityType/:entityId", async (req, res) => {
    const logs = await storage.getAuditLogsByEntity(req.params.entityType, req.params.entityId);
    res.json(logs);
  });

  const httpServer = createServer(app);
  return httpServer;
}
