import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const strategicGoals = pgTable("strategic_goals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  targetDate: timestamp("target_date"),
  status: text("status").notNull().default('Active'),
  targetValue: text("target_value"),
  currentValue: text("current_value"),
  unit: text("unit"),
  qualitativeTarget: text("qualitative_target"),
  qualitativeStatus: text("qualitative_status"),
  progress: integer("progress").notNull().default(0),
});

export const insertStrategicGoalSchema = createInsertSchema(strategicGoals).omit({ id: true, currentValue: true, progress: true });
export type InsertStrategicGoal = z.infer<typeof insertStrategicGoalSchema>;
export type StrategicGoal = typeof strategicGoals.$inferSelect;

export const streams = pgTable("streams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default('Active'),
  ownerId: varchar("owner_id").references(() => users.id),
  strategicGoalIds: text("strategic_goal_ids").array(),
  allocatedBudget: decimal("allocated_budget", { precision: 15, scale: 2 }),
  spentToDate: decimal("spent_to_date", { precision: 15, scale: 2 }).default('0'),
  progress: integer("progress").notNull().default(0),
});

export const insertStreamSchema = createInsertSchema(streams).omit({ id: true, spentToDate: true, progress: true });
export type InsertStream = z.infer<typeof insertStreamSchema>;
export type Stream = typeof streams.$inferSelect;

export const subStreams = pgTable("sub_streams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  streamId: varchar("stream_id").notNull().references(() => streams.id),
  name: text("name").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default('Active'),
  ownerId: varchar("owner_id").references(() => users.id),
  spentToDate: varchar("spent_to_date"),
  progress: integer("progress").notNull().default(0),
});

export const insertSubStreamSchema = createInsertSchema(subStreams).omit({ id: true, spentToDate: true, progress: true });
export type InsertSubStream = z.infer<typeof insertSubStreamSchema>;
export type SubStream = typeof subStreams.$inferSelect;

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  subStreamId: varchar("sub_stream_id").notNull().references(() => subStreams.id),
  name: text("name").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default('Planning'),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  budget: decimal("budget", { precision: 15, scale: 2 }),
  spent: decimal("spent", { precision: 15, scale: 2 }).default('0'),
  progress: integer("progress").notNull().default(0),
  ownerId: varchar("owner_id").references(() => users.id),
  strategicGoalId: varchar("strategic_goal_id").references(() => strategicGoals.id),
  businessCase: text("business_case"),
  expectedBenefits: text("expected_benefits"),
  actualBenefits: text("actual_benefits"),
  roi: decimal("roi", { precision: 10, scale: 2 }),
  paybackPeriod: integer("payback_period"),
});

export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, spent: true, actualBenefits: true }).extend({
  startDate: z.union([z.string(), z.date()]).optional().nullable().transform(val => val ? (typeof val === 'string' ? new Date(val) : val) : null),
  endDate: z.union([z.string(), z.date()]).optional().nullable().transform(val => val ? (typeof val === 'string' ? new Date(val) : val) : null),
});
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export const milestones = pgTable("milestones", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  name: text("name").notNull(),
  description: text("description"),
  dueDate: timestamp("due_date").notNull(),
  status: text("status").notNull().default('Pending'),
  completedDate: timestamp("completed_date"),
  ownerId: varchar("owner_id").references(() => users.id),
});

export const insertMilestoneSchema = createInsertSchema(milestones).omit({ id: true, completedDate: true }).extend({
  dueDate: z.union([z.string(), z.date()]).transform(val => typeof val === 'string' ? new Date(val) : val),
});
export type InsertMilestone = z.infer<typeof insertMilestoneSchema>;

export const updateMilestoneSchema = createInsertSchema(milestones).omit({ id: true, projectId: true, completedDate: true }).partial().extend({
  dueDate: z.union([z.string(), z.date()]).optional().transform(val => val ? (typeof val === 'string' ? new Date(val) : val) : undefined),
});
export type UpdateMilestone = z.infer<typeof updateMilestoneSchema>;

export type Milestone = typeof milestones.$inferSelect;

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  milestoneId: varchar("milestone_id").references(() => milestones.id),
  parentTaskId: varchar("parent_task_id").references(() => tasks.id),
  name: text("name").notNull(),
  description: text("description"),
  assignedTo: varchar("assigned_to").references(() => users.id),
  status: text("status").notNull().default('Not Started'),
  priority: text("priority").notNull().default('Medium'),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  progress: integer("progress").notNull().default(0),
  dependencyIds: text("dependency_ids").array(),
  isCriticalPath: boolean("is_critical_path").notNull().default(false),
  estimatedHours: integer("estimated_hours"),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true, isCriticalPath: true }).extend({
  startDate: z.union([z.string(), z.date()]).optional().nullable().transform(val => val ? (typeof val === 'string' ? new Date(val) : val) : null),
  endDate: z.union([z.string(), z.date()]).optional().nullable().transform(val => val ? (typeof val === 'string' ? new Date(val) : val) : null),
  milestoneId: z.string().nullable().optional(),
  parentTaskId: z.string().nullable().optional(),
});
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export const taskDependencies = pgTable("task_dependencies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").notNull().references(() => tasks.id),
  dependsOnId: varchar("depends_on_id").notNull().references(() => tasks.id),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertTaskDependencySchema = createInsertSchema(taskDependencies).omit({ id: true, createdAt: true });
export type InsertTaskDependency = z.infer<typeof insertTaskDependencySchema>;
export type TaskDependency = typeof taskDependencies.$inferSelect;

export const milestoneDependencies = pgTable("milestone_dependencies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  milestoneId: varchar("milestone_id").notNull().references(() => milestones.id),
  dependsOnId: varchar("depends_on_id").notNull().references(() => milestones.id),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertMilestoneDependencySchema = createInsertSchema(milestoneDependencies).omit({ id: true, createdAt: true });
export type InsertMilestoneDependency = z.infer<typeof insertMilestoneDependencySchema>;
export type MilestoneDependency = typeof milestoneDependencies.$inferSelect;

export const activities = pgTable("activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").notNull().references(() => tasks.id),
  name: text("name").notNull(),
  description: text("description"),
  assignedTo: varchar("assigned_to").references(() => users.id),
  status: text("status").notNull().default('Not Started'),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  progress: integer("progress").notNull().default(0),
});

export const insertActivitySchema = createInsertSchema(activities).omit({ id: true });
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

export const raidLogs = pgTable("raid_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  type: text("type").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default('Open'),
  severity: text("severity"),
  owner: varchar("owner").references(() => users.id),
  mitigationPlan: text("mitigation_plan"),
  dateRaised: timestamp("date_raised").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertRaidLogSchema = createInsertSchema(raidLogs).omit({ id: true, dateRaised: true });
export type InsertRaidLog = z.infer<typeof insertRaidLogSchema>;
export type RaidLog = typeof raidLogs.$inferSelect;

export const documents = pgTable("documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  name: text("name").notNull(),
  url: text("url").notNull(),
  type: text("type").notNull(),
  uploadedBy: varchar("uploaded_by").references(() => users.id),
  uploadedAt: timestamp("uploaded_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true, uploadedAt: true });
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

export const stakeholders = pgTable("stakeholders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  name: text("name").notNull(),
  role: text("role").notNull(),
  email: text("email"),
  influence: text("influence").notNull(),
  interest: text("interest").notNull(),
  engagementStrategy: text("engagement_strategy"),
});

export const insertStakeholderSchema = createInsertSchema(stakeholders).omit({ id: true });
export type InsertStakeholder = z.infer<typeof insertStakeholderSchema>;
export type Stakeholder = typeof stakeholders.$inferSelect;

export const benefits = pgTable("benefits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  type: text("type").notNull().default('Qualitative'),
  targetValue: text("target_value"),
  actualValue: text("actual_value"),
  unit: text("unit"),
  status: text("status").notNull().default('Planned'),
  achievementDate: timestamp("achievement_date"),
  notes: text("notes"),
});

export const insertBenefitSchema = createInsertSchema(benefits).omit({ id: true, actualValue: true });
export type InsertBenefit = z.infer<typeof insertBenefitSchema>;
export type Benefit = typeof benefits.$inferSelect;

export const expenses = pgTable("expenses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  category: text("category").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  date: timestamp("date").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertExpenseSchema = createInsertSchema(expenses).omit({ id: true, createdAt: true }).extend({
  date: z.union([z.string(), z.date()]).transform(val => typeof val === 'string' ? new Date(val) : val),
  amount: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, {
    message: "Amount must be a valid non-negative number"
  }),
});
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;

export const budgetLines = pgTable("budget_lines", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  category: text("category").notNull(),
  allocatedAmount: decimal("allocated_amount", { precision: 15, scale: 2 }).notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertBudgetLineSchema = createInsertSchema(budgetLines).omit({ id: true, createdAt: true }).extend({
  allocatedAmount: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, {
    message: "Allocated amount must be a valid non-negative number"
  }),
});
export type InsertBudgetLine = z.infer<typeof insertBudgetLineSchema>;
export type BudgetLine = typeof budgetLines.$inferSelect;

export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entityType: text("entity_type").notNull(),
  entityId: varchar("entity_id").notNull(),
  parentEntityId: varchar("parent_entity_id"),
  action: text("action").notNull(),
  performedBy: varchar("performed_by").references(() => users.id),
  timestamp: timestamp("timestamp").notNull().default(sql`CURRENT_TIMESTAMP`),
  changes: text("changes"),
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({ id: true, timestamp: true });
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
